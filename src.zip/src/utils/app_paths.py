#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
路径适配工具：
- 开发环境：在项目根/src/CWD 中查找资源
- 打包环境：支持 PyInstaller (_MEIPASS、onedir)、macOS .app Resources
- 数据目录：按平台返回标准的用户数据目录
"""

import sys
import os
from pathlib import Path


def resource_path(relative_path: str) -> Path:
    """返回资源的绝对路径，兼容开发模式与打包模式（含 macOS .app）"""
    if not getattr(sys, 'frozen', False):
        base_path = Path(__file__).resolve().parent.parent.parent
        for p in (base_path / relative_path, base_path / "src" / relative_path, Path.cwd() / relative_path):
            if p.exists():
                return p
        return base_path / relative_path
    if hasattr(sys, '_MEIPASS'):
        p = Path(sys._MEIPASS) / relative_path
        if p.exists():
            return p
    exe_path = Path(sys.executable)
    if sys.platform == "darwin" and ".app" in str(exe_path):
        r = exe_path.parent.parent / "Resources" / relative_path
        if r.exists():
            return r
    p = exe_path.parent / relative_path
    if p.exists():
        return p
    return exe_path.parent / relative_path


def get_app_data_dir() -> Path:
    """返回平台对应的应用数据目录（CursorProManager）"""
    if sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    elif sys.platform == "win32":
        base = Path(os.getenv('APPDATA', str(Path.home() / 'AppData' / 'Roaming')))
    else:
        base = Path.home() / '.config'
    d = base / 'CursorProManager'
    d.mkdir(parents=True, exist_ok=True)
    return d


def get_config_file() -> Path:
    """配置文件路径"""
    return get_app_data_dir() / 'config.json'


def get_data_dir() -> Path:
    """数据目录路径"""
    d = get_app_data_dir() / 'data'
    d.mkdir(parents=True, exist_ok=True)
    return d


def get_database_file() -> Path:
    """数据库文件路径"""
    return get_data_dir() / 'accounts.db'


def get_key_file() -> Path:
    """密钥文件路径"""
    return get_data_dir() / '.key'


def get_logs_dir() -> Path:
    """日志目录路径"""
    d = get_data_dir() / 'logs'
    d.mkdir(parents=True, exist_ok=True)
    return d
