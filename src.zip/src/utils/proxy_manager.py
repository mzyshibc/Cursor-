# -*- coding: utf-8 -*-
import random
import os
from pathlib import Path
try:
    from src.utils.logger import get_logger
except ImportError:
    from utils.logger import get_logger

logger = get_logger("proxy_manager")

class ProxyManager:
    """代理管理器"""
    
    _proxies = []
    _has_loaded = False
    
    @classmethod
    def load_proxies(cls):
        """加载代理列表"""
        if cls._has_loaded:
            return

        # 尝试查找代理文件
        # 优先查找 f:\Cursorzidongzhuce\Webshare 10 proxies.txt
        # 其次查找项目根目录下的 proxies.txt
        
        possible_paths = [
            r"f:\Cursorzidongzhuce\Webshare 10 proxies.txt",
            os.path.join(os.getcwd(), "Webshare 10 proxies.txt"),
            os.path.join(os.getcwd(), "proxies.txt")
        ]
        
        proxy_file = None
        for path in possible_paths:
            if os.path.exists(path):
                proxy_file = path
                break
        
        if not proxy_file:
            logger.debug("未找到代理文件 (Webshare 10 proxies.txt)")
            cls._has_loaded = True
            return

        try:
            with open(proxy_file, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            valid_count = 0
            for line in lines:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                
                # 解析格式
                # 格式1: ip:port:username:password (Webshare 默认导出格式)
                # 格式2: http://user:pass@ip:port (标准格式)
                
                proxy_url = None
                
                if "://" in line:
                    proxy_url = line
                elif ":" in line:
                    parts = line.split(':')
                    if len(parts) == 4:
                        # ip:port:user:pass -> http://user:pass@ip:port
                        ip, port, user, pwd = parts
                        proxy_url = f"http://{user}:{pwd}@{ip}:{port}"
                    elif len(parts) == 2:
                        # ip:port -> http://ip:port
                        proxy_url = f"http://{line}"
                
                if proxy_url:
                    cls._proxies.append(proxy_url)
                    valid_count += 1
            
            logger.info(f"✅ 已加载 {valid_count} 个代理")
            cls._has_loaded = True
            
        except Exception as e:
            logger.error(f"加载代理文件失败: {e}")

    @classmethod
    def get_random_proxy(cls):
        """获取随机代理"""
        cls.load_proxies()
        
        if not cls._proxies:
            return None
            
        return random.choice(cls._proxies)
