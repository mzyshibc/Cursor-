#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
日志工具模块
提供统一的日志记录功能
"""

import logging
import logging.handlers
import sys
import os
from pathlib import Path
from typing import Optional

try:
    from src.utils.config import ConfigManager
except ImportError:
    try:
        from utils.config import ConfigManager
    except ImportError:
        # 兼容直接运行脚本的情况
        sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
        from src.utils.config import ConfigManager


class SensitiveDataFilter(logging.Filter):
    """敏感数据过滤器"""

    def __init__(self):
        super().__init__()
        self.sensitive_patterns = [
            r'access_token=[^\s&]+',
            r'refresh_token=[^\s&]+',
            r'session_token=[^\s&]+',
            r'password=[^\s&]+',
            r'pin=[^\s&]+',
            r'api_key=[^\s&]+',
        ]

    def filter(self, record):
        if hasattr(record, 'msg') and isinstance(record.msg, str):
            import re
            msg = record.msg

            # 替换敏感信息
            for pattern in self.sensitive_patterns:
                msg = re.sub(pattern, lambda m: m.group(0)[:20] + '***', msg, flags=re.IGNORECASE)

            # 也检查args中的敏感信息
            if hasattr(record, 'args') and record.args:
                new_args = []
                for arg in record.args:
                    if isinstance(arg, str):
                        for pattern in self.sensitive_patterns:
                            arg = re.sub(pattern, lambda m: m.group(0)[:20] + '***', arg, flags=re.IGNORECASE)
                    new_args.append(arg)
                record.args = tuple(new_args)

            record.msg = msg

        return True


def setup_logger(
    name: str = "cursor_vip",
    level: str = "INFO",
    log_dir: Optional[Path] = None,
    max_files: int = 10,
    max_size: int = 10 * 1024 * 1024  # 10MB
):
    """
    设置日志系统

    Args:
        name: 日志器名称
        level: 日志级别
        log_dir: 日志目录
        max_files: 最大日志文件数
        max_size: 单个日志文件最大大小
    """
    # 获取配置
    config_manager = ConfigManager()
    system_config = config_manager.get_system_config()

    if log_dir is None:
        log_dir = config_manager.get_logs_dir()

    # 确保日志目录存在
    log_dir.mkdir(parents=True, exist_ok=True)

    # 创建日志器
    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))

    # 避免重复添加处理器
    if logger.handlers:
        return logger

    # 创建格式化器
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    # 控制台处理器
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(getattr(logging, level.upper(), logging.INFO))
    console_handler.setFormatter(formatter)
    console_handler.addFilter(SensitiveDataFilter())
    logger.addHandler(console_handler)

    # 文件处理器 (轮转)
    log_file = log_dir / f"{name}.log"
    file_handler = logging.handlers.RotatingFileHandler(
        log_file,
        maxBytes=max_size,
        backupCount=max_files,
        encoding='utf-8'
    )
    file_handler.setLevel(getattr(logging, level.upper(), logging.INFO))
    file_handler.setFormatter(formatter)
    file_handler.addFilter(SensitiveDataFilter())
    logger.addHandler(file_handler)

    # 错误日志单独文件
    error_log_file = log_dir / f"{name}_error.log"
    error_handler = logging.handlers.RotatingFileHandler(
        error_log_file,
        maxBytes=max_size,
        backupCount=max_files,
        encoding='utf-8'
    )
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(formatter)
    error_handler.addFilter(SensitiveDataFilter())
    logger.addHandler(error_handler)

    return logger


def get_logger(name: str = "cursor_vip") -> logging.Logger:
    """
    获取日志器

    Args:
        name: 日志器名称

    Returns:
        logging.Logger: 日志器实例
    """
    return logging.getLogger(f"cursor_vip.{name}")


class LoggerMixin:
    """日志混入类，为类提供日志功能"""

    @property
    def logger(self) -> logging.Logger:
        """获取日志器"""
        if not hasattr(self, '_logger'):
            self._logger = get_logger(self.__class__.__name__)
        return self._logger
