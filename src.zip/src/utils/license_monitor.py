# -*- coding: utf-8 -*-
"""
许可证实时监控模块
使用 WebSocket 保持与服务器的长连接，接收实时撤销通知
"""

import json
from PyQt6.QtCore import QObject, pyqtSignal, QUrl, QTimer
from PyQt6.QtWebSockets import QWebSocket
from PyQt6.QtNetwork import QAbstractSocket, QNetworkProxy

class LicenseMonitor(QObject):
    """
    许可证监控器
    
    信号:
        license_revoked (str): 当收到撤销通知时触发，参数为原因
    """
    license_revoked = pyqtSignal(str)
    # 新增配置更新信号
    config_updated = pyqtSignal()

    def __init__(self, server_url: str, machine_id: str):
        """
        初始化监控器
        
        Args:
            server_url: 服务器基础 URL (http/https)
            machine_id: 机器唯一标识
        """
        super().__init__()
        self.machine_id = machine_id
        
        # 转换 http/https 为 ws/wss
        if server_url.startswith("https://"):
            ws_url = server_url.replace("https://", "wss://")
        elif server_url.startswith("http://"):
            ws_url = server_url.replace("http://", "ws://")
        else:
            # 默认假设 ws
            ws_url = f"ws://{server_url}"
            
        self.url = QUrl(ws_url)
        
        self.client = QWebSocket()
        
        # 强制直连，绕过系统代理/VPN，防止因代理不稳定导致断连
        self.client.setProxy(QNetworkProxy(QNetworkProxy.ProxyType.NoProxy))
        
        self.client.connected.connect(self.on_connected)
        self.client.textMessageReceived.connect(self.on_message)
        self.client.disconnected.connect(self.on_disconnected)
        self.client.error.connect(self.on_error)
        
        # 自动重连定时器
        self.reconnect_timer = QTimer()
        self.reconnect_timer.timeout.connect(self.connect_to_server)
        self.reconnect_timer.setInterval(5000) # 5秒重试一次

    def start(self):
        """启动监控"""
        self.connect_to_server()

    def connect_to_server(self):
        """连接服务器"""
        if self.client.state() == QAbstractSocket.SocketState.UnconnectedState:
            # print(f"[Monitor] Connecting to {self.url.toString()}...")
            self.client.open(self.url)

    def on_connected(self):
        """连接成功回调"""
        # print("[Monitor] Connected to notification server")
        self.reconnect_timer.stop()
        
        # 发送身份验证信息
        auth_payload = {
            "type": "auth",
            "machine_id": self.machine_id
        }
        self.client.sendTextMessage(json.dumps(auth_payload))

    def on_disconnected(self):
        """连接断开回调"""
        # print("[Monitor] Disconnected from server")
        # 启动重连
        self.reconnect_timer.start()

    def on_error(self, error_code):
        """错误回调"""
        # print(f"[Monitor] WebSocket Error: {self.client.errorString()}")
        pass

    def on_message(self, message):
        """收到消息回调"""
        try:
            data = json.loads(message)
            msg_type = data.get("type")
            
            if msg_type == "revoke":
                reason = data.get("reason", "您的授权已被撤销")
                print(f"[Monitor] 收到撤销通知: {reason}")
                self.license_revoked.emit(reason)
                
            elif msg_type == "auth_success":
                # print("[Monitor] Authentication successful")
                pass
                
            elif msg_type == "config_updated":
                print("[Monitor] 收到配置更新通知")
                self.config_updated.emit()
                
        except Exception as e:
            print(f"[Monitor] 解析消息错误: {e}")

    def stop(self):
        """停止监控"""
        self.reconnect_timer.stop()
        self.client.close()
