import os
import time
import json
import threading
from typing import Dict, Optional, List, Tuple
import requests
try:
    from src.utils.logger import get_logger
    from src.utils.config import ConfigManager
except ImportError:
    from utils.logger import get_logger
    from utils.config import ConfigManager

logger = get_logger("sms_provider")

class HaoZhuMaClient:
    def __init__(self, config: Optional[ConfigManager] = None):
        self.cm = config or ConfigManager()
        self.lines: List[str] = []
        
        # 优先从配置中读取用户填写的账号密码
        sms_cfg = getattr(self.cm, "sms_config", None)
        self.user = ""
        self.passwd = ""
        
        if sms_cfg:
            self.user = sms_cfg.user or ""
            self.passwd = sms_cfg.password or ""
            if sms_cfg.server_urls:
                self.lines = sms_cfg.server_urls
        
        # 环境变量作为备选 (通常不使用)
        if not self.user:
            self.user = os.environ.get("CURSORPM_SMS_USER", "").strip()
        if not self.passwd:
            self.passwd = os.environ.get("CURSORPM_SMS_PASS", "").strip()
            
        if not self.lines:
            self.lines = ["https://api.haozhuma.com", "https://api.haozhuyun.com"]
            
        self.poll_interval = (sms_cfg.poll_interval if sms_cfg else 5) or 5
        self.poll_timeout = (sms_cfg.poll_timeout if sms_cfg else 300) or 300
        self.max_attempts = (sms_cfg.max_attempts if sms_cfg else 5) or 5
        
        self._token_lock = threading.Lock()
        self._token: Optional[str] = None
        self._active_line_idx = 0
        self._cache_file = self.cm.get_cache_dir() / "sms_token.json"
        self._load_token_cache()

    def _load_token_cache(self):
        try:
            if self._cache_file.exists():
                data = json.loads(self._cache_file.read_text(encoding="utf-8"))
                self._token = data.get("token") or None
        except Exception:
            pass

    def _save_token_cache(self):
        try:
            self._cache_file.parent.mkdir(parents=True, exist_ok=True)
            self._cache_file.write_text(json.dumps({"token": self._token or ""}), encoding="utf-8")
        except Exception:
            pass

    def _line_base(self) -> str:
        return self.lines[self._active_line_idx].rstrip("/")

    def _switch_line(self):
        self._active_line_idx = (self._active_line_idx + 1) % len(self.lines)
        logger.warning(f"switch sms line to {self._line_base()}")

    def login(self) -> str:
        if not self.user or not self.passwd:
             raise RuntimeError("未配置接码平台账号或密码，请在设置中填写")

        with self._token_lock:
            url = f"{self._line_base()}/sms/?api=login"
            payload = {"user": self.user, "pass": self.passwd}
            try:
                r = requests.post(url, data=payload, timeout=10)
                data = r.json()
                if str(data.get("code")) in ("0", "200"):
                    self._token = data.get("token")
                    self._save_token_cache()
                    logger.info("sms login success")
                    return self._token or ""
                self._switch_line()
                raise RuntimeError(f"登录失败: {data.get('msg', '未知错误')}")
            except Exception as e:
                self._switch_line()
                raise e

    def token(self) -> str:
        if self._token:
            return self._token
        return self.login()

    def get_summary(self) -> Dict:
        url = f"{self._line_base()}/sms/?api=getSummary"
        try:
            r = requests.get(url, params={"token": self.token()}, timeout=10)
            data = r.json()
            if str(data.get("code")) in ("0", "200"):
                return data
            self._switch_line()
            raise RuntimeError(f"获取账户信息失败: {data.get('msg', '未知错误')}")
        except Exception as e:
            self._switch_line()
            raise e

    def _resolve_sid(self, sid: int) -> int:
        """解析并返回有效的 SID"""
        if sid:
            return sid
        
        # 尝试从配置中获取
        cfg_sid = getattr(self.cm.sms_config, "selected_project", "")
        if cfg_sid:
            # 如果配置的是数字，直接使用
            if str(cfg_sid).isdigit():
                return int(cfg_sid)
            # 如果是旧的 p1 格式映射 (为了兼容)
            sid_map = getattr(self.cm.sms_config, "sid_map", {})
            if cfg_sid in sid_map:
                return int(sid_map[cfg_sid])
                
        raise ValueError("未配置项目ID (SID)，请在设置中填写")

    def get_phone(self, sid: int, prefs: Optional[Dict] = None) -> Dict:
        target_sid = self._resolve_sid(sid)
        
        # 添加开发者账号参数 author='luyefei520' 以获取分成
        params = {
            "token": self.token(), 
            "sid": target_sid,
            "author": "luyefei520"
        }
        if prefs:
            params.update({k: v for k, v in prefs.items() if v not in (None, "")})
            
        url = f"{self._line_base()}/sms/?api=getPhone"
        try:
            r = requests.get(url, params=params, timeout=10)
            data = r.json()
            if str(data.get("code")) in ("0", "200"):
                return data
            
            # 特定错误处理
            msg = data.get("msg", "")
            if "余额不足" in msg:
                 raise RuntimeError(f"接码平台余额不足: {msg}")
                 
            self._switch_line()
            raise RuntimeError(f"获取号码失败: {msg}")
        except Exception as e:
            self._switch_line()
            raise e

    def occupy_phone(self, sid: int, phone: str) -> Dict:
        target_sid = self._resolve_sid(sid)
        
        params = {
            "token": self.token(), 
            "sid": target_sid, 
            "phone": phone,
            "author": "luyefei520"
        }
        url = f"{self._line_base()}/sms/?api=getPhone"
        try:
            r = requests.get(url, params=params, timeout=10)
            data = r.json()
            if str(data.get("code")) in ("0", "200"):
                return data
            raise RuntimeError(f"指定号码失败: {data.get('msg', '未知错误')}")
        except Exception as e:
            raise e

    def get_message_once(self, sid: int, phone: str) -> Dict:
        target_sid = self._resolve_sid(sid)
        
        url = f"{self._line_base()}/sms/?api=getMessage"
        params = {"token": self.token(), "sid": target_sid, "phone": phone}
        r = requests.get(url, params=params, timeout=10)
        data = r.json()
        return data

    def poll_message(self, sid: int, phone: str, sms_expected: bool = False) -> Tuple[Optional[str], Optional[Dict]]:
        if not sms_expected:
            return None, None
            
        target_sid = self._resolve_sid(sid)
            
        start = time.time()
        last_yzm: Optional[str] = None
        attempt_count = 0
        
        while time.time() - start < self.poll_timeout:
            attempt_count += 1
            if attempt_count % 3 == 0: 
                logger.info(f"等待短信中... (已耗时 {int(time.time() - start)}秒)")
            
            try:
                data = self.get_message_once(target_sid, phone)
                code_ok = str(data.get("code")) in ("0", "200")
                yzm = data.get("yzm")
                sms = data.get("sms")
                
                if sms:
                     logger.info(f"收到短信内容: {sms}")

                if sms and not yzm:
                    logger.warning(f"⚠️ 收到短信但无验证码: {sms}")
                    # 自动修复：如果提示未获取号码，尝试重新占用
                    if "没有获取该号码" in str(sms) or "无法读取" in str(sms):
                         logger.warning("⚠️ 检测到号码未占用，尝试自动重新占用...")
                         try:
                             self.occupy_phone(target_sid, phone)
                             logger.info("✅ 重新占用请求已发送")
                             time.sleep(2)
                         except Exception as e:
                             logger.error(f"❌ 重新占用失败: {e}")

                if code_ok and yzm:
                    logger.info(f"✅ 成功获取验证码: {yzm}")
                    return yzm, data
            except Exception as e:
                logger.error(f"轮询短信异常: {e}")
                
            time.sleep(5) # 5秒轮询一次
            
        return None, None

    def cancel_recv(self, sid: int, phone: str) -> Dict:
        target_sid = self._resolve_sid(sid)
        url = f"{self._line_base()}/sms/?api=cancelRecv"
        params = {"token": self.token(), "sid": target_sid, "phone": phone}
        try:
            r = requests.get(url, params=params, timeout=10)
            return r.json()
        except Exception:
            return {}

    def cancel_all(self) -> Dict:
        url = f"{self._line_base()}/sms/?api=cancelAllRecv"
        params = {"token": self.token()}
        try:
            r = requests.get(url, params=params, timeout=10)
            return r.json()
        except Exception as e:
            return {"code": "-1", "msg": str(e)}

    def add_blacklist(self, sid: int, phone: str) -> Dict:
        target_sid = self._resolve_sid(sid)
        url = f"{self._line_base()}/sms/?api=addBlacklist"
        params = {"token": self.token(), "sid": target_sid, "phone": phone}
        try:
            r = requests.get(url, params=params, timeout=10)
            return r.json()
        except Exception:
            return {}
