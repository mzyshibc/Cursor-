#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
屏蔽 Cursor 自动更新工具类
"""

import os
import json
import platform
import shutil
from pathlib import Path
from typing import Optional, Tuple

class UpdateBlocker:
    """Cursor 自动更新屏蔽工具"""
    
    def __init__(self):
        self.cached_settings_path: Optional[Path] = None

    def find_cursor_settings_path(self) -> Optional[Path]:
        """查找 Cursor settings.json 路径"""
        if self.cached_settings_path and self.cached_settings_path.exists():
            return self.cached_settings_path

        possible_paths = []
        home = Path.home()
        system = platform.system()

        # 1. 标准路径
        if system == 'Windows':
            possible_paths.append(home / 'AppData' / 'Roaming' / 'Cursor' / 'User' / 'settings.json')
        elif system == 'Darwin': # macOS
            possible_paths.append(home / 'Library' / 'Application Support' / 'Cursor' / 'User' / 'settings.json')
        else: # Linux
            possible_paths.append(home / '.config' / 'Cursor' / 'User' / 'settings.json')

        # 2. 全盘搜索（仅 Windows）
        if system == 'Windows':
            # 获取所有驱动器
            drives = []
            for i in range(65, 91): # A-Z
                drive = f"{chr(i)}:\\"
                if os.path.exists(drive):
                    drives.append(drive)
            
            for drive in drives:
                users_dir = Path(drive) / 'Users'
                if users_dir.exists():
                    try:
                        for user_dir in users_dir.iterdir():
                            if user_dir.is_dir():
                                path = user_dir / 'AppData' / 'Roaming' / 'Cursor' / 'User' / 'settings.json'
                                possible_paths.append(path)
                    except Exception:
                        pass

        # 检查文件是否存在
        for path in possible_paths:
            try:
                if path.exists():
                    self.cached_settings_path = path
                    return path
            except Exception:
                continue
                
        # 如果找不到但标准路径目录存在，返回标准路径以便创建
        if system == 'Windows':
             default_path = home / 'AppData' / 'Roaming' / 'Cursor' / 'User' / 'settings.json'
             if default_path.parent.exists():
                 return default_path

        return None

    def is_update_blocked(self) -> bool:
        """检查是否已屏蔽更新"""
        settings_path = self.find_cursor_settings_path()
        if not settings_path or not settings_path.exists():
            return False
            
        try:
            with open(settings_path, 'r', encoding='utf-8') as f:
                settings = json.load(f)
                
            return (settings.get('update.mode') == 'none' and 
                    settings.get('update.enableWindowsBackgroundUpdates') is False)
                
        except Exception:
            return False

    def block_updates(self) -> Tuple[bool, str]:
        """屏蔽自动更新"""
        settings_path = self.find_cursor_settings_path()
        if not settings_path:
            return False, "未找到 Cursor 配置文件目录"
            
        try:
            # 确保目录存在
            settings_path.parent.mkdir(parents=True, exist_ok=True)

            # 读取现有配置
            settings = {}
            if settings_path.exists():
                try:
                    # 备份
                    backup_path = settings_path.with_suffix('.json.bak')
                    shutil.copy2(settings_path, backup_path)
                    
                    with open(settings_path, 'r', encoding='utf-8') as f:
                        settings = json.load(f)
                except json.JSONDecodeError:
                    settings = {}

            # 添加禁用更新配置
            settings['update.enableWindowsBackgroundUpdates'] = False
            settings['update.mode'] = 'none'
            
            # 写入配置
            with open(settings_path, 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=4, ensure_ascii=False)
                
            return True, "已成功屏蔽 Cursor 自动更新"
            
        except Exception as e:
            return False, f"屏蔽失败: {str(e)}"

    def unblock_updates(self) -> Tuple[bool, str]:
        """恢复自动更新"""
        settings_path = self.find_cursor_settings_path()
        if not settings_path or not settings_path.exists():
            return False, "未找到 Cursor 配置文件"
            
        try:
            with open(settings_path, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            
            # 移除配置
            changed = False
            if 'update.enableWindowsBackgroundUpdates' in settings:
                del settings['update.enableWindowsBackgroundUpdates']
                changed = True
            if 'update.mode' in settings:
                del settings['update.mode']
                changed = True
            
            if changed:
                with open(settings_path, 'w', encoding='utf-8') as f:
                    json.dump(settings, f, indent=4, ensure_ascii=False)
            
            return True, "已恢复 Cursor 自动更新"
            
        except Exception as e:
            return False, f"恢复失败: {str(e)}"
