#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
版本检查工具
"""

import requests
from PyQt6.QtCore import QThread, pyqtSignal

class VersionChecker(QThread):
    """版本检查线程"""
    finished = pyqtSignal(bool, str, str)  # success, latest_version, download_url
    
    def __init__(self, current_version: str, update_url: str = "https://vip.mzyota.icu/version.json"):
        super().__init__()
        self.current_version = current_version
        self.update_url = update_url
        
    def run(self):
        try:
            s = requests.Session()
            s.trust_env = False
            proxies = {"http": None, "https": None}
            headers = {"User-Agent": "CursorVIP-Unified/1.0.0"}
            urls = [self.update_url, self.update_url.replace("https://", "http://")]
            last_err = None
            for url in urls:
                try:
                    resp = s.get(url, timeout=8, verify=False, proxies=proxies, headers=headers)
                    if resp.status_code == 200:
                        data = resp.json()
                        latest_version = data.get("version", self.current_version)
                        download_url = data.get("url", "")
                        if self._compare_versions(latest_version, self.current_version) > 0:
                            self.finished.emit(True, latest_version, download_url)
                        else:
                            self.finished.emit(False, latest_version, "")
                        return
                    else:
                        last_err = f"HTTP {resp.status_code}"
                        continue
                except Exception as e:
                    last_err = e
                    continue
            self.finished.emit(False, "error", "network_unreachable")
        except Exception:
            self.finished.emit(False, "error", "network_unreachable")

    def _compare_versions(self, v1, v2):
        """比较版本号 v1 > v2 返回 1"""
        def parse(v):
            # 处理可能的 'v' 前缀
            v = v.lower().lstrip('v')
            return [int(x) for x in v.split('.')]
        
        try:
            p1 = parse(v1)
            p2 = parse(v2)
            # 简单的元组比较
            if p1 > p2:
                return 1
            elif p1 < p2:
                return -1
            else:
                return 0
        except:
            return 0
