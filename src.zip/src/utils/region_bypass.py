#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
突破地区限制工具类
"""

import os
import json
import platform
import requests
from pathlib import Path
from typing import Optional, Dict, Tuple

class RegionBypass:
    """Cursor 地区限制突破工具"""
    
    def __init__(self):
        self.cached_settings_path: Optional[Path] = None
        self.default_proxy_config = {
            "http.proxy": "socks5://xc999:xc123@154.201.91.204:38999",
            "http.systemCertificates": False,
            "http.proxySupport": "override",
            "http.experimental.systemCertificatesV2": False,
            "http.experimental.systemCertificates": False,
            "cursor.general.disableHttp2": True
        }
        # 需要管理的键值列表
        self.managed_keys = list(self.default_proxy_config.keys())

    def find_cursor_settings_path(self) -> Optional[Path]:
        """查找 Cursor settings.json 路径"""
        if self.cached_settings_path and self.cached_settings_path.exists():
            return self.cached_settings_path

        possible_paths = []
        home = Path.home()
        system = platform.system()

        # 1. 当前用户目录（优先级最高）
        if system == 'Windows':
            possible_paths.append(home / 'AppData' / 'Roaming' / 'Cursor' / 'User' / 'settings.json')
        elif system == 'Darwin': # macOS
            possible_paths.append(home / 'Library' / 'Application Support' / 'Cursor' / 'User' / 'settings.json')
        else: # Linux
            possible_paths.append(home / '.config' / 'Cursor' / 'User' / 'settings.json')

        # 2. 全盘搜索（仅 Windows）
        if system == 'Windows':
            # 获取所有驱动器
            drives = []
            for i in range(65, 91): # A-Z
                drive = f"{chr(i)}:\\"
                if os.path.exists(drive):
                    drives.append(drive)
            
            for drive in drives:
                users_dir = Path(drive) / 'Users'
                if users_dir.exists():
                    try:
                        for user_dir in users_dir.iterdir():
                            if user_dir.is_dir():
                                path = user_dir / 'AppData' / 'Roaming' / 'Cursor' / 'User' / 'settings.json'
                                possible_paths.append(path)
                    except Exception:
                        pass

        # 检查文件是否存在
        for path in possible_paths:
            try:
                if path.exists():
                    self.cached_settings_path = path
                    return path
            except Exception:
                continue
                
        return None

    def fetch_current_proxy_config(self) -> Optional[Dict]:
        """从后端获取最新代理配置"""
        url = 'https://www.xxdlzs.top/hou/csk/proxy-config/current'
        headers = {
            'xxcdndlzs': 'curs',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        try:
            response = requests.get(url, headers=headers, timeout=5)
            if response.status_code == 200:
                data = response.json()
                if data.get('success') and data.get('data'):
                    return data['data']
        except Exception as e:
            print(f"获取代理配置失败: {e}")
            
        return None

    def is_enabled(self) -> bool:
        """检查是否已开启"""
        settings_path = self.find_cursor_settings_path()
        if not settings_path:
            return False
            
        try:
            with open(settings_path, 'r', encoding='utf-8') as f:
                settings = json.load(f)
                
            # 检查关键配置是否存在且值匹配（或是我们的托管键）
            # 只要 http.proxy 存在且不为空，且 http.proxySupport 为 override，就认为是开启状态
            if settings.get('http.proxy') and settings.get('http.proxySupport') == 'override':
                return True
                
        except Exception:
            pass
            
        return False

    def enable(self) -> Tuple[bool, str]:
        """开启地区限制突破"""
        settings_path = self.find_cursor_settings_path()
        if not settings_path:
            return False, "未找到 Cursor 配置文件，请先运行一次 Cursor"
            
        try:
            # 1. 获取配置
            proxy_config = self.fetch_current_proxy_config()
            if not proxy_config:
                proxy_config = self.default_proxy_config
                print("使用默认代理配置")
            else:
                print("使用云端代理配置")

            # 2. 读取现有配置
            settings = {}
            if settings_path.exists():
                try:
                    with open(settings_path, 'r', encoding='utf-8') as f:
                        settings = json.load(f)
                except json.JSONDecodeError:
                    settings = {} # 文件损坏则重置

            # 3. 合并配置
            settings.update(proxy_config)
            
            # 4. 写入配置
            with open(settings_path, 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=4, ensure_ascii=False)
                
            return True, "已开启地区限制突破"
            
        except Exception as e:
            return False, f"开启失败: {str(e)}"

    def disable(self) -> Tuple[bool, str]:
        """关闭地区限制突破"""
        settings_path = self.find_cursor_settings_path()
        if not settings_path:
            return False, "未找到 Cursor 配置文件"
            
        try:
            # 1. 读取现有配置
            if not settings_path.exists():
                return True, "配置文件不存在，无需关闭"
                
            with open(settings_path, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            
            # 2. 移除相关配置
            # 移除我们管理的所有键
            changed = False
            for key in self.managed_keys:
                if key in settings:
                    del settings[key]
                    changed = True
            
            # 3. 写入配置
            if changed:
                with open(settings_path, 'w', encoding='utf-8') as f:
                    json.dump(settings, f, indent=4, ensure_ascii=False)
            
            return True, "已关闭地区限制突破"
            
        except Exception as e:
            return False, f"关闭失败: {str(e)}"
