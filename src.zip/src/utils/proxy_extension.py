# -*- coding: utf-8 -*-
import os
import zipfile

def create_proxy_auth_extension(proxy_host, proxy_port, proxy_user, proxy_pass, plugin_path):
    """
    创建一个 Chrome 插件用于代理认证 (Manifest V2)
    仅负责认证，代理服务器设置通过命令行参数传入
    """
    manifest_json = """
    {
        "version": "1.0.0",
        "manifest_version": 2,
        "name": "Chrome Proxy Auth",
        "permissions": [
            "tabs",
            "unlimitedStorage",
            "storage",
            "<all_urls>",
            "webRequest",
            "webRequestBlocking"
        ],
        "background": {
            "scripts": ["background.js"]
        },
        "minimum_chrome_version": "22.0.0"
    }
    """

    # 恢复 chrome.proxy.settings.set，由插件全权接管代理设置和认证
    background_js = """
    var config = {
            mode: "fixed_servers",
            rules: {
              singleProxy: {
                scheme: "http",
                host: "%s",
                port: parseInt(%s)
              },
              bypassList: ["localhost"]
            }
          };

    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

    function callbackFn(details) {
        return {
            authCredentials: {
                username: "%s",
                password: "%s"
            }
        };
    }

    chrome.webRequest.onAuthRequired.addListener(
                callbackFn,
                {urls: ["<all_urls>"]},
                ['blocking']
    );
    """ % (proxy_host, proxy_port, proxy_user, proxy_pass)



    import zipfile
    import shutil
    
    # 确保是文件夹路径，不是 zip 文件
    if plugin_path.endswith('.zip'):
        folder_path = plugin_path[:-4]
    else:
        folder_path = plugin_path

    # 清理旧文件
    if os.path.exists(folder_path):
        try:
            shutil.rmtree(folder_path)
        except:
            pass
    os.makedirs(folder_path, exist_ok=True)

    with open(os.path.join(folder_path, "manifest.json"), 'w', encoding='utf-8') as f:
        f.write(manifest_json)
    
    with open(os.path.join(folder_path, "background.js"), 'w', encoding='utf-8') as f:
        f.write(background_js)

    return folder_path
