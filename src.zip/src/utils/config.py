#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
配置管理模块
"""

import json
import os
from pathlib import Path
from typing import Dict, Any, Optional
from dataclasses import dataclass, asdict


@dataclass
class EmailConfig:
    """邮箱配置"""
    mode: str = "tempmail"  # "tempmail" or "imap"
    domain: str = "mzyota"    # 域名选择: "mzyota", "yefota", "gotool", "custom"
    tempmail_service: str = "tempmail.plus"
    tempmail_email: str = ""
    tempmail_pin: str = ""
    imap_server: str = ""
    imap_port: int = 993
    imap_username: str = ""
    imap_password: str = ""
    imap_folder: str = "INBOX"
    use_ssl: bool = True
    # 自定义域名配置
    custom_imap_server: str = ""
    custom_main_email: str = ""
    custom_password: str = ""
    custom_pattern: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'EmailConfig':
        return cls(**data)


@dataclass
class AuthConfig:
    """认证配置"""
    server_url: str = "https://vip.mzyota.icu"
    api_key: str = ""
    timeout: int = 15000
    offline_days: int = 7
    bypass_proxy: bool = True  # 是否绕过系统代理


@dataclass
class UIConfig:
    """UI配置"""
    theme: str = "dark"
    language: str = "zh_CN"
    window_width: int = 1200
    window_height: int = 800
    enable_animations: bool = True
    font_size: int = 10


@dataclass
class SystemConfig:
    """系统配置"""
    auto_start: bool = False
    minimize_to_tray: bool = True
    check_updates: bool = True
    log_level: str = "INFO"
    max_log_files: int = 10
    max_log_size: int = 10 * 1024 * 1024  # 10MB
    cursor_path: str = ""  # 用户自定义 Cursor 路径
    update_url: str = "https://vip.mzyota.icu/version.json"  # 更新检查地址


@dataclass
class PhoneConfig:
    """手机验证配置"""
    enabled: bool = False  # 是否启用自动接码
    provider: str = "haozhuma"  # 默认接码平台
    selected_project: str = ""  # 选中的项目 (P1, P2 等)
    api_key: str = ""  # API Key (如果需要)
    sid_map: Dict[str, int] = None  # 项目ID映射，如 {"P1": 1001, "P2": 1002}
    max_attempts: int = 5  # 最大尝试次数
    poll_interval: int = 5  # 轮询间隔(秒)
    poll_timeout: int = 180 # 超时时间(秒)
    user: str = "" # 平台用户名
    password: str = "" # 平台密码
    server_urls: list = None # 自定义API地址列表

    def __post_init__(self):
        if self.sid_map is None:
            self.sid_map = {}
        if self.server_urls is None:
            self.server_urls = []

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class ConfigManager:
    """配置管理器"""

    def __init__(self, config_dir: Optional[Path] = None):
        """
        初始化配置管理器
        
        Args:
            config_dir: 配置目录，默认为用户目录下的.cursor-vip-unified
        """
        import sys
        if config_dir is None:
            env_dir = os.environ.get('CURSORPM_DATA_DIR', '').strip()
            if env_dir:
                config_dir = Path(env_dir)
            else:
                from utils.app_paths import get_app_data_dir
                config_dir = get_app_data_dir()

        self.config_dir = config_dir
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.config_file = self.config_dir / 'config.json'

        # 初始化配置
        self.email_config = EmailConfig()
        self.auth_config = AuthConfig()
        self.ui_config = UIConfig()
        self.system_config = SystemConfig()
        self.sms_config = PhoneConfig()  # 新增 sms_config

        # 加载配置
        self.load_config()

    @property
    def config(self) -> Dict[str, Any]:
        """获取完整配置字典 (兼容 BackendAPI)"""
        return {
            'email': self.email_config.to_dict(),
            'auth': asdict(self.auth_config),
            'ui': asdict(self.ui_config),
            'system': asdict(self.system_config),
            'phone_verification': self.sms_config.to_dict()  # 导出为 phone_verification
        }

    def load_config(self):
        """加载配置文件"""
        try:
            if self.config_file.exists():
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)

                # 加载各个配置模块
                if 'email' in data:
                    self.email_config = EmailConfig.from_dict(data['email'])
                if 'auth' in data:
                    self.auth_config = AuthConfig(**data['auth'])
                if 'ui' in data:
                    self.ui_config = UIConfig(**data['ui'])
                if 'system' in data:
                    self.system_config = SystemConfig(**data['system'])
                # 加载手机验证配置 (兼容 phone_verification 键名)
                if 'phone_verification' in data:
                    self.sms_config = PhoneConfig(**data['phone_verification'])
                elif 'sms' in data: # 兼容旧键名
                    self.sms_config = PhoneConfig(**data['sms'])

        except Exception as e:
            print(f"加载配置文件失败: {e}")

    def save_config(self):
        """保存配置文件"""
        try:
            config_data = {
                'email': self.email_config.to_dict(),
                'auth': asdict(self.auth_config),
                'ui': asdict(self.ui_config),
                'system': asdict(self.system_config),
                'phone_verification': self.sms_config.to_dict()
            }

            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(config_data, f, indent=2, ensure_ascii=False)

        except Exception as e:
            print(f"保存配置文件失败: {e}")

    def get_email_config(self) -> EmailConfig:
        """获取邮箱配置"""
        return self.email_config

    def set_email_config(self, config: EmailConfig):
        """设置邮箱配置"""
        self.email_config = config
        self.save_config()

    def get_auth_config(self) -> AuthConfig:
        """获取认证配置"""
        return self.auth_config

    def set_auth_config(self, config: AuthConfig):
        """设置认证配置"""
        self.auth_config = config
        self.save_config()

    def get_ui_config(self) -> UIConfig:
        """获取UI配置"""
        return self.ui_config

    def set_ui_config(self, config: UIConfig):
        """设置UI配置"""
        self.ui_config = config
        self.save_config()

    def get_system_config(self) -> SystemConfig:
        """获取系统配置"""
        return self.system_config

    def set_system_config(self, config: SystemConfig):
        """设置系统配置"""
        self.system_config = config
        self.save_config()

    def get_data_dir(self) -> Path:
        """获取数据目录"""
        data_dir = self.config_dir / 'data'
        data_dir.mkdir(exist_ok=True)
        return data_dir

    def get_logs_dir(self) -> Path:
        """获取日志目录"""
        logs_dir = self.config_dir / 'logs'
        logs_dir.mkdir(exist_ok=True)
        return logs_dir

    def get_cache_dir(self) -> Path:
        """获取缓存目录"""
        cache_dir = self.config_dir / 'cache'
        cache_dir.mkdir(exist_ok=True)
        return cache_dir
