#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
许可证验证模块
处理许可证的生成、验证和管理
"""

import json
import time
import uuid
import platform
import requests
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, Tuple, Optional

from utils.crypto import get_crypto_manager
from utils.logger import LoggerMixin
from utils.config import ConfigManager


class LicenseValidator(LoggerMixin):
    """许可证验证器"""

    def __init__(self, config_manager: ConfigManager):
        """
        初始化许可证验证器

        Args:
            config_manager: 配置管理器
        """
        self.config_manager = config_manager
        self.crypto = get_crypto_manager()
        self.machine_id = self._get_machine_id()
        self.license_file = config_manager.config_dir / 'license.dat'
        
        # 加载公钥
        try:
            pub_key_path = Path(__file__).parent / 'public_key.pem'
            if pub_key_path.exists():
                with open(pub_key_path, 'rb') as f:
                    self.public_key = f.read()
            else:
                self.public_key = None
                self.logger.warning("RSA Public Key not found. Signature verification disabled.")
        except Exception as e:
            self.public_key = None
            self.logger.error(f"Failed to load RSA Public Key: {e}")

    def _get_machine_id(self) -> str:
        """获取机器唯一标识"""
        try:
            # 收集硬件信息
            info = ""
            info += platform.node()  # 计算机名称
            info += str(uuid.getnode())  # MAC地址
            info += platform.machine()  # 处理器架构
            info += platform.system()  # 操作系统

            # 生成哈希
            import hashlib
            return hashlib.sha256(info.encode('utf-8')).hexdigest()[:32].upper()

        except Exception:
            # 备用方案
            return str(uuid.uuid4()).replace('-', '').upper()[:32]

    def check_local_license(self) -> Tuple[bool, Optional[Dict[str, Any]]]:
        """
        检查本地许可证

        Returns:
            Tuple[bool, Optional[Dict]]: (是否有效, 许可证数据)
        """
        try:
            if not self.license_file.exists():
                self.logger.info("未找到许可证文件")
                return False, None

            # 读取并解密许可证
            with open(self.license_file, 'r', encoding='utf-8') as f:
                encrypted_data = f.read().strip()

            if not encrypted_data:
                self.logger.warning("许可证文件为空")
                return False, None

            # 解密
            decrypted_data = self.crypto.decrypt(encrypted_data)
            license_data = json.loads(decrypted_data)

            # 验证机器码
            if license_data.get('machine_id') != self.machine_id:
                self.logger.warning("许可证机器码不匹配")
                return False, None

            # 验证数字签名 (如果有公钥)
            if self.public_key:
                print("DEBUG: Verifying signature...")
                signature = license_data.get('signature')
                if not signature:
                    print("DEBUG: Missing signature in license data")
                    self.logger.warning("许可证缺少数字签名")
                    return False, {'error': 'missing_signature'}
                
                # 构造验证数据 (必须与服务端签名时的顺序和格式完全一致)
                verify_payload = {
                    'machine_id': license_data.get('machine_id'),
                    'expires_at': license_data.get('expires_at'),
                    'plan': license_data.get('plan', 'premium'),
                    'days': license_data.get('days', 30)
                }
                # Node.js JSON.stringify 默认不带空格
                verify_data = json.dumps(verify_payload, separators=(',', ':'))
                
                if not self.crypto.verify_signature(verify_data, signature, self.public_key):
                    print("DEBUG: Signature verification failed! Data tampered!")
                    self.logger.error("许可证数字签名验证失败，数据可能已被篡改！")
                    return False, {'error': 'invalid_signature'}
                
                print("DEBUG: Signature verified successfully.")

            # 检查过期时间
            expires_at = datetime.fromisoformat(license_data['expires_at'])
            
            # 使用 UTC 时间进行比较，避免本地时区转换错误
            from datetime import timezone
            now = datetime.now(timezone.utc)
            
            # 如果 expires_at 没有时区信息，假定它是 UTC
            if expires_at.tzinfo is None:
                expires_at = expires_at.replace(tzinfo=timezone.utc)

            # 调试日志：显示当前时间和过期时间
            self.logger.info(f"Checking expiration: Now(UTC)={now}, ExpiresAt={expires_at}")

            if now >= expires_at:
                self.logger.info(f"许可证已过期: {expires_at}")
                # 删除过期许可证
                self.license_file.unlink(missing_ok=True)
                return False, {'expired': True, 'expires_at': license_data['expires_at']}

            self.logger.info(f"本地许可证有效，过期时间: {expires_at}")
            return True, license_data

        except Exception as e:
            self.logger.error(f"检查本地许可证失败: {e}")
            return False, None

    def validate_license_online(self, license_key: str) -> Tuple[bool, Dict[str, Any]]:
        """
        在线验证许可证

        Args:
            license_key: 许可证密钥

        Returns:
            Tuple[bool, Dict]: (是否成功, 响应数据)
        """
        try:
            auth_config = self.config_manager.get_auth_config()

            payload = {
                'license_key': license_key,
                'machine_id': self.machine_id,
                'client_time': datetime.now().isoformat(),
                'client_version': '1.0.0',
                'platform': platform.system().lower()
            }

            headers = {
                'Content-Type': 'application/json',
                'User-Agent': 'CursorVIP-Unified/1.0.0'
            }

            # 如果有API密钥，添加到请求头
            if auth_config.api_key:
                headers['Authorization'] = f'Bearer {auth_config.api_key}'

            self.logger.info("正在进行在线许可证验证...")

            # 根据配置决定是否绕过代理
            proxies = None
            if auth_config.bypass_proxy:
                proxies = {
                    "http": None,
                    "https": None
                }

            response = requests.post(
                f"{auth_config.server_url}/api/validate-license",
                json=payload,
                headers=headers,
                timeout=auth_config.timeout / 1000,  # 转换为秒
                proxies=proxies # 绕过系统代理(如果配置开启)
            )

            if response.status_code == 200:
                result = response.json()
                if result.get('success'):
                    self.logger.info("在线验证成功")
                    return True, result
                else:
                    self.logger.warning(f"验证失败: {result.get('message', '未知错误')}")
                    return False, result
            else:
                self.logger.error(f"HTTP错误: {response.status_code}")
                return False, {'error': f'HTTP {response.status_code}'}

        except requests.exceptions.RequestException as e:
            self.logger.error(f"网络请求失败: {e}")
            return False, {'error': 'network_error', 'message': str(e)}
        except Exception as e:
            self.logger.error(f"在线验证异常: {e}")
            return False, {'error': 'unknown_error', 'message': str(e)}

    def activate_license(self, license_key: str) -> Tuple[bool, Dict[str, Any]]:
        """
        激活许可证

        Args:
            license_key: 许可证密钥

        Returns:
            Tuple[bool, Dict]: (是否成功, 结果信息)
        """
        try:
            # 首先进行格式验证
            if not self._validate_license_format(license_key):
                return False, {'error': 'invalid_format', 'message': '许可证格式无效'}

            # 在线验证
            success, result = self.validate_license_online(license_key)

            if success:
                # 生成本地许可证文件
                expires_at = result.get('expires_at')
                license_data = result.get('license_data', {})

                local_license = {
                    'license_key': license_key,
                    'machine_id': self.machine_id,
                    'issued_at': datetime.now().isoformat(),
                    'expires_at': expires_at,
                    'plan': license_data.get('plan', 'premium'),  # 保存 plan 字段
                    'days': license_data.get('days', 30),
                    'server_validated': True,
                    'last_verify_time': datetime.now().isoformat(),
                    'signature': result.get('signature')  # 保存服务器返回的签名
                }

                # 加密并保存
                encrypted_data = self.crypto.encrypt(json.dumps(local_license))

                with open(self.license_file, 'w', encoding='utf-8') as f:
                    f.write(encrypted_data)

                self.logger.info(f"许可证激活成功，过期时间: {expires_at}")
                return True, {
                    'expires_at': expires_at,
                    'days': local_license['days'],
                    'message': '激活成功'
                }

            else:
                return False, result

        except Exception as e:
            self.logger.error(f"激活许可证失败: {e}")
            return False, {'error': 'activation_failed', 'message': str(e)}

    def verify_license_online(self, license_key: str = None) -> Tuple[bool, Dict[str, Any]]:
        """
        在线校验许可证状态

        Args:
            license_key: 许可证密钥（可选，从本地读取）

        Returns:
            Tuple[bool, Dict]: (是否成功, 状态信息)
        """
        try:
            # 获取本地许可证信息
            is_valid, local_data = self.check_local_license()
            if not is_valid:
                return False, {'error': 'no_valid_license'}

            license_key = license_key or local_data.get('license_key')
            if not license_key:
                return False, {'error': 'no_license_key'}

            auth_config = self.config_manager.get_auth_config()

            payload = {
                'license_key': license_key,
                'machine_id': self.machine_id,
                'client_time': datetime.now().isoformat(),
                'last_verify_time': local_data.get('last_verify_time')
            }

            headers = {
                'Content-Type': 'application/json',
                'User-Agent': 'CursorVIP-Unified/1.0.0'
            }

            if auth_config.api_key:
                headers['Authorization'] = f'Bearer {auth_config.api_key}'

            # 根据配置决定是否绕过代理
            proxies = None
            if auth_config.bypass_proxy:
                proxies = {
                    "http": None,
                    "https": None
                }

            response = requests.post(
                f"{auth_config.server_url}/api/verify-online",
                json=payload,
                headers=headers,
                timeout=auth_config.timeout / 1000,
                proxies=proxies
            )

            if response.status_code == 200:
                result = response.json()
                if result.get('success'):
                    # 更新本地许可证的验证时间
                    if local_data:
                        local_data['last_verify_time'] = datetime.now().isoformat()
                        # 更新签名 (如果服务器返回了新的)
                        if result.get('signature'):
                            local_data['signature'] = result.get('signature')
                            
                        encrypted_data = self.crypto.encrypt(json.dumps(local_data))
                        with open(self.license_file, 'w', encoding='utf-8') as f:
                            f.write(encrypted_data)

                    return True, result
                else:
                    # 服务端明确拒绝（如授权码不存在、已过期、机器码不匹配等）
                    self.logger.warning(f"在线校验被拒绝: {result.get('message', '未知原因')} - 正在清除本地无效授权")
                    self.license_file.unlink(missing_ok=True)
                    return False, result
            else:
                return False, {'error': f'http_{response.status_code}'}

        except Exception as e:
            self.logger.error(f"在线校验失败: {e}")
            return False, {'error': 'verify_failed', 'message': str(e)}

    def get_license_info(self) -> Optional[Dict[str, Any]]:
        """获取许可证信息"""
        is_valid, data = self.check_local_license()
        return data if is_valid else None

    def is_license_expired(self) -> bool:
        """检查许可证是否过期"""
        is_valid, data = self.check_local_license()
        return not is_valid and data and data.get('expired')

    def get_remaining_days(self) -> int:
        """获取剩余天数"""
        is_valid, data = self.check_local_license()
        if not is_valid or not data:
            return 0

        expires_at = datetime.fromisoformat(data['expires_at'])
        remaining = expires_at - datetime.now()
        return max(0, remaining.days)

    def _validate_license_format(self, license_key: str) -> bool:
        """
        验证许可证格式

        Args:
            license_key: 许可证密钥

        Returns:
            bool: 是否有效
        """
        import re

        # 支持的格式
        patterns = [
            r'^VIP\d+[DHMS]-[A-Z0-9]{5,}$', # VIP7D-..., VIP1M-..., VIP1H-... (支持天/时/分/秒)
            r'^VIP\d+[DHMS]_[A-Z0-9]{5,}$', # VIP7D_..., VIP1M_...
            r'^VIP-YEAR-[A-Z0-9]{5,}$',     # VIP-YEAR-XXXXX
            r'^VIP-TEST-[A-Z0-9]{5,}$',     # VIP-TEST-XXXXX
        ]

        license_key = license_key.upper().strip()

        for pattern in patterns:
            if re.match(pattern, license_key):
                return True

        return False
