#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
加密工具模块
提供AES加密解密功能，用于保护敏感数据
"""

import base64
import hashlib
import os
import json
from cryptography.hazmat.primitives import padding, serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding as asym_padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend


class CryptoManager:
    """加密管理器"""

    def __init__(self, key: str = None):
        """
        初始化加密管理器

        Args:
            key: 加密密钥，如果不提供则使用机器码生成
        """
        if key is None:
            key = self._generate_machine_key()

        # 确保密钥长度为32字节 (AES-256)
        self.key = self._derive_key(key.encode('utf-8'))

    def _generate_machine_key(self) -> str:
        """生成基于机器信息的密钥"""
        try:
            import platform
            import uuid

            # 收集机器信息
            machine_info = ""
            machine_info += platform.node()  # 计算机名称
            machine_info += str(uuid.getnode())  # MAC地址
            machine_info += platform.machine()  # 处理器架构
            machine_info += platform.system()  # 操作系统

            # 生成哈希作为密钥基础
            return hashlib.sha256(machine_info.encode('utf-8')).hexdigest()[:32]

        except Exception:
            # 备用方案：使用随机密钥
            return base64.b64encode(os.urandom(32)).decode('utf-8')

    def _derive_key(self, key: bytes) -> bytes:
        """派生密钥到正确的长度"""
        # 使用PBKDF2派生32字节密钥
        import hashlib

        salt = b'cursor_vip_salt_2024'  # 固定盐值
        derived_key = hashlib.pbkdf2_hmac(
            'sha256',
            key,
            salt,
            100000,  # 迭代次数
            dklen=32  # 32字节 = 256位
        )
        return derived_key

    def encrypt(self, plaintext: str) -> str:
        """
        加密字符串

        Args:
            plaintext: 明文字符串

        Returns:
            str: Base64编码的密文
        """
        try:
            # 转换为字节
            data = plaintext.encode('utf-8')

            # 生成随机IV (16字节 for AES)
            iv = os.urandom(16)

            # 创建密码器
            cipher = Cipher(
                algorithms.AES(self.key),
                modes.CBC(iv),
                backend=default_backend()
            )
            encryptor = cipher.encryptor()

            # 填充数据
            padder = padding.PKCS7(algorithms.AES.block_size).padder()
            padded_data = padder.update(data) + padder.finalize()

            # 加密
            ciphertext = encryptor.update(padded_data) + encryptor.finalize()

            # 组合IV和密文，然后Base64编码
            encrypted_data = iv + ciphertext
            return base64.b64encode(encrypted_data).decode('utf-8')

        except Exception as e:
            raise Exception(f"加密失败: {str(e)}")

    def decrypt(self, ciphertext: str) -> str:
        """
        解密字符串

        Args:
            ciphertext: Base64编码的密文

        Returns:
            str: 明文字符串
        """
        try:
            # Base64解码
            encrypted_data = base64.b64decode(ciphertext)

            # 分离IV和密文
            iv = encrypted_data[:16]
            ciphertext_data = encrypted_data[16:]

            # 创建解密器
            cipher = Cipher(
                algorithms.AES(self.key),
                modes.CBC(iv),
                backend=default_backend()
            )
            decryptor = cipher.decryptor()

            # 解密
            padded_plaintext = decryptor.update(ciphertext_data) + decryptor.finalize()

            # 去除填充
            unpadder = padding.PKCS7(algorithms.AES.block_size).unpadder()
            plaintext = unpadder.update(padded_plaintext) + unpadder.finalize()

            # 转换为字符串
            return plaintext.decode('utf-8')

        except Exception as e:
            raise Exception(f"解密失败: {str(e)}")

    def hash_string(self, text: str) -> str:
        """
        对字符串进行哈希 (用于密码等不可逆加密)

        Args:
            text: 待哈希字符串

        Returns:
            str: 哈希值
        """
        return hashlib.sha256(text.encode('utf-8')).hexdigest()

    def verify_hash(self, text: str, hash_value: str) -> bool:
        """
        验证哈希值

        Args:
            text: 原始字符串
            hash_value: 哈希值

        Returns:
            bool: 是否匹配
        """
        return self.hash_string(text) == hash_value

    def verify_signature(self, data: str, signature: str, public_key_pem: bytes) -> bool:
        """
        验证RSA数字签名

        Args:
            data: 原始数据（字符串，将被JSON序列化后验证）
            signature: Base64编码的签名
            public_key_pem: PEM格式的公钥

        Returns:
            bool: 签名是否有效
        """
        try:
            if not signature or not public_key_pem:
                return False

            # 加载公钥
            public_key = serialization.load_pem_public_key(
                public_key_pem,
                backend=default_backend()
            )

            # 解码签名
            signature_bytes = base64.b64decode(signature)
            data_bytes = data.encode('utf-8')

            # 验证
            public_key.verify(
                signature_bytes,
                data_bytes,
                asym_padding.PKCS1v15(),
                hashes.SHA256()
            )
            return True
        except Exception as e:
            # print(f"Signature verification failed: {e}")
            return False



# 全局实例
_crypto_manager = None

def get_crypto_manager() -> CryptoManager:
    """获取全局加密管理器实例"""
    global _crypto_manager
    if _crypto_manager is None:
        _crypto_manager = CryptoManager()
    return _crypto_manager
