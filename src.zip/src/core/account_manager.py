#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
账户管理池核心模块
管理账户的增删改查、状态监控、切换等功能
"""

import sqlite3
import json
import threading
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, asdict, field

from utils.logger import LoggerMixin
from utils.crypto import get_crypto_manager
from utils.config import ConfigManager


@dataclass
class AccountInfo:
    """账户信息数据类"""
    id: int = 0
    email: str = ""
    password: Optional[str] = None
    access_token: Optional[str] = None
    refresh_token: Optional[str] = None
    session_token: Optional[str] = None
    user_id: Optional[str] = None
    membership_type: str = 'free'
    days_remaining: int = 0
    usage_percent: float = 0.0
    used: int = 0
    limit_value: int = 1000
    created_at: str = ""
    last_used: Optional[str] = None
    last_refreshed: Optional[str] = None
    status: str = 'active'
    notes: Optional[str] = None
    db_path: Optional[str] = None
    token_format: Optional[str] = None
    detected_at: Optional[str] = None
    register_type: str = 'manual'  # 'manual' or 'auto'
    email_config: Optional[Dict[str, Any]] = None  # 邮箱配置信息
    token_consumption: Dict[str, Any] = field(default_factory=dict)  # Token消耗统计

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        data = asdict(self)
        # 清理None值
        return {k: v for k, v in data.items() if v is not None}

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AccountInfo':
        """从字典创建AccountInfo实例"""
        # 过滤掉不在 dataclass 字段中的 key
        valid_keys = cls.__dataclass_fields__.keys()
        filtered_data = {k: v for k, v in data.items() if k in valid_keys}
        
        # 处理默认值
        if 'token_consumption' not in filtered_data:
            filtered_data['token_consumption'] = {}
        if 'email_config' not in filtered_data:
            filtered_data['email_config'] = None
            
        return cls(**filtered_data)

    def is_token_valid(self) -> bool:
        """检查Token是否有效"""
        if not self.access_token:
            return False

        try:
            import jwt
            # 解析JWT Token
            jwt_token = self.access_token
            # 处理 Session Token 格式 (user_xxx::jwt)
            if "::" in self.access_token:
                parts = self.access_token.split("::")
                if len(parts) > 1:
                    jwt_token = parts[1]
            elif self.access_token.startswith('user_'):
                # 尝试提取 JWT
                import re
                match = re.search(r'(eyJ[\w-]*\.eyJ[\w-]*\.[\w-]*)', self.access_token)
                if match:
                    jwt_token = match.group(1)

            payload = jwt.decode(jwt_token, options={"verify_signature": False})
            exp = payload.get('exp')
            if exp:
                # 检查是否过期 (留5分钟缓冲)
                return datetime.now().timestamp() < (exp - 300)
        except:
            pass
        return False

    def get_subscription_status(self) -> Dict[str, Any]:
        """获取订阅状态信息"""
        return {
            'type': self.membership_type,
            'days_remaining': self.days_remaining,
            'usage_percent': self.usage_percent,
            'used': self.used,
            'limit': self.limit_value,
            'is_pro': self.membership_type in ['pro', 'pro_plus'],
            'is_expired': self.days_remaining <= 0
        }

    def get_token_info(self) -> Dict[str, Any]:
        """获取Token详细信息"""
        token_type = 'unknown'
        try:
            import jwt
            payload = jwt.decode(self.access_token, options={"verify_signature": False})
            token_type = payload.get('type', 'unknown')
        except:
            pass

        return {
            'has_access_token': bool(self.access_token),
            'has_refresh_token': bool(self.refresh_token),
            'has_session_token': bool(self.session_token),
            'token_valid': self.is_token_valid(),
            'token_type': token_type,
            'token_format': self.token_format,
            'last_refreshed': self.last_refreshed
        }

    def get_consumption_info(self) -> Dict[str, Any]:
        """获取消耗统计信息"""
        consumption = self.token_consumption or {}
        return {
            'total_used': consumption.get('total_used', 0),
            'monthly_used': consumption.get('monthly_used', 0),
            'daily_used': consumption.get('daily_used', 0),
            'last_updated': consumption.get('last_updated'),
            'usage_trend': consumption.get('usage_trend', [])
        }


class AccountStorage(LoggerMixin):
    """账户存储管理器"""

    def __init__(self, db_path: Optional[Path] = None):
        """
        初始化账户存储

        Args:
            db_path: 数据库文件路径
        """
        if db_path is None:
            config_manager = ConfigManager()
            db_path = config_manager.get_data_dir() / 'accounts.db'

        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.crypto = get_crypto_manager()
        self._lock = threading.Lock()

        self._init_database()

    def _init_database(self):
        """初始化数据库表"""
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()

            # 创建账户表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS accounts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    email TEXT UNIQUE NOT NULL,
                    password TEXT,
                    access_token TEXT,
                    refresh_token TEXT,
                    session_token TEXT,
                    user_id TEXT,
                    membership_type TEXT DEFAULT 'free',
                    days_remaining INTEGER DEFAULT 0,
                    usage_percent REAL DEFAULT 0.0,
                    used INTEGER DEFAULT 0,
                    limit_value INTEGER DEFAULT 1000,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_used TIMESTAMP,
                    last_refreshed TIMESTAMP,
                    status TEXT DEFAULT 'active',
                    notes TEXT,
                    db_path TEXT,
                    token_format TEXT,
                    detected_at TIMESTAMP,
                    register_type TEXT DEFAULT 'manual',
                    email_config TEXT,
                    token_consumption TEXT
                )
            ''')

            conn.commit()
            conn.close()

    def _get_connection(self) -> sqlite3.Connection:
        """获取数据库连接"""
        return sqlite3.connect(str(self.db_path))

    def save_account(self, account_data: Dict[str, Any]) -> int:
        """
        保存账户信息

        Args:
            account_data: 账户数据字典

        Returns:
            int: 保存成功返回账户ID，失败返回-1
        """
        try:
            with self._lock:
                conn = self._get_connection()
                cursor = conn.cursor()

                # 准备数据
                data = account_data.copy()

                # 序列化复杂对象
                if 'email_config' in data and data['email_config']:
                    data['email_config'] = json.dumps(data['email_config'])
                if 'token_consumption' in data and data['token_consumption']:
                    data['token_consumption'] = json.dumps(data['token_consumption'])

                # 首先检查邮箱是否已存在
                cursor.execute('SELECT id FROM accounts WHERE email = ?', (data.get('email'),))
                existing_row = cursor.fetchone()

                if existing_row:
                    # 邮箱已存在，更新现有记录
                    existing_id = existing_row[0]
                    update_columns = [col for col in data.keys() if col != 'id']
                    set_clause = ', '.join([f'{col} = ?' for col in update_columns])

                    update_values = []
                    for col in update_columns:
                        val = data[col]
                        if isinstance(val, (dict, list)):
                            update_values.append(json.dumps(val))
                        else:
                            update_values.append(val)

                    cursor.execute(f'UPDATE accounts SET {set_clause} WHERE id = ?', update_values + [existing_id])
                    last_id = existing_id
                else:
                    # 邮箱不存在，插入新记录（排除id字段，让SQLite自动分配）
                    insert_columns = [col for col in data.keys() if col != 'id']
                    columns = ', '.join(insert_columns)
                    placeholders = ', '.join(['?' for _ in insert_columns])

                    # 转换所有值为基本类型
                    values = []
                    for col in insert_columns:
                        val = data[col]
                        if isinstance(val, (dict, list)):
                            values.append(json.dumps(val))
                        else:
                            values.append(val)

                    sql = f'INSERT INTO accounts ({columns}) VALUES ({placeholders})'
                    cursor.execute(sql, values)
                    last_id = cursor.lastrowid
                    
                conn.commit()

                self.logger.info(f"账户保存成功: {data.get('email', 'unknown')} (ID: {last_id})")
                return last_id

        except Exception as e:
            self.logger.error(f"保存账户失败: {e}")
            return -1
        finally:
            if 'conn' in locals():
                conn.close()

    def get_account(self, account_id: int) -> Optional[Dict[str, Any]]:
        """
        获取账户信息

        Args:
            account_id: 账户ID

        Returns:
            Optional[Dict]: 账户数据
        """
        try:
            conn = self._get_connection()
            cursor = conn.cursor()

            cursor.execute('SELECT * FROM accounts WHERE id = ?', (account_id,))
            row = cursor.fetchone()

            if not row:
                return None

            # 获取列名
            columns = [desc[0] for desc in cursor.description]

            # 构建字典
            data = dict(zip(columns, row))

            # 反序列化复杂对象
            if data.get('email_config'):
                data['email_config'] = json.loads(data['email_config'])
            if data.get('token_consumption'):
                data['token_consumption'] = json.loads(data['token_consumption'])

            return data

        except Exception as e:
            self.logger.error(f"获取账户失败: {e}")
            return None
        finally:
            if 'conn' in locals():
                conn.close()

    def get_all_accounts(self) -> List[Dict[str, Any]]:
        """
        获取所有账户

        Returns:
            List[Dict]: 账户列表
        """
        try:
            conn = self._get_connection()
            cursor = conn.cursor()

            cursor.execute('SELECT * FROM accounts ORDER BY last_used DESC, created_at DESC')
            rows = cursor.fetchall()

            columns = [desc[0] for desc in cursor.description]
            accounts = []

            for row in rows:
                data = dict(zip(columns, row))

                # 反序列化复杂对象
                try:
                    if data.get('email_config'):
                        data['email_config'] = json.loads(data['email_config'])
                    if data.get('token_consumption'):
                        data['token_consumption'] = json.loads(data['token_consumption'])
                except json.JSONDecodeError:
                    pass  # 忽略解析错误

                accounts.append(data)

            return accounts

        except Exception as e:
            self.logger.error(f"获取所有账户失败: {e}")
            return []
        finally:
            if 'conn' in locals():
                conn.close()

    def update_account(self, account_id: int, updates: Dict[str, Any]) -> bool:
        """
        更新账户信息

        Args:
            account_id: 账户ID
            updates: 更新数据

        Returns:
            bool: 是否更新成功
        """
        try:
            with self._lock:
                conn = self._get_connection()
                cursor = conn.cursor()

                # 序列化复杂对象
                data = updates.copy()
                
                # 构建更新SQL
                set_parts = [f"{k} = ?" for k in data.keys()]
                
                # 转换所有值为基本类型
                values = []
                for val in data.values():
                    if isinstance(val, (dict, list)):
                        values.append(json.dumps(val))
                    else:
                        values.append(val)
                
                values.append(account_id)  # 最后加上WHERE条件的值

                sql = f"UPDATE accounts SET {', '.join(set_parts)} WHERE id = ?"
                cursor.execute(sql, values)
                conn.commit()

                self.logger.info(f"账户更新成功: ID {account_id}")
                return True

        except Exception as e:
            self.logger.error(f"更新账户失败: {e}")
            return False
        finally:
            if 'conn' in locals():
                conn.close()

    def delete_account(self, account_id: int) -> bool:
        """
        删除账户

        Args:
            account_id: 账户ID

        Returns:
            bool: 是否删除成功
        """
        try:
            with self._lock:
                conn = self._get_connection()
                cursor = conn.cursor()

                cursor.execute('DELETE FROM accounts WHERE id = ?', (account_id,))
                conn.commit()

                self.logger.info(f"账户删除成功: ID {account_id}")
                return True

        except Exception as e:
            self.logger.error(f"删除账户失败: {e}")
            return False
        finally:
            if 'conn' in locals():
                conn.close()

    def get_accounts_by_status(self, status: str) -> List[Dict[str, Any]]:
        """
        根据状态获取账户

        Args:
            status: 账户状态

        Returns:
            List[Dict]: 账户列表
        """
        try:
            conn = self._get_connection()
            cursor = conn.cursor()

            cursor.execute('SELECT * FROM accounts WHERE status = ? ORDER BY last_used DESC', (status,))
            rows = cursor.fetchall()

            columns = [desc[0] for desc in cursor.description]
            accounts = []

            for row in rows:
                data = dict(zip(columns, row))
                accounts.append(data)

            return accounts

        except Exception as e:
            self.logger.error(f"获取状态账户失败: {e}")
            return []
        finally:
            if 'conn' in locals():
                conn.close()


class AccountManager(LoggerMixin):
    """账户管理器"""

    def __init__(self):
        self.storage = AccountStorage()
        self.crypto = get_crypto_manager()
        self.current_account: Optional[AccountInfo] = None
        self._lock = threading.Lock()
        
        # 初始化时检测当前账号
        self._init_current_account_detection()
        
    def _init_current_account_detection(self):
        """初始化时检测当前 Cursor 使用的账号"""
        try:
            # 延迟导入以避免循环依赖
            from core.drission_modules.cursor_switcher import get_switcher
            switcher = get_switcher()
            current_info = switcher.get_current_account()
            
            if current_info and current_info.get('email'):
                email = current_info['email']
                # 查找对应的账户
                accounts = self.get_all_accounts()
                for acc in accounts:
                    if acc.email == email:
                        self.current_account = acc
                        self.logger.info(f"检测到当前 Cursor 账号: {email}")
                        break
        except Exception as e:
            self.logger.error(f"检测当前账号失败: {e}")

    def add_account(self, account_info: AccountInfo) -> bool:
        """
        添加账户到池中

        Args:
            account_info: 账户信息

        Returns:
            bool: 是否添加成功
        """
        try:
            with self._lock:
                data = account_info.to_dict()

                # 设置创建时间
                if not data.get('created_at'):
                    data['created_at'] = datetime.now().isoformat()

                # 加密敏感信息
                if account_info.password:
                    data['password'] = self.crypto.encrypt(account_info.password)
                if account_info.access_token:
                    data['access_token'] = self.crypto.encrypt(account_info.access_token)
                if account_info.refresh_token:
                    data['refresh_token'] = self.crypto.encrypt(account_info.refresh_token)
                if account_info.session_token:
                    data['session_token'] = self.crypto.encrypt(account_info.session_token)

                account_id = self.storage.save_account(data)
                if account_id > 0:
                    account_info.id = account_id
                    return True
                return False
        except Exception as e:
            self.logger.error(f"添加账户失败: {e}")
            return False

    def get_account(self, account_id: int) -> Optional[AccountInfo]:
        """
        获取账户信息

        Args:
            account_id: 账户ID

        Returns:
            Optional[AccountInfo]: 账户信息
        """
        try:
            data = self.storage.get_account(account_id)
            if not data:
                return None

            # 解密敏感信息
            if data.get('password'):
                data['password'] = self.crypto.decrypt(data['password'])
            if data.get('access_token'):
                data['access_token'] = self.crypto.decrypt(data['access_token'])
            if data.get('refresh_token'):
                data['refresh_token'] = self.crypto.decrypt(data['refresh_token'])
            if data.get('session_token'):
                data['session_token'] = self.crypto.decrypt(data['session_token'])
            elif data.get('access_token') and (data['access_token'].startswith('user_') or '::' in data['access_token']):
                # 兼容旧数据：如果 session_token 为空，但 access_token 看起来像 Session Token
                data['session_token'] = data['access_token']

            return AccountInfo.from_dict(data)
        except Exception as e:
            self.logger.error(f"获取账户失败: {e}")
            return None

    def get_all_accounts(self) -> List[AccountInfo]:
        """
        获取所有账户

        Returns:
            List[AccountInfo]: 账户列表
        """
        try:
            accounts_data = self.storage.get_all_accounts()
            accounts = []

            for data in accounts_data:
                try:
                    # 解密敏感信息
                    try:
                        if data.get('password'):
                            data['password'] = self.crypto.decrypt(data['password'])
                    except:
                        pass # 解密失败保留原值或为空

                    try:
                        if data.get('access_token'):
                            data['access_token'] = self.crypto.decrypt(data['access_token'])
                    except:
                        pass

                    try:
                        if data.get('refresh_token'):
                            data['refresh_token'] = self.crypto.decrypt(data['refresh_token'])
                    except:
                        pass

                    try:
                        if data.get('session_token'):
                            # 尝试解密，如果失败（可能是明文），则保留原值
                            try:
                                decrypted = self.crypto.decrypt(data['session_token'])
                                data['session_token'] = decrypted
                            except:
                                # 解密失败，说明是明文，保留原值
                                pass
                        elif data.get('access_token') and (data['access_token'].startswith('user_') or '::' in data['access_token']):
                            # 兼容旧数据：如果 session_token 为空，但 access_token 看起来像 Session Token
                            # 则将其复制给 session_token
                            try:
                                # access_token 是加密的，需要先解密（如果尚未解密）
                                # 注意：上面的代码块可能已经解密了 access_token，这里需要小心
                                # 我们先检查 access_token 是否已经被解密（是否包含 user_ 或 ::）
                                # 如果还没解密（是乱码），则无法判断。
                                # 但根据代码顺序，access_token 在上面已经被尝试解密了。
                                acc_token = data['access_token']
                                if acc_token.startswith('user_') or '::' in acc_token:
                                    data['session_token'] = acc_token
                            except:
                                pass
                    except:
                        # session_token 可能是明文存储的，解密失败说明它本来就是明文
                        pass

                    accounts.append(AccountInfo.from_dict(data))
                except Exception as e:
                    self.logger.error(f"解析账户数据失败: {e}")
                    # 即使解析出错，也尝试添加部分数据
                    try:
                        accounts.append(AccountInfo(email=data.get('email', 'unknown')))
                    except:
                        continue

            return accounts
        except Exception as e:
            self.logger.error(f"获取所有账户失败: {e}")
            return []

    def update_account(self, account_info: AccountInfo) -> bool:
        """
        更新账户信息

        Args:
            account_info: 账户信息

        Returns:
            bool: 是否更新成功
        """
        try:
            with self._lock:
                data = account_info.to_dict()

                # 加密敏感信息
                if account_info.password:
                    data['password'] = self.crypto.encrypt(account_info.password)
                if account_info.access_token:
                    data['access_token'] = self.crypto.encrypt(account_info.access_token)
                if account_info.refresh_token:
                    data['refresh_token'] = self.crypto.encrypt(account_info.refresh_token)
                if account_info.session_token:
                    data['session_token'] = self.crypto.encrypt(account_info.session_token)

                return self.storage.update_account(account_info.id, data)
        except Exception as e:
            self.logger.error(f"更新账户失败: {e}")
            return False

    def delete_account(self, account_id: int) -> bool:
        """
        删除账户

        Args:
            account_id: 账户ID

        Returns:
            bool: 是否删除成功
        """
        try:
            with self._lock:
                return self.storage.delete_account(account_id)
        except Exception as e:
            self.logger.error(f"删除账户失败: {e}")
            return False

    def switch_to_account(self, account_id: int) -> Tuple[bool, str]:
        """
        切换到指定账户

        Args:
            account_id: 账户ID

        Returns:
            Tuple[bool, str]: (是否成功, 消息)
        """
        try:
            account = self.get_account(account_id)
            if not account:
                return False, "账户不存在"

            if not account.access_token:
                return False, "账户没有有效的访问令牌"

            # 检查Token是否有效
            if not account.is_token_valid():
                return False, "账户的访问令牌已过期"

            self.logger.info(f"正在切换到账户: {account.email}")

            # 使用新的 Python 风格切换器 (复刻版)
            from core.drission_modules.cursor_switcher import switch_cursor_account
            
            # 构造账户数据
            account_data = {
                'email': account.email,
                'access_token': account.access_token,
                'refresh_token': account.refresh_token,
                'session_token': account.session_token
            }

            if switch_cursor_account(account_data):
                success = True
                message = f"成功切换到账户: {account.email}"
            else:
                success = False
                message = "切换失败，请检查日志"

            if success:
                # 更新最后使用时间和状态
                account.last_used = datetime.now().isoformat()
                account.status = 'active'
                self.update_account(account)

                self.current_account = account
                self.logger.info(f"账户切换成功: {account.email}")
                return True, f"成功切换到账户: {account.email}"
            else:
                self.logger.error(f"账户切换失败: {message}")
                return False, f"切换失败: {message}"

        except Exception as e:
            self.logger.error(f"切换账户异常: {e}")
            return False, f"切换账户失败: {str(e)}"

    def refresh_account_info(self, account_id: int) -> Tuple[bool, str]:
        """
        刷新账户信息（从API获取最新状态）

        Args:
            account_id: 账户ID

        Returns:
            Tuple[bool, str]: (是否成功, 消息)
        """
        try:
            account = self.get_account(account_id)
            if not account:
                return False, "账户不存在"

            if not account.access_token:
                return False, "账户没有访问令牌"

            self.logger.info(f"正在刷新账户信息: {account.email}")
            
            # 调用 API 获取最新信息
            from core.cursor_api import get_api_client
            api = get_api_client()
            
            # 构造 Token (如果是 Session Token)
            token = account.access_token
            
            # [修改] 不再强制使用本地存储的 user_id 构造 Session Token
            # 让 cursor_api 内部根据 Token 类型自动判断和处理
            # 这样更安全，避免因 user_id 不匹配或格式问题导致 500 错误
            
            # 获取详情
            details = api.get_account_details(token)
            
            if details:
                # 1. 更新订阅信息
                sub_info = details.get('subscription_info', {})
                if sub_info:
                    account.membership_type = sub_info.get('plan', account.membership_type)
                    # 如果有具体的天数信息
                    if 'days_remaining' in details:
                        account.days_remaining = details['days_remaining']
                
                # 2. 更新使用量信息
                usage_info = details.get('usage_info', {})
                if usage_info:
                    # 如果 API 返回了具体的 used/limit
                    if 'used' in details:
                        account.used = details['used']
                    if 'limit' in details:
                        account.limit_value = details['limit']
                    if 'usage_percent' in details:
                        account.usage_percent = details['usage_percent']
                
                # 3. 更新消耗统计 (Token Consumption)
                consumption = {
                    'total_cost': details.get('total_cost', 0),
                    'unpaid_amount': details.get('unpaid_amount', 0),
                    'total_tokens': details.get('total_tokens', 0),
                    'model_usage': details.get('model_usage', {}),
                    'last_updated': datetime.now().isoformat()
                }
                account.token_consumption = consumption
                
                # 4. 更新其他元数据
                if details.get('last_used'):
                    account.last_used = details.get('last_used')
                
                account.last_refreshed = datetime.now().isoformat()
                # 优先使用 API 返回的订阅状态
                if sub_info and 'status' in sub_info:
                    raw_status = sub_info['status']
                    # 将 inactive 映射为 active，因为免费版账号也是活跃的
                    if raw_status == 'inactive':
                        account.status = 'active'
                    else:
                        account.status = raw_status
                else:
                    account.status = 'active'

                if self.update_account(account):
                    return True, "账户信息已更新"
                else:
                    return False, "保存账户信息失败"
            else:
                # API 获取失败，说明 Token 可能失效
                account.status = 'invalid'
                self.update_account(account)
                return False, "Token 已失效或账号异常"

        except Exception as e:
            self.logger.error(f"刷新账户信息失败: {e}")
            return False, f"刷新失败: {str(e)}"

    def get_current_account(self) -> Optional[AccountInfo]:
        """
        获取当前使用的账户

        Returns:
            Optional[AccountInfo]: 当前账户信息
        """
        return self.current_account

    def set_current_account(self, account: AccountInfo):
        """
        设置当前账户

        Args:
            account: 账户信息
        """
        self.current_account = account

    def get_accounts_summary(self) -> Dict[str, Any]:
        """
        获取账户池摘要信息

        Returns:
            Dict[str, Any]: 摘要信息
        """
        accounts = self.get_all_accounts()

        summary = {
            'total_accounts': len(accounts),
            'active_accounts': len([a for a in accounts if a.status == 'active']),
            'pro_accounts': len([a for a in accounts if a.membership_type in ['pro', 'pro_plus']]),
            # 将"过期"改为统计"已失效" (invalid) 的账号
            'expired_accounts': len([a for a in accounts if a.status == 'invalid']),
            # 优化有效Token计算：必须有token且状态不是invalid且未过期
            'valid_tokens': len([a for a in accounts if a.is_token_valid() and a.status != 'invalid']),
            'auto_registered': len([a for a in accounts if a.register_type == 'auto']),
            'manual_registered': len([a for a in accounts if a.register_type == 'manual'])
        }

        return summary

    def search_accounts(self, keyword: str) -> List[AccountInfo]:
        """
        搜索账户

        Args:
            keyword: 搜索关键词

        Returns:
            List[AccountInfo]: 匹配的账户列表
        """
        accounts = self.get_all_accounts()
        keyword_lower = keyword.lower()

        filtered = []
        for account in accounts:
            if (keyword_lower in account.email.lower() or
                (account.notes and keyword_lower in account.notes.lower()) or
                keyword_lower in account.membership_type.lower()):
                filtered.append(account)

        return filtered
