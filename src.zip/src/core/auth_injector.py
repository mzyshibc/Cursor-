#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
认证注入器
负责将认证信息注入到Cursor数据库中
"""

import os
import sqlite3
import shutil
import time
from pathlib import Path
from typing import Dict, Any, Optional, Tuple, List
from dataclasses import dataclass

from utils.logger import LoggerMixin
from utils.crypto import get_crypto_manager


@dataclass
class CursorPaths:
    """Cursor路径信息"""
    app_data: Path
    db_path: Path
    backup_path: Optional[Path] = None

    @classmethod
    def find_cursor_paths(cls) -> Optional['CursorPaths']:
        """查找Cursor路径"""
        try:
            # Windows路径
            if os.name == 'nt':
                app_data = Path(os.environ.get('APPDATA', '')) / 'Cursor'
                db_path = app_data / 'User' / 'globalStorage' / 'state.vscdb'

                if db_path.exists():
                    return cls(
                        app_data=app_data,
                        db_path=db_path,
                        backup_path=db_path.with_suffix('.backup')
                    )

            # macOS路径
            elif os.uname().sysname == 'Darwin':
                home = Path.home()
                app_data = home / 'Library' / 'Application Support' / 'Cursor'
                db_path = app_data / 'User' / 'globalStorage' / 'state.vscdb'

                if db_path.exists():
                    return cls(
                        app_data=app_data,
                        db_path=db_path,
                        backup_path=db_path.with_suffix('.backup')
                    )

            # Linux路径
            else:
                home = Path.home()
                app_data = home / '.config' / 'Cursor'
                db_path = app_data / 'User' / 'globalStorage' / 'state.vscdb'

                if db_path.exists():
                    return cls(
                        app_data=app_data,
                        db_path=db_path,
                        backup_path=db_path.with_suffix('.backup')
                    )

            return None

        except Exception:
            return None


class CursorDatabaseManager(LoggerMixin):
    """Cursor数据库管理器"""

    def __init__(self):
        self.paths = CursorPaths.find_cursor_paths()
        if not self.paths:
            raise Exception("未找到Cursor安装路径")
        self.crypto = get_crypto_manager()

    def _get_connection(self) -> sqlite3.Connection:
        """获取数据库连接"""
        return sqlite3.connect(str(self.paths.db_path))

    def _execute_query(self, query: str, params: tuple = ()) -> List[Dict[str, Any]]:
        """执行查询并返回结果"""
        try:
            conn = self._get_connection()
            cursor = conn.cursor()

            cursor.execute(query, params)
            columns = [desc[0] for desc in cursor.description]

            results = []
            for row in cursor.fetchall():
                results.append(dict(zip(columns, row)))

            conn.close()
            return results

        except Exception as e:
            self.logger.error(f"查询执行失败: {e}")
            return []

    def _execute_non_query(self, query: str, params: tuple = ()) -> bool:
        """执行非查询操作"""
        try:
            conn = self._get_connection()
            cursor = conn.cursor()

            cursor.execute(query, params)
            conn.commit()
            conn.close()
            return True

        except Exception as e:
            self.logger.error(f"非查询执行失败: {e}")
            return False

    def backup_database(self) -> bool:
        """
        备份数据库

        Returns:
            bool: 备份是否成功
        """
        try:
            if self.paths.backup_path:
                shutil.copy2(self.paths.db_path, self.paths.backup_path)
                self.logger.info(f"数据库备份成功: {self.paths.backup_path}")
                return True
            return False
        except Exception as e:
            self.logger.error(f"数据库备份失败: {e}")
            return False

    def restore_database(self) -> bool:
        """
        恢复数据库

        Returns:
            bool: 恢复是否成功
        """
        try:
            if self.paths.backup_path and self.paths.backup_path.exists():
                shutil.copy2(self.paths.backup_path, self.paths.db_path)
                self.logger.info(f"数据库恢复成功: {self.paths.db_path}")
                return True
            return False
        except Exception as e:
            self.logger.error(f"数据库恢复失败: {e}")
            return False

    def inject_auth_data(self, email: str, access_token: str,
                        refresh_token: str = "", session_token: str = "") -> bool:
        """
        注入认证数据

        Args:
            email: 用户邮箱
            access_token: 访问令牌
            refresh_token: 刷新令牌
            session_token: 会话令牌

        Returns:
            bool: 注入是否成功
        """
        try:
            # 准备认证数据
            auth_data = {
                'cursorAccount': email,
                'cursorAuth': access_token,
                'workosCursorAccessToken': access_token,
            }

            # 处理刷新令牌
            if refresh_token:
                auth_data['workosCursorRefreshToken'] = refresh_token
            else:
                auth_data['workosCursorRefreshToken'] = access_token

            # 处理会话令牌
            if session_token:
                auth_data['workosCursorSessionToken'] = session_token

            # 注入基础认证信息
            success = self._inject_basic_auth(auth_data)
            if not success:
                return False

            # 注入用户偏好设置
            success &= self._inject_user_preferences(email)
            if not success:
                return False

            # 注入机器码信息（如果需要）
            success &= self._inject_machine_info()
            if not success:
                return False

            # 清理旧的认证数据
            self._cleanup_old_auth_data()

            self.logger.info(f"认证数据注入成功: {email}")
            return True

        except Exception as e:
            self.logger.error(f"认证数据注入失败: {e}")
            return False

    def _inject_basic_auth(self, auth_data: Dict[str, str]) -> bool:
        """注入基础认证数据"""
        try:
            conn = self._get_connection()
            cursor = conn.cursor()

            # 批量更新认证数据
            for key, value in auth_data.items():
                # 检查是否存在
                cursor.execute("SELECT value FROM ItemTable WHERE key = ?", (key,))
                existing = cursor.fetchone()

                if existing:
                    # 更新现有记录
                    cursor.execute("""
                        UPDATE ItemTable SET value = ? WHERE key = ?
                    """, (value, key))
                else:
                    # 插入新记录
                    cursor.execute("""
                        INSERT INTO ItemTable (key, value) VALUES (?, ?)
                    """, (key, value))

            conn.commit()
            conn.close()
            return True

        except Exception as e:
            self.logger.error(f"基础认证数据注入失败: {e}")
            return False

    def _inject_user_preferences(self, email: str) -> bool:
        """注入用户偏好设置"""
        try:
            # 设置一些基本的用户偏好
            preferences = {
                'cursorUserEmail': email,
                'cursorUserId': self._generate_user_id(email),
                'cursorLastLogin': str(int(time.time() * 1000)),  # 时间戳
                'cursorLoginMethod': 'oauth',
            }

            conn = self._get_connection()
            cursor = conn.cursor()

            for key, value in preferences.items():
                cursor.execute("SELECT value FROM ItemTable WHERE key = ?", (key,))
                existing = cursor.fetchone()

                if existing:
                    cursor.execute("""
                        UPDATE ItemTable SET value = ? WHERE key = ?
                    """, (value, key))
                else:
                    cursor.execute("""
                        INSERT INTO ItemTable (key, value) VALUES (?, ?)
                    """, (key, value))

            conn.commit()
            conn.close()
            return True

        except Exception as e:
            self.logger.error(f"用户偏好注入失败: {e}")
            return False

    def _inject_machine_info(self) -> bool:
        """注入机器信息"""
        try:
            import uuid
            import platform

            machine_info = {
                'cursorMachineId': str(uuid.uuid4()),
                'cursorPlatform': platform.system().lower(),
                'cursorVersion': '1.0.0',
                'cursorInstallDate': str(int(time.time() * 1000)),
            }

            conn = self._get_connection()
            cursor = conn.cursor()

            for key, value in machine_info.items():
                cursor.execute("SELECT value FROM ItemTable WHERE key = ?", (key,))
                existing = cursor.fetchone()

                if existing:
                    cursor.execute("""
                        UPDATE ItemTable SET value = ? WHERE key = ?
                    """, (value, key))
                else:
                    cursor.execute("""
                        INSERT INTO ItemTable (key, value) VALUES (?, ?)
                    """, (key, value))

            conn.commit()
            conn.close()
            return True

        except Exception as e:
            self.logger.error(f"机器信息注入失败: {e}")
            return False

    def _cleanup_old_auth_data(self) -> bool:
        """清理旧的认证数据"""
        try:
            # 删除过期的认证数据
            old_keys = [
                'cursorOldAuth',
                'cursorExpiredToken',
                'workosOldSessionToken',
            ]

            conn = self._get_connection()
            cursor = conn.cursor()

            for key in old_keys:
                cursor.execute("DELETE FROM ItemTable WHERE key = ?", (key,))

            conn.commit()
            conn.close()
            return True

        except Exception as e:
            self.logger.error(f"清理旧认证数据失败: {e}")
            return False

    def _generate_user_id(self, email: str) -> str:
        """生成用户ID"""
        try:
            import hashlib
            # 基于邮箱生成用户ID
            return hashlib.md5(email.encode()).hexdigest()
        except:
            return str(hash(email) % 1000000)

    def clear_auth_data(self) -> bool:
        """
        清除认证数据

        Returns:
            bool: 清除是否成功
        """
        try:
            conn = sqlite3.connect(str(self.paths.db_path))
            cursor = conn.cursor()

            # 删除认证相关的数据
            cursor.execute("""
                DELETE FROM ItemTable
                WHERE key IN ('cursorAuth', 'cursorAccount', 'workosCursorAccessToken', 'workosCursorRefreshToken', 'workosCursorSessionToken')
            """)

            conn.commit()
            conn.close()

            self.logger.info("认证数据清除成功")
            return True

        except Exception as e:
            self.logger.error(f"认证数据清除失败: {e}")
            return False

    def get_current_auth_info(self) -> Dict[str, Any]:
        """
        获取当前的认证信息
        """
        try:
            conn = sqlite3.connect(str(self.paths.db_path))
            cursor = conn.cursor()

            cursor.execute("""
                SELECT key, value FROM ItemTable
                WHERE key IN ('cursorAccount', 'cursorAuth', 'workosCursorAccessToken', 'workosCursorRefreshToken', 'workosCursorSessionToken')
            """)

            data = {row[0]: row[1] for row in cursor.fetchall()}
            conn.close()

            return data

        except Exception as e:
            self.logger.error(f"获取认证信息失败: {e}")
            return {}


class ProcessManager(LoggerMixin):
    """进程管理器"""

    def __init__(self):
        self.cursor_processes = [
            'Cursor.exe', 'Cursor', 'cursor.exe', 'cursor',
            'Cursor Helper.exe', 'Cursor Helper', 'Cursor Helper (Renderer).exe'
        ]
        self.kill_timeout = 10  # 杀死进程超时时间（秒）
        self.start_timeout = 30  # 启动超时时间（秒）

    def kill_cursor_processes(self) -> Tuple[bool, str]:
        """
        关闭所有Cursor进程
        """
        try:
            import psutil
            killed_count = 0
            force_killed = 0

            # 获取所有Cursor相关进程
            cursor_procs = []
            for proc in psutil.process_iter(['pid', 'name', 'exe']):
                try:
                    if proc.info['name'] and any(cursor_name in proc.info['name'] for cursor_name in self.cursor_processes):
                        cursor_procs.append(proc)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            if not cursor_procs:
                return True, "未找到运行中的Cursor进程"

            # 优雅关闭进程
            for proc in cursor_procs:
                try:
                    if proc.is_running():
                        proc.terminate()
                        killed_count += 1
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            # 等待进程关闭
            start_time = time.time()
            while time.time() - start_time < self.kill_timeout:
                remaining_procs = [p for p in cursor_procs if p.is_running()]
                if not remaining_procs:
                    break
                time.sleep(0.5)

            # 强制杀死剩余进程
            for proc in cursor_procs:
                try:
                    if proc.is_running():
                        proc.kill()
                        force_killed += 1
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            return True, f"已关闭 {killed_count} 个进程，强制杀死 {force_killed} 个进程"

        except Exception as e:
            return False, f"关闭进程异常: {e}"

    def launch_cursor(self) -> Tuple[bool, str]:
        """
        启动Cursor
        """
        try:
            cursor_exe = self._find_cursor_executable()
            if not cursor_exe:
                return False, "未找到Cursor可执行文件"

            import subprocess
            subprocess.Popen([str(cursor_exe)], shell=False)
            return True, "Cursor已启动"
        except Exception as e:
            return False, f"启动Cursor失败: {e}"

    def _find_cursor_executable(self) -> Optional[Path]:
        """查找Cursor可执行文件"""
        if os.name == 'nt':
            local_app_data = os.environ.get('LOCALAPPDATA', '')
            if local_app_data:
                exe_path = Path(local_app_data) / 'Programs' / 'Cursor' / 'Cursor.exe'
                if exe_path.exists():
                    return exe_path
        return None


class AuthInjector(LoggerMixin):
    """认证注入器"""

    def __init__(self):
        self.db_manager = CursorDatabaseManager()
        self.process_manager = ProcessManager()

    def inject_auth(self, email: str, access_token: str,
                   refresh_token: str = "", session_token: str = "") -> Tuple[bool, str]:
        """
        注入认证信息
        """
        try:
            self.logger.info(f"开始注入认证信息: {email}")

            # 1. 关闭Cursor进程
            self.process_manager.kill_cursor_processes()

            # 2. 备份数据库
            self.db_manager.backup_database()

            # 3. 注入认证数据
            if self.db_manager.inject_auth_data(email, access_token, refresh_token, session_token):
                # 4. 启动Cursor
                self.process_manager.launch_cursor()
                return True, "认证注入成功"
            else:
                self.db_manager.restore_database()
                return False, "认证数据注入失败"

        except Exception as e:
            self.db_manager.restore_database()
            return False, f"认证注入失败: {str(e)}"

    def reset_machine_id(self) -> Tuple[bool, str]:
        """
        重置机器ID
        """
        try:
            self.process_manager.kill_cursor_processes()
            if self.db_manager._inject_machine_info():
                self.process_manager.launch_cursor()
                return True, "机器ID重置成功"
            return False, "机器ID注入失败"
        except Exception as e:
            return False, f"机器ID重置失败: {str(e)}"
