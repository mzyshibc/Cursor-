# -*- coding: utf-8 -*-
"""
后端 API 交互模块
负责将注册好的账号上传到服务器
"""

from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import requests
import json
from typing import Dict, Any

try:
    from src.utils.logger import get_logger
    from src.core.drission_modules.account_storage import LicenseValidator
except ImportError:
    # 兼容性导入
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from src.utils.logger import get_logger
    # LicenseValidator 可能在不同位置，这里简单处理或者假设存在
    # 如果找不到，就硬编码 URL
    class LicenseValidator:
        SERVER_URL = "https://vip.mzyota.icu"

logger = get_logger("backend_api")

class BackendAPI:
    """后端 API 客户端"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        # 尝试从 auth 配置中获取
        self.auth_config = config.get('auth', {})
        
        # 确定 Base URL
        self.base_url = self.auth_config.get('server_url', "https://vip.mzyota.icu")
        
        # 获取管理员账号密码（通常在 auth 配置中，或者 server 配置中）
        # 这里为了兼容旧版逻辑，也检查 server 键
        server_config = config.get('server', {})
        
        # 优先级：auth配置 > server配置 > 硬编码默认值
        self.username = (self.auth_config.get('admin_username') or 
                        server_config.get('admin_username') or 
                        "admin")
                        
        self.password = (self.auth_config.get('admin_password') or 
                        server_config.get('admin_password') or 
                        "admin123")
        
        self.token = None # 初始化为空，等待登录获取
        
        # 是否启用上传
        self.enabled = self.auth_config.get('upload_enabled') or server_config.get('upload_enabled', True)
        
        # 是否绕过代理
        self.bypass_proxy = self.auth_config.get('bypass_proxy', True)
        
        # 配置重试策略 (解决网络超时问题)
        self.session = requests.Session()
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "OPTIONS", "POST"]
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("https://", adapter)
        self.session.mount("http://", adapter)

    def _get_request_kwargs(self) -> Dict[str, Any]:
        """获取请求参数（如代理设置）"""
        kwargs = {'timeout': 30}
        if self.bypass_proxy:
            # 明确禁用代理
            kwargs['proxies'] = {
                "http": None,
                "https": None
            }
        return kwargs

    def login(self) -> bool:
        """
        登录获取 Token
        """
        if not self.username or not self.password:
            # 如果没有配置账号密码，看看是否有 API Key（有些版本可能用 API Key）
            if self.auth_config.get('api_key'):
                 self.token = self.auth_config.get('api_key')
                 return True
                 
            logger.warning("未配置管理员账号密码，无法自动登录")
            return False
            
        url = f"{self.base_url}/api/admin/login"
        payload = {
            "username": self.username,
            "password": self.password
        }
        
        try:
            logger.info(f"正在尝试登录服务器 ({self.username})...")
            if self.bypass_proxy:
                logger.info("  (已启用直连模式，绕过系统代理)")
                
            response = self.session.post(url, json=payload, **self._get_request_kwargs())
            
            if response.status_code != 200:
                logger.error(f"登录失败，状态码: {response.status_code}")
                return False
                
            data = response.json()
            if data.get("success"):
                self.token = data.get("token")
                logger.info("✅ 登录成功，获取到 Token")
                return True
            else:
                logger.error(f"登录失败: {data.get('message')}")
                return False
                
        except Exception as e:
            logger.error(f"登录异常: {e}")
            return False

    def get_system_config(self) -> Dict[str, Any]:
        """
        获取系统全局配置（邮箱设置等）
        """
        url = f"{self.base_url}/api/config/email-settings"
        
        try:
            logger.info("正在获取系统全局配置...")
            response = self.session.get(url, **self._get_request_kwargs())
            
            if response.status_code == 200:
                data = response.json()
                if data.get("success"):
                    config = data.get("config", {})
                    logger.info("✅ 成功获取系统全局配置")
                    return config
            
            logger.warning(f"获取系统配置失败: {response.status_code}")
            return {}
            
        except Exception as e:
            logger.error(f"获取系统配置异常: {e}")
            return {}
    def upload_account(self, account_data: Dict[str, Any]) -> bool:
        """
        上传账号到服务器
        
        Args:
            account_data: 账号数据字典
            
        Returns:
            bool: 是否成功
        """
        if not self.enabled:
            return False
            
        # 如果没有 Token，尝试登录
        if not self.token:
            if not self.login():
                return False
            
        url = f"{self.base_url}/api/admin/upload-accounts"
        
        try:
            logger.info("正在上传账号到服务器...")
            
            payload = {
                "token": self.token,
                "accounts": [account_data]
            }
            
            response = self.session.post(url, json=payload, **self._get_request_kwargs())
            
            # 检查是否因为 Token 过期导致失败 (401/403)
            if response.status_code in [401, 403]:
                logger.warning("Token 可能已过期，尝试重新登录...")
                if self.login():
                    # 更新 Token 后重试
                    payload["token"] = self.token
                    response = self.session.post(url, json=payload, **self._get_request_kwargs())
                else:
                    return False

            # 处理响应...
            if response.status_code != 200:
                logger.error(f"服务器返回错误状态码: {response.status_code}")
                # logger.error(f"响应内容: {response.text[:200]}") # 调试用
                return False

            try:
                result = response.json()
                if result.get('success'):
                    logger.info(f"✅ 账号已上传到服务器: {result.get('message')}")
                    return True
                else:
                    logger.warning(f"❌ 上传失败: {result.get('message')}")
                    return False
            except json.JSONDecodeError:
                logger.error(f"解析响应 JSON 失败。响应内容: {response.text[:200]}")
                return False
                
        except Exception as e:
            logger.error(f"上传账号异常: {e}")
            return False
