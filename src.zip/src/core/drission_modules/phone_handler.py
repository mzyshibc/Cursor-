#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
手机验证处理模块
负责处理 Cursor 的手机验证步骤
"""

import time
import json
try:
    from src.utils.logger import get_logger
except ImportError:
    from utils.logger import get_logger

logger = get_logger("phone_handler")

def detect_invalid_phone_feedback(tab) -> bool:
    try:
        texts = []
        eles = tab.eles("tag:div") or []
        for e in eles[:100]:
            t = e.text or ""
            if t:
                texts.append(t)
        joined = " ".join(texts)
        # 增加 "请求过多" 相关的关键词
        keys = [
            "号码不可用", "已注册", "请更换手机号", "格式不合法", 
            "不支持该号码", "invalid", "not available", "used",
            "请求过多", "request too many", "too many requests",
            "something went wrong", "try again"
        ]
        for k in keys:
            if k in joined:
                return True
    except Exception:
        pass
    return False

def acquire_phone_via_provider(sid: int, prefs: dict | None = None):
    from src.utils.sms_provider import HaoZhuMaClient
    client = HaoZhuMaClient()
    data = client.get_phone(sid, prefs)
    return data.get("phone"), data

def blacklist_and_reacquire(sid: int, phone: str, prefs: dict | None = None):
    from src.utils.sms_provider import HaoZhuMaClient
    client = HaoZhuMaClient()
    try:
        client.add_blacklist(sid, phone)
    except Exception:
        pass
    return acquire_phone_via_provider(sid, prefs)

def occupy_phone_via_provider(sid: int, phone: str):
    from src.utils.sms_provider import HaoZhuMaClient
    client = HaoZhuMaClient()
    try:
        return client.occupy_phone(sid, phone)
    except Exception:
        return {}

def read_code_via_provider(sid: int, phone: str, sms_expected: bool = False):
    from src.utils.sms_provider import HaoZhuMaClient
    client = HaoZhuMaClient()
    code, data = client.poll_message(sid, phone, sms_expected=sms_expected)
    return code, data

def release_phone_via_provider(sid: int, phone: str):
    from src.utils.sms_provider import HaoZhuMaClient
    client = HaoZhuMaClient()
    try:
        return client.cancel_recv(sid, phone)
    except Exception:
        return {}


class PhoneHandler:
    """手机验证处理器"""
    
    @staticmethod
    def call_user_custom_code(tab, custom_code: str) -> bool:
        """
        调用用户自定义的手机验证代码
        
        Args:
            tab: DrissionPage 的 tab 对象
            custom_code: 用户编写的 Python 代码
            
        Returns:
            bool: 是否成功
        """
        try:
            from src.utils.config import ConfigManager
            cm = ConfigManager()
            sms_cfg = getattr(cm, "sms_config")
            sid_map = sms_cfg.sid_map or {}
            sel = sms_cfg.selected_project or ""
            
            # 统一 SID 获取逻辑
            sid = 0
            if sel in sid_map:
                sid = int(sid_map[sel])
            elif str(sel).isdigit():
                sid = int(sel)
            elif sid_map:
                sid = int(list(sid_map.values())[0])
            
            if not sid:
                raise RuntimeError(f"未能在配置中找到有效的项目ID (当前选择: {sel})")
                
            phone_number, _ = acquire_phone_via_provider(sid, {})
            logger.info(f"📱 从接码平台获取手机号: +1{phone_number} (SID: {sid})")
            
            # 创建执行环境
            exec_globals = {
                'tab': tab,
                'phone_number': phone_number,
                'time': time,
                'logger': logger
            }
            exec_locals = {}
            
            # 执行用户代码
            exec(custom_code, exec_globals, exec_locals)
            
            # 调用用户定义的函数
            if 'verify_phone' in exec_locals:
                verify_func = exec_locals['verify_phone']
                result = verify_func(tab, phone_number)
                return bool(result)
            else:
                logger.error("用户代码中未找到 verify_phone 函数")
                return False
                
        except Exception as e:
            logger.error(f"执行用户代码失败: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    @staticmethod
    def handle_manual_phone_verification(tab, progress_callback=None) -> bool:
        def _log(msg, percent=None):
            logger.info(msg)
            if progress_callback:
                try:
                    progress_callback(msg, percent)
                except:
                    pass

        try:
            from src.utils.config import ConfigManager
            cm = ConfigManager()
            sms_cfg = getattr(cm, "sms_config")
            sid_map = sms_cfg.sid_map or {}
            sel = sms_cfg.selected_project or ""
            
            # 改进 SID 获取逻辑
            sid = 0
            if sel in sid_map:
                sid = int(sid_map[sel])
            elif str(sel).isdigit():
                sid = int(sel)
            elif sid_map:
                # 按照用户要求，如果没有匹配到选中的，优先尝试从 sid_map 中获取
                sid = int(list(sid_map.values())[0])
            
            if not sid:
                raise RuntimeError(f"未能在配置中找到有效的项目ID (当前选择: {sel})")
                
            _log(f"等待手机验证页面加载...", 88)
            _log(f"使用接码项目ID: {sid}", 88)
            
            prefs = {}
            # 设置重试上限为 50 次，除非配置中有更高的要求
            max_attempts = max(sms_cfg.max_attempts or 5, 50)
            attempt = 0
            while attempt < max_attempts:
                attempt += 1
                _log(f"获取手机号 (第{attempt}/{max_attempts}次)...", 88)
                phone, info = acquire_phone_via_provider(sid, prefs)
                if not phone:
                    continue
                try:
                    sp = (info or {}).get("sp") or ""
                    gsd = (info or {}).get("phone_gsd") or ""
                    _log(f"📱 拉取手机号: {phone} {sp} {gsd}", 88)
                except:
                    _log(f"📱 拉取手机号: {phone}", 88)
                
                try:
                    cc_inp = None
                    num_inp = None
                    
                    # 1. 根据用户提供的 HTML 精准定位
                    cc_inp = tab.ele("@name=country_code", timeout=2)
                    num_inp = tab.ele("@name=local_number", timeout=2)
                    
                    # 2. 如果精准定位失败，尝试 class 定位
                    if not cc_inp or not num_inp:
                        inputs = tab.eles("@class:rt-TextFieldInput")
                        if len(inputs) >= 2:
                            cc_inp = inputs[0]
                            num_inp = inputs[1]

                    if cc_inp and num_inp:
                        _log(f"✅ 找到手机号输入框", 89)
                        # 1. 模拟打字输入国家代码 (86)
                        cc_inp.click() # 先物理点击确保获取焦点
                        cc_inp.clear()
                        cc_inp.input("86")
                        time.sleep(0.5)
                        
                        # 2. 物理点击右侧手机号输入框，强制移动焦点
                        num_inp.click()
                        time.sleep(0.3)
                        
                        # 准备手机号逻辑
                        raw = ''.join(ch for ch in str(phone) if ch.isdigit())
                        local = raw[2:] if raw.startswith('86') else raw
                        
                        # 3. 模拟打字输入手机号
                        num_inp.clear()
                        num_inp.input(local)
                        
                        time.sleep(0.5)
                    else:
                        _log("❌ 无法定位手机号输入框，请检查网页结构", 88)
                        continue
                        
                    btn = None
                    for b in (tab.eles("tag:button") or []):
                        t = (b.text or "").lower()
                        if ("验证码" in t) or ("短信" in t) or ("send" in t and "code" in t):
                            btn = b
                            break
                    if btn:
                        btn.click()
                    
                    # 关键修复：点击发送后增加等待并检测页面反馈
                    time.sleep(2) 
                    if detect_invalid_phone_feedback(tab):
                        _log(f"⚠️ 号码 {phone} 不可用或请求过多，拉黑并重试...", 88)
                        blacklist_and_reacquire(sid, phone, prefs)
                        continue

                    sms_expected = True
                    _log("读取短信验证码...", 89)
                    code, data = read_code_via_provider(sid, phone, sms_expected=sms_expected)
                    masked = False
                    try:
                        msg_txt = (data or {}).get("msg", "") or ""
                        sms_txt = (data or {}).get("sms", "") or ""
                        if str(code).strip() == "0":
                            masked = True
                        if ("屏蔽" in msg_txt) or ("屏蔽" in sms_txt):
                            masked = True
                    except:
                        pass
                    if not code or masked:
                        if masked:
                            _log("⚠️ 检测到短信被屏蔽，号码已拉黑，重新取号", 88)
                        else:
                            _log("读取超时，拉黑并重试", 88)
                        phone, _ = blacklist_and_reacquire(sid, phone, prefs)
                        continue
                    
                    _log(f"✅ 获取到短信验证码: {code}", 90)
                    ok = True
                    try:
                        from .drission_modules.registration_steps import RegistrationSteps
                    except Exception:
                        from .registration_steps import RegistrationSteps
                    ok = RegistrationSteps.input_verification_code(tab, code)
                    release_phone_via_provider(sid, phone)
                    return bool(ok)
                except Exception as e:
                    _log(f"输入手机号过程异常: {e}", 88)
                    try:
                        release_phone_via_provider(sid, phone)
                    except:
                        pass
            _log("❌ 手机验证失败（达到最大次数）", 88)
            return False
        except Exception as e:
            _log(f"手机验证流程异常: {e}", 88)
            return False

