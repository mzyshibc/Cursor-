#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Cursor 账号切换模块
配置文件更新和账号切换逻辑
完全复刻 cursor_utils.js 的核心注入流程
"""

import os
import sys
import json
import sqlite3
import shutil
import time
import psutil
import uuid
import hashlib
import subprocess
from pathlib import Path
from contextlib import contextmanager
from typing import Dict, Any, List, Optional

try:
    from src.utils.logger import get_logger
    from src.utils.config import ConfigManager
except ImportError:
    from utils.logger import get_logger
    from utils.config import ConfigManager

# 文件锁支持（跨平台）
if sys.platform == 'win32':
    import msvcrt
else:
    import fcntl  # macOS/Linux 使用 fcntl

logger = get_logger("cursor_switcher")


class CursorSwitcher:
    """Cursor 账号切换器"""
    
    def __init__(self):
        """初始化切换器"""
        self.platform = sys.platform
        self.cursor_dir = self._detect_cursor_dir()
        self.config_paths = self._detect_config_paths()
        self.db_paths = self._detect_db_paths()
        self.cursor_exe_path: Optional[Path] = None
        self.config_manager = ConfigManager()
    
    def _detect_cursor_dir(self) -> Path:
        """
        检测 Cursor 数据根目录
        Windows: %APPDATA%/Cursor
        macOS: ~/Library/Application Support/Cursor
        Linux: ~/.config/Cursor
        """
        home = Path.home()
        if self.platform == 'win32':
            return Path(os.getenv('APPDATA', home / 'AppData' / 'Roaming')) / 'Cursor'
        elif self.platform == 'darwin':
            return home / 'Library' / 'Application Support' / 'Cursor'
        else:
            return home / '.config' / 'Cursor'

    def _detect_config_paths(self) -> List[Path]:
        """检测 storage.json 配置文件路径"""
        possible_paths = [
            self.cursor_dir / 'User' / 'globalStorage' / 'storage.json'
        ]
        
        existing_paths = [p for p in possible_paths if p.exists()]
        
        if existing_paths:
            logger.info(f"找到 {len(existing_paths)} 个 storage.json 配置文件")
        else:
            logger.warning("未找到 Cursor 配置文件 (storage.json)")
        
        return existing_paths
    
    def _detect_db_paths(self) -> List[Path]:
        """检测 state.vscdb 数据库文件路径"""
        possible_paths = [
            self.cursor_dir / 'User' / 'globalStorage' / 'state.vscdb'
        ]
        
        existing_paths = [p for p in possible_paths if p.exists()]
        
        if existing_paths:
            logger.info(f"找到 {len(existing_paths)} 个 state.vscdb 数据库文件")
        
        return existing_paths
    
    @contextmanager
    def _file_lock(self, file_handle):
        """文件锁（跨平台）"""
        if self.platform == 'win32':
            try:
                msvcrt.locking(file_handle.fileno(), msvcrt.LK_LOCK, 1)
                yield file_handle
            finally:
                try:
                    msvcrt.locking(file_handle.fileno(), msvcrt.LK_UNLCK, 1)
                except:
                    pass
        else:
            try:
                fcntl.flock(file_handle.fileno(), fcntl.LOCK_EX)
                yield file_handle
            finally:
                try:
                    fcntl.flock(file_handle.fileno(), fcntl.LOCK_UN)
                except:
                    pass
    
    def switch_account(self, account: Dict[str, Any]) -> bool:
        """
        切换到指定账号 (完全复刻 pythonStyleAccountSwitch 逻辑)
        
        Args:
            account: 账号数据字典，必须包含 email 和 access_token
                
        Returns:
            bool: 是否成功
        """
        try:
            email = account.get('email')
            access_token = account.get('access_token')
            refresh_token = account.get('refresh_token', access_token)
            
            logger.info("========================================")
            logger.info("=== Python风格账号切换开始（复刻版） ===")
            logger.info("========================================")
            logger.info(f"用户邮箱: {email}")

            if not email or not access_token:
                logger.error("账号数据不完整：缺少 email 或 access_token")
                return False
            
            # 1. 解密 Token
            access_token = self._decrypt_token_if_needed(access_token)
            refresh_token = self._decrypt_token_if_needed(refresh_token)

            # [2024-01-24 终极修正 V2]
            # 用户反馈：“存入数据库 应该是去掉前缀 保留ey开头的 这样试试”
            # 这回到了我最早的猜测，也是最符合逻辑的猜测：
            # 数据库里的 accessToken 字段应该只存纯 JWT (eyJ...)。
            # 而 sessionToken 字段才存带前缀的。
            # 但 Cursor 似乎主要用 accessToken。
            
            # 所以，现在的策略是：
            # 1. 必须 URL 解码 (把 %3A%3A 变成 ::)。
            # 2. 必须清洗 (去掉 user_xxx:: 前缀，只保留 eyJ...)。
            
            # 1. URL 解码
            import urllib.parse
            if access_token and '%' in access_token:
                try:
                    decoded = urllib.parse.unquote(access_token)
                    if decoded != access_token:
                        access_token = decoded
                        logger.info("已对 Access Token 进行 URL 解码")
                except:
                    pass
            
            if refresh_token and '%' in refresh_token:
                try:
                    decoded = urllib.parse.unquote(refresh_token)
                    if decoded != refresh_token:
                        refresh_token = decoded
                        logger.info("已对 Refresh Token 进行 URL 解码")
                except:
                    pass

            # 2. 清洗 Token (去除前缀) - 已禁用，Cursor 需要完整 Token
            # if access_token and "::" in access_token:
            #     parts = access_token.split("::")
            #     if len(parts) > 1:
            #         potential_jwt = parts[-1]
            #         if potential_jwt.startswith("eyJ"):
            #             access_token = potential_jwt
            #             logger.info("已清洗 Access Token (去除前缀，只保留 JWT)")
            
            # if refresh_token and "::" in refresh_token:
            #     parts = refresh_token.split("::")
            #     if len(parts) > 1:
            #         potential_jwt = parts[-1]
            #         if potential_jwt.startswith("eyJ"):
            #             refresh_token = potential_jwt
            #             logger.info("已清洗 Refresh Token (去除前缀，只保留 JWT)")

            # 3. 补全 Refresh Token (如果缺失)
            if not refresh_token:
                refresh_token = access_token
                logger.info("Refresh Token 缺失，已自动补全")

            # 2. 关闭 Cursor 进程
            logger.info("【1/5】关闭 Cursor 进程...")
            if not self.close_cursor_gracefully():
                logger.warning("无法完全关闭 Cursor 进程，可能会影响写入")
            
            # 确保进程完全释放
            time.sleep(2)

            # 3. 重置机器码 (Storage + Files + Registry)
            logger.info("【2/5】重置机器码...")
            self.reset_machine_ids()

            # 4. 更新数据库 (Auth Injection)
            logger.info("【3/5】注入认证数据...")
            db_success = self._update_db_files(email, access_token, refresh_token)
            
            if not db_success:
                logger.error("数据库注入失败")
                return False

            # 5. 清理缓存
            logger.info("【4/5】清理缓存目录...")
            self._clean_cache_directories()

            # 6. 启动 Cursor
            logger.info("【5/5】启动 Cursor...")
            self.start_cursor()
            
            logger.info("========================================")
            logger.info("=== 账号切换流程完成 ===")
            logger.info("========================================")
            return True
            
        except Exception as e:
            logger.error(f"切换账号失败: {e}", exc_info=True)
            return False

    def _decrypt_token_if_needed(self, token: str) -> str:
        """如果 token 是加密的，尝试解密"""
        if token and token.startswith('gAAAAA'):
            try:
                from utils.crypto import get_crypto_manager
                crypto = get_crypto_manager()
                decrypted = crypto.decrypt(token)
                if decrypted:
                    return decrypted
            except Exception as e:
                logger.warning(f"解密 token 失败: {e}")
        return token

    def reset_machine_ids(self):
        """重置所有机器码 (storage.json, 文件, 注册表)"""
        try:
            # 生成新的 ID
            new_ids = {
                'machineId': hashlib.sha256(os.urandom(32)).hexdigest(),
                'devDeviceId': str(uuid.uuid4()),
                'sqmId': '{' + str(uuid.uuid4()).upper() + '}',
                'macMachineId': str(uuid.uuid4())
            }
            
            logger.info(f"生成新机器码: {new_ids['machineId'][:10]}...")

            # 1. 更新 storage.json
            self._update_storage_json_machine_ids(new_ids)

            # 2. 更新文件机器码 (machineid, machineid.json, etc.)
            self._update_file_machine_ids(new_ids['devDeviceId'])

            # 3. 更新注册表 (Windows only)
            if self.platform == 'win32':
                self._update_windows_registry_guid()

        except Exception as e:
            logger.error(f"重置机器码失败: {e}")

    def _update_storage_json_machine_ids(self, new_ids: Dict[str, str]):
        """更新 storage.json 中的机器码"""
        if not self.config_paths:
            return

        for config_file in self.config_paths:
            try:
                if not config_file.exists():
                    continue

                # 备份
                backup_file = config_file.with_suffix('.json.backup')
                shutil.copy2(config_file, backup_file)

                with open(config_file, 'r', encoding='utf-8') as f:
                    config = json.load(f)

                # 更新字段
                config['telemetry.machineId'] = new_ids['machineId']
                config['telemetry.devDeviceId'] = new_ids['devDeviceId']
                config['telemetry.sqmId'] = new_ids['sqmId']
                config['telemetry.macMachineId'] = new_ids['macMachineId']

                # 写入
                with open(config_file, 'r+', encoding='utf-8') as f:
                    with self._file_lock(f):
                        f.seek(0)
                        f.truncate()
                        json.dump(config, f, ensure_ascii=False, indent=4)
                        f.flush()
                        os.fsync(f.fileno())
                
                logger.info(f"✓ storage.json 机器码已更新")

            except Exception as e:
                logger.error(f"更新 storage.json 失败: {e}")

    def _update_file_machine_ids(self, device_id: str):
        """更新文件系统中的机器码文件"""
        # 定义要更新的文件路径 (参考 cursor_utils.js)
        target_files = [
            self.cursor_dir / 'machineid.json',
            self.cursor_dir / 'machineid',
            self.cursor_dir / 'User' / 'globalStorage' / 'machine-id',
            self.cursor_dir / 'User' / 'globalStorage' / 'anonymousid'
        ]

        anonymous_id = str(uuid.uuid4())

        for file_path in target_files:
            try:
                # 确保目录存在
                file_path.parent.mkdir(parents=True, exist_ok=True)

                if file_path.suffix == '.json':
                    # JSON 格式
                    content = json.dumps({"machineId": device_id}, indent=2)
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(content)
                else:
                    # 纯文本格式
                    # anonymousid 使用独立 ID，其他使用 device_id
                    id_to_write = anonymous_id if file_path.name == 'anonymousid' else device_id
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(id_to_write)
                
                logger.info(f"✓ 已更新机器码文件: {file_path.name}")

            except Exception as e:
                logger.warning(f"更新机器码文件失败 {file_path}: {e}")

    def _update_windows_registry_guid(self):
        """更新 Windows 注册表 MachineGuid"""
        try:
            machine_guid = str(uuid.uuid4())
            cmd = [
                'reg', 'add', 
                r'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Cryptography', 
                '/v', 'MachineGuid', 
                '/t', 'REG_SZ', 
                '/d', machine_guid, 
                '/f'
            ]
            # 需要管理员权限，这里尝试运行，失败则忽略
            subprocess.run(cmd, capture_output=True, check=False)
            logger.info("✓ 尝试更新注册表 MachineGuid")
        except Exception as e:
            logger.debug(f"更新注册表失败 (可能需要管理员权限): {e}")

    def _update_db_files(self, email: str, access_token: str, refresh_token: str) -> bool:
        """更新 state.vscdb 数据库 (完全逐条复刻 JS 逻辑，不使用事务脚本)"""
        if not self.db_paths:
            logger.error("未找到 state.vscdb")
            return False

        # 使用内置 sqlite3 库执行，不依赖外部 sqlite3.exe
        sqlite_exe = None
        logger.info("使用内置 sqlite3 库执行 SQL（不依赖 sqlite3.exe）")

        success_count = 0
        for db_path in self.db_paths:
            try:
                # 0. 确保文件可写
                try:
                    os.chmod(db_path, 0o666)
                except:
                    pass

                # 1. 清理 WAL/SHM 文件
                self._clean_wal_shm(db_path)

                # 2. 备份
                try:
                    shutil.copy2(db_path, db_path.with_suffix('.vscdb.backup'))
                except Exception as e:
                    logger.warning(f"备份数据库失败: {e}")

                # 3. 准备要执行的操作
                # 参考 cursor_utils.js: 仅清理 cursorai/serverConfig
                keys_to_delete = ['cursorai/serverConfig']
                
                # 准备 updates (严格对应 JS 的 4 个字段，不添加额外的)
                updates = []
                if email:
                    updates.append(('cursorAuth/cachedEmail', email))
                if access_token:
                    updates.append(('cursorAuth/accessToken', access_token))
                if refresh_token:
                    updates.append(('cursorAuth/refreshToken', refresh_token))
                    updates.append(('cursorAuth/cachedSignUpType', 'Auth_0'))
                    # 关键修复：清空 WorkOS Token，防止冲突
                    updates.append(('WorkosCursorSessionToken', ''))
                    updates.append(('workos.sessionToken', ''))
                    
                    # [2024-01-26 补全] 对齐旧版逻辑：添加 stripeMembershipType 和 serverConfig
                    updates.append(('cursorAuth/stripeMembershipType', 'free'))
                    server_config = json.dumps({"baseUrl": "https://api.cursor.com", "version": "1.0.0"})
                    updates.append(('cursorai/serverConfig', server_config))

                # 4. 逐条执行 SQL (完全复刻 JS 逻辑)
                
                # 4.1 删除旧 Key
                if keys_to_delete:
                    delete_keys_str = "', '".join(keys_to_delete)
                    sql = f"DELETE FROM ItemTable WHERE key IN ('{delete_keys_str}');"
                    self._run_sqlite_cmd(sqlite_exe, db_path, sql)

                # 4.2 逐个更新/插入
                for key, value in updates:
                    # 转义单引号
                    safe_key = key.replace("'", "''")
                    safe_value = value.replace("'", "''")
                    
                    # 尝试 UPDATE
                    update_sql = f"UPDATE ItemTable SET value = '{safe_value}' WHERE key = '{safe_key}';"
                    self._run_sqlite_cmd(sqlite_exe, db_path, update_sql)
                    
                    # 检查是否更新成功
                    check_sql = f"SELECT COUNT(*) FROM ItemTable WHERE key = '{safe_key}';"
                    result = self._run_sqlite_cmd(sqlite_exe, db_path, check_sql)
                    
                    try:
                        count = int(result.strip())
                    except:
                        count = 0
                        
                    if count == 0:
                        # 插入
                        insert_sql = f"INSERT INTO ItemTable (key, value) VALUES ('{safe_key}', '{safe_value}');"
                        self._run_sqlite_cmd(sqlite_exe, db_path, insert_sql)

                logger.info(f"✓ 数据库注入成功 (逐条模式): {db_path.name}")
                success_count += 1

            except Exception as e:
                logger.error(f"操作数据库失败 {db_path}: {e}")

        return success_count > 0

    def _run_sqlite_cmd(self, exe, db, sql):
        """执行单条 sqlite 命令（内置 sqlite3，无需外部 sqlite3.exe）"""
        try:
            conn = sqlite3.connect(str(db))
            cur = conn.cursor()
            cur.execute(sql)
            out = ""
            if sql.strip().lower().startswith("select"):
                row = cur.fetchone()
                if row is not None and len(row) > 0:
                    out = str(row[0])
                else:
                    out = "0"
            else:
                conn.commit()
            cur.close()
            conn.close()
            return out
        except Exception as e:
            logger.error(f"SQL执行错误: {e}")
            return ""

    def _clean_wal_shm(self, db_path: Path):
        """清理 SQLite 的 WAL 和 SHM 临时文件"""
        try:
            for ext in ['-wal', '-shm']:
                temp_file = db_path.with_name(db_path.name + ext)
                if temp_file.exists():
                    try:
                        os.remove(temp_file)
                        logger.debug(f"已清理临时文件: {temp_file.name}")
                    except OSError:
                        pass
        except Exception:
            pass

    def _clean_cache_directories(self):
        """清理 Cursor 缓存目录"""
        try:
            # 缓存目录通常在 Cursor 根目录下
            # Windows: %APPDATA%/Cursor/Cache, %APPDATA%/Cursor/Code Cache, etc.
            cache_dirs = [
                self.cursor_dir / 'Cache',
                self.cursor_dir / 'Code Cache',
                self.cursor_dir / 'GPUCache',
                self.cursor_dir / 'DawnCache',
                self.cursor_dir / 'Workspaces'  # 可选：清理工作区缓存
            ]

            for cache_dir in cache_dirs:
                if cache_dir.exists():
                    try:
                        shutil.rmtree(cache_dir, ignore_errors=True)
                        logger.info(f"✓ 已清理缓存: {cache_dir.name}")
                    except Exception as e:
                        logger.warning(f"清理缓存失败 {cache_dir.name}: {e}")

        except Exception as e:
            logger.error(f"清理缓存流程异常: {e}")

    def close_cursor_gracefully(self) -> bool:
        """关闭 Cursor 进程 (增强版，参考 cursor_utils.js)"""
        logger.info("正在关闭 Cursor 相关进程...")
        
        target_processes = ['Cursor.exe', 'Cursor', 'cursor']
        if self.platform == 'win32':
             target_processes.extend(['Cursor Helper.exe', 'Cursor Helper (Renderer).exe'])

        try:
            # 0. 尝试捕获 Cursor 可执行文件路径
            if not self.cursor_exe_path:
                for proc in psutil.process_iter(['name', 'exe']):
                    try:
                        # 严谨匹配：只匹配精确的 'Cursor.exe'，忽略大小写，排除 FlyCursor.exe 等
                        if proc.info['name'] and proc.info['name'].lower() == 'cursor.exe':
                            exe_path = proc.info.get('exe')
                            if exe_path and os.path.exists(exe_path):
                                self.cursor_exe_path = Path(exe_path)
                                logger.info(f"已捕获 Cursor 路径: {self.cursor_exe_path}")
                                break
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        pass

            # 1. 尝试温和关闭
            for proc in psutil.process_iter(['name']):
                try:
                    # 关闭时也需要严谨，避免误杀
                    proc_name = proc.info['name'].lower() if proc.info['name'] else ""
                    if proc_name == 'cursor.exe' or proc_name == 'cursor':
                         proc.terminate()
                    elif self.platform == 'win32' and proc_name in ['cursor helper.exe', 'cursor helper (renderer).exe']:
                         proc.terminate()
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            
            # 等待片刻
            time.sleep(2)

            # 2. 检查并强制杀死 (循环检查)
            max_retries = 5
            for i in range(max_retries):
                still_running = False
                for proc in psutil.process_iter(['name']):
                    try:
                        proc_name = proc.info['name'].lower() if proc.info['name'] else ""
                        # 严谨匹配
                        if proc_name == 'cursor.exe' or proc_name == 'cursor':
                            logger.info(f"发现残留进程 {proc.info['name']}, 强制关闭...")
                            proc.kill()
                            still_running = True
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        pass
                
                if not still_running:
                    logger.info("所有 Cursor 进程已关闭")
                    return True
                
                time.sleep(1)
            
            # 如果还有残留，使用系统命令强制清理
            if self.platform == 'win32':
                subprocess.run("taskkill /F /IM Cursor.exe /T", shell=True, stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
            else:
                subprocess.run("pkill -9 -f Cursor", shell=True, stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
            
            time.sleep(1)
            return True
            
        except Exception as e:
            logger.error(f"关闭进程异常: {e}")
            return False

    def kill_cursor_force(self):
        """强制清理 Cursor 进程"""
        try:
            if self.platform == 'win32':
                subprocess.run("taskkill /F /IM Cursor.exe /T", shell=True, stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
            else:
                subprocess.run("pkill -9 -f Cursor", shell=True, stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
        except:
            pass

    def _scan_full_disk_for_cursor(self) -> Optional[Path]:
        """全盘搜索 Cursor.exe (使用系统命令加速)"""
        import string
        from concurrent.futures import ThreadPoolExecutor, as_completed

        if self.platform != 'win32':
            return None

        # 获取所有驱动器
        drives = ['%s:\\' % d for d in string.ascii_uppercase if os.path.exists('%s:\\' % d)]
        logger.info(f"正在全盘搜索 Cursor.exe，扫描驱动器: {drives} (可能需要几分钟)...")

        found_path = None

        def scan_drive(drive):
            try:
                # 使用 where /r 命令 (递归搜索)
                # cmd /c where /r C:\ Cursor.exe
                # 为了避免权限问题和系统目录死循环，where 命令通常表现不错
                cmd = f'where /r {drive} Cursor.exe'
                
                # 创建无窗口的 startupinfo
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                
                result = subprocess.run(
                    cmd, 
                    capture_output=True, 
                    text=True, 
                    shell=True,
                    startupinfo=startupinfo,
                    creationflags=subprocess.CREATE_NO_WINDOW
                )
                
                if result.returncode == 0 and result.stdout:
                    paths = result.stdout.strip().split('\n')
                    for p in paths:
                        p = p.strip()
                        if not p: continue
                        # 严格验证
                        path_obj = Path(p)
                        if path_obj.name.lower() == 'cursor.exe':
                             return path_obj
            except Exception:
                pass
            return None

        # 并行搜索所有驱动器
        with ThreadPoolExecutor(max_workers=min(len(drives), 4)) as executor:
            futures = {executor.submit(scan_drive, drive): drive for drive in drives}
            for future in as_completed(futures):
                result = future.result()
                if result:
                    found_path = result
                    # 找到后不需要取消其他，因为 where 命令很难被取消，直接返回即可
                    break
        
        if found_path:
            logger.info(f"全盘搜索找到 Cursor: {found_path}")
        else:
            logger.warning("全盘搜索未找到 Cursor.exe")
            
        return found_path

    def start_cursor(self) -> bool:
        """启动 Cursor (优化版：Config > Process > Common > Full Scan)"""
        try:
            if self.platform == 'win32':
                possible_paths = []
                
                # 1. 优先使用用户配置的路径 (最高优先级)
                try:
                    config_path = self.config_manager.get_system_config().cursor_path
                    if config_path:
                        p = Path(config_path)
                        if p.exists() and p.name.lower() == 'cursor.exe':
                            logger.info(f"使用用户配置的 Cursor 路径: {p}")
                            possible_paths.append(p)
                        else:
                            logger.warning(f"用户配置的 Cursor 路径无效或不存在: {config_path}")
                except Exception as e:
                    logger.error(f"读取配置路径失败: {e}")

                # 2. 使用捕获到的路径 (仅当未配置时)
                if not possible_paths and self.cursor_exe_path and self.cursor_exe_path.exists():
                    logger.info(f"使用进程捕获到的 Cursor 路径: {self.cursor_exe_path}")
                    possible_paths.append(self.cursor_exe_path)

                # 3. 常见路径 (常规搜索)
                if not possible_paths:
                    common_paths = [
                        Path(os.getenv('LOCALAPPDATA', '')) / 'Programs' / 'cursor' / 'Cursor.exe',
                        Path(os.getenv('APPDATA', '')) / 'Programs' / 'cursor' / 'Cursor.exe',
                        Path('C:/Program Files/Cursor/Cursor.exe'),
                        Path('C:/Program Files (x86)/Cursor/Cursor.exe'),
                        # 添加常见的用户自定义路径
                        Path('D:/Cursor/Cursor.exe'),
                        Path('E:/Cursor/Cursor.exe'),
                        Path('F:/Cursor/Cursor.exe'),
                    ]
                    possible_paths.extend([p for p in common_paths if p.exists()])

                # 4. 全盘搜索 (最后的兜底手段)
                if not possible_paths:
                    logger.warning("常规路径未找到 Cursor，尝试全盘搜索...")
                    scanned_path = self._scan_full_disk_for_cursor()
                    if scanned_path:
                        possible_paths.append(scanned_path)
                        # 找到后自动保存到配置，方便下次使用
                        try:
                            config = self.config_manager.get_system_config()
                            config.cursor_path = str(scanned_path)
                            self.config_manager.set_system_config(config)
                            logger.info(f"已自动保存全盘搜索到的路径: {scanned_path}")
                        except:
                            pass

                # 从注册表查找 (作为补充)
                if not possible_paths:
                    try:
                        import winreg
                        reg_paths = [
                            r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
                            r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall",
                        ]
                        for reg_path in reg_paths:
                            try:
                                key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, reg_path)
                                for i in range(0, winreg.QueryInfoKey(key)[0]):
                                    try:
                                        subkey_name = winreg.EnumKey(key, i)
                                        subkey = winreg.OpenKey(key, subkey_name)
                                        display_name = winreg.QueryValueEx(subkey, "DisplayName")[0]
                                        if "Cursor" in str(display_name):
                                            install_loc = winreg.QueryValueEx(subkey, "InstallLocation")[0]
                                            exe_path = Path(install_loc) / "Cursor.exe"
                                            if exe_path.exists():
                                                possible_paths.append(exe_path)
                                    except:
                                        pass
                            except:
                                pass
                    except:
                        pass
                
                cursor_exe = None
                # 选择第一个有效的
                for path in possible_paths:
                    if path.exists():
                        cursor_exe = path
                        break
                
                if cursor_exe:
                    logger.info(f"启动 Cursor: {cursor_exe}")
                    subprocess.Popen(
                        [str(cursor_exe)], 
                        shell=False,
                        creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
                        close_fds=True,
                        stdin=subprocess.DEVNULL,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL
                    )
                    return True
                else:
                    logger.error("未找到 Cursor 可执行文件，请在设置中手动指定路径")
                    return False
            
            elif self.platform == 'darwin':
                subprocess.Popen(['open', '-a', 'Cursor'])
                return True
                
            else:
                subprocess.Popen(['cursor'], start_new_session=True)
                return True
                
            return False
        except Exception as e:
            logger.error(f"启动 Cursor 失败: {e}")
            return False


# 全局切换器实例
_switcher = None

def get_switcher() -> CursorSwitcher:
    global _switcher
    if _switcher is None:
        _switcher = CursorSwitcher()
    return _switcher

def switch_cursor_account(account: Dict[str, Any]) -> bool:
    """切换 Cursor 账号（便捷函数）"""
    switcher = get_switcher()
    return switcher.switch_account(account)
