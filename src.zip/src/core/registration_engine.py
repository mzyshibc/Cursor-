#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自动注册引擎
实现完整的Cursor账户自动化注册流程
"""

from typing import Optional, Callable
from dataclasses import dataclass

from utils.logger import LoggerMixin
from utils.config import EmailConfig
from core.cursor_api import CursorOfficialAPI
from core.legacy_email_handler import LegacyEmailHandler

@dataclass
class RegistrationResult:
    """注册结果"""
    success: bool
    email: str = ""
    access_token: str = ""
    refresh_token: str = ""
    session_token: str = ""
    user_id: str = ""
    message: str = ""
    error_details: str = ""


class RegistrationEngine(LoggerMixin):
    """自动注册引擎（基于DrissionPage复刻版）"""

    def __init__(self, email_config: EmailConfig, domain: str = 'mzyota'):
        """
        初始化注册引擎
        
        Args:
            email_config: 邮箱配置
            domain: 域名类型 ('mzyota', 'yefota', 'gotool', 'custom')
        """
        self.email_config = email_config
        self.domain = domain
        self.api = CursorOfficialAPI()
        self.legacy_email_handler = LegacyEmailHandler(domain)

    def register_account(self, progress_callback: Optional[Callable[[str, int], None]] = None, email: str = None) -> RegistrationResult:
        """
        执行自动注册流程（委托给DrissionPage实现，完全复刻旧版本行为）
        
        Args:
            progress_callback: 进度回调函数 callback(message, percent)
            email: 指定使用的邮箱地址（可选，如果提供则跳过生成）
            
        Returns:
            RegistrationResult: 注册结果
        """
        print("[DEBUG] RegistrationEngine.register_account() 开始 (DrissionPage Mode)")
        self.logger.info("开始自动注册流程（DrissionPage复刻版）")
        
        if progress_callback:
            progress_callback("正在初始化注册环境...", 0)

        # 初始化统一 EmailHandler
        from core.email_handler import EmailHandler
        
        # ⚠️ 关键修正：对于 TempMail 模式，必须使用正确的 receiving_email 配置
        # 否则 EmailHandler 会尝试用注册邮箱去查询，导致查不到邮件
        handler_config = self.email_config
        
        if self.email_config.mode == 'tempmail':
            # 获取当前域名的正确配置 (从 legacy_email_handler 获取)
            domain_config = self.legacy_email_handler.config
            
            # 创建临时配置对象，覆盖 tempmail_email 为公共接收邮箱
            import copy
            handler_config = copy.deepcopy(self.email_config)
            
            # ⭐ 关键修正：如果用户在 config.json 中显式配置了 tempmail_email，则优先使用它
            # 否则才回退到 domain_config (旧版默认配置)
            if self.email_config.tempmail_email and self.email_config.tempmail_service == 'tempmail.plus':
                self.logger.info(f"使用用户自定义的 TempMail 配置: {self.email_config.tempmail_email}")
                # 保持原样，不要覆盖
            else:
                handler_config.tempmail_email = domain_config['receiving_email']
                handler_config.tempmail_pin = domain_config['pin']
                self.logger.info(f"配置 EmailHandler 使用默认公共接收箱: {handler_config.tempmail_email}")
            
        email_handler = EmailHandler(handler_config)

        try:
            # 1. 生成/使用邮箱
            if not email:
                if progress_callback:
                    progress_callback("生成邮箱...", 5)
                
                if self.email_config.mode == 'imap':
                    email = email_handler.generate_email()
                else:
                    email = self.legacy_email_handler.generate_email()
            
            if not email:
                return RegistrationResult(success=False, message="邮箱生成失败")
                
            self.logger.info(f"使用的邮箱: {email}")
            
            # 2. 构造配置 (适配 CursorAutoRegister 需要的格式)
            # 获取域名对应的配置
            domain_config = self.legacy_email_handler.config
            
            # ⚠️ 关键修正：确保 config 中包含 config.json 中的全部信息
            # 特别是 auth.admin_username 等上传所需的凭证
            
            # 1. 基础配置
            # 尝试获取 sms_config
            sms_config_dict = {'enabled': False}
            try:
                from utils.config import ConfigManager
                cm = ConfigManager()
                if hasattr(cm, 'sms_config'):
                    sms_config_dict = cm.sms_config.to_dict()
            except Exception as e:
                self.logger.warning(f"无法加载 SMS 配置: {e}")

            config = {
                'email': {
                    'receiving_email': domain_config['receiving_email'],
                    'receiving_email_pin': domain_config['pin']
                },
                'browser': {
                    'incognito_mode': True
                },
                'phone_verification': sms_config_dict, # 使用加载的手机验证配置
                'payment_binding': {
                    'enabled': False
                },
                # 2. 注入 auth 配置（用于上传）
                'auth': self.email_config.to_dict().get('auth', {}), # 这里可能需要从更上层获取
                # 3. 注入 server 配置 (兼容旧版)
                'server': {
                    'admin_username': "admin", # 默认值，会被下面的覆盖
                    'admin_password': "admin123"
                }
            }
            
            # 尝试从 EmailConfig 所在的 ConfigManager 获取完整的配置树
            # 由于这里只传了 EmailConfig，我们尝试手动读取一下 config.json 来补充 auth 信息
            # 或者假设 email_config 其实并不包含 auth，我们需要重新加载
            try:
                from utils.config import ConfigManager
                cm = ConfigManager()
                full_config = cm.get_auth_config()
                config['auth'] = {
                    'server_url': full_config.server_url,
                    'admin_username': full_config.admin_username,
                    'admin_password': full_config.admin_password,
                    'bypass_proxy': full_config.bypass_proxy
                }
                # 同时填充 server 字段以兼容
                config['server']['admin_username'] = full_config.admin_username
                config['server']['admin_password'] = full_config.admin_password
            except:
                pass
            
            # 3. 实例化 DrissionPage 注册器
            # 注意：这里动态导入，确保只有在调用时才加载 DrissionPage
            try:
                from .drission_modules.auto_register import CursorAutoRegister
            except ImportError as e:
                self.logger.error(f"无法导入 DrissionPage 模块: {e}")
                return RegistrationResult(success=False, message="缺少 DrissionPage 依赖", error_details=str(e))
                
            registrar = CursorAutoRegister()
            
            # 4. 执行注册
            if progress_callback:
                progress_callback("启动旧版浏览器内核...", 10)
                
            result_dict = registrar.register_account(
                email=email,
                config=config,
                progress_callback=progress_callback,
                check_limit=False,
                email_handler=email_handler
            )
            
            # 5. 处理结果
            success = result_dict.get('success', False)
            token = result_dict.get('token')
            session_token = result_dict.get('session_token')
            
            if success and token:
                # 验证账号有效性
                if progress_callback:
                    progress_callback("验证账户有效性...", 95)
                    
                verified = self._verify_account(token)
                if not verified:
                    self.logger.warning("注册成功但验证失败")
                    # 仍然返回成功，但在日志中记录
            
            # 关闭浏览器（确保清理）
            registrar.close()
            
            return RegistrationResult(
                success=success,
                message=result_dict.get('message', ''),
                email=email,
                access_token=token if token else "",
                refresh_token=result_dict.get('refresh_token', token) if token else "",
                session_token=session_token if session_token else "",
                error_details=None if success else result_dict.get('message')
            )
            
        except Exception as e:
            self.logger.error(f"注册过程异常: {e}")
            import traceback
            self.logger.error(traceback.format_exc())
            return RegistrationResult(
                success=False,
                message="注册过程中发生异常",
                error_details=str(e)
            )

    def _verify_account(self, access_token: str) -> bool:
        """验证账户有效性"""
        try:
            # 使用API验证Token
            user_info = self.api.get_user_info_by_bearer(access_token)
            return user_info is not None
        except Exception as e:
            self.logger.error(f"账户验证异常: {e}")
            return False
