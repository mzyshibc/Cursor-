#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Legacy Email Handler - 复刻旧版本的邮箱处理器
"""

import time
import imaplib
import email
import re
import requests
from typing import Optional
from utils.logger import get_logger

logger = get_logger("legacy_email_handler")


class LegacyEmailHandler:
    """复刻旧版本的邮箱处理器"""

    # 复刻旧版本的IMAP配置
    IMAP_SERVER = 'imap.2925.com'
    IMAP_PORT = 993
    MAIN_EMAIL = 'sqdecursor@2925.com'  # 原版主邮箱
    APP_PASSWORD = '100200'  # 原版密码

    # 系统预设域名邮箱配置
    DOMAIN_CONFIGS = {
        # 2925域名：直接IMAP邮箱（复刻cursor-vip-project）
        '2925': {
            'type': 'imap',
            'server': 'imap.2925.com',
            'port': 993,
            'main_email': 'bluesky78@2925.com',
            'password': 'a251314',
            'generate_pattern': 'bluesky78+{random}@2925.com'
        },
        # 其他三个域名：使用tempmail.plus（复刻zidongdengru）
        'mzyota': {
            'type': 'tempmail',
            'receiving_email': 'mzyshibc@any.pink',
            'pin': 'abc251314',
            'domain': 'mzyota.cn'
        },
        'yefota': {
            'type': 'tempmail',
            'receiving_email': 'mzyshibc@any.pink',
            'pin': 'abc251314',
            'domain': 'yefota.dpdns.org'
        },
        'gotool': {
            'type': 'tempmail',
            'receiving_email': 'mzyshibc@any.pink',
            'pin': 'abc251314',
            'domain': 'gotool.qzz.io'
        }
    }

    def __init__(self, domain: str = 'mzyota', custom_config: dict = None):
        """
        初始化邮箱处理器

        Args:
            domain: 域名类型 ('2925', 'mzyota', 'yefota', 'gotool', 'custom')
            custom_config: 自定义域名配置
        """
        self.domain = domain

        if domain == 'custom' and custom_config:
            # 使用自定义配置（tempmail.plus）
            self.config = {
                'type': 'tempmail',
                'receiving_email': custom_config.get('custom_receiving_email', ''),
                'pin': custom_config.get('custom_pin', ''),
                'domain': custom_config.get('custom_domain', 'custom.com')
            }
        else:
            # 使用系统预设配置（全部使用tempmail.plus）
            self.config = self.DOMAIN_CONFIGS.get(domain, self.DOMAIN_CONFIGS['mzyota'])

    def generate_email(self) -> str:
        """生成临时邮箱"""
        if self.config['type'] == 'imap':
            # IMAP类型：生成别名邮箱
            import random
            import string
            random_suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
            return self.config['generate_pattern'].format(random=random_suffix)
        else:
            # tempmail类型：生成域名邮箱，通过Cloudflare路由到tempmail.plus
            # 使用自然人名 + 随机数格式，类似zidongdengru的实现
            import random
            import string

            # 自然人名库（复刻zidongdengru）
            common_names = [
                "james", "mary", "robert", "patricia", "john", "jennifer", "michael", "linda",
                "david", "elizabeth", "william", "barbara", "richard", "susan", "joseph", "jessica",
                "thomas", "sarah", "charles", "karen", "christopher", "nancy", "daniel", "lisa"
            ]

            # 随机选择名字
            name = random.choice(common_names)
            # 生成随机后缀
            suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=4))

            return f"{name}{suffix}@{self.config['domain']}"

    def get_verification_code(self, target_email: str, timeout: int = 300, start_timestamp: float = 0) -> Optional[str]:
        """
        获取邮箱验证码
        
        Args:
            target_email: 目标邮箱
            timeout: 超时时间
            start_timestamp: 开始等待验证码的时间戳（用于过滤旧邮件）
        """
        if self.config['type'] == 'imap':
            # IMAP类型：使用IMAP协议获取验证码
            return self._get_verification_code_imap(target_email, timeout)
        else:
            # tempmail类型：使用tempmail.plus API获取验证码
            return self._get_verification_code_tempmail(target_email, timeout, start_timestamp)

    def _get_verification_code_imap(self, target_email: str, timeout: int = 300) -> Optional[str]:
        """使用IMAP协议获取验证码（复刻旧版本）"""
        mail = None
        start_time = time.time()

        try:
            # 连接IMAP服务器
            mail = imaplib.IMAP4_SSL(self.config['server'], self.config['port'])
            mail.login(self.config['main_email'], self.config['password'])
            mail.select('INBOX')

            code = None
            last_checked_msg_ids = set()

            # 轮询直到获取到6位数字验证码或超时
            while code is None and (time.time() - start_time) < timeout:
                msg_ids = []

                # 搜索邮件
                try:
                    status, messages = mail.search('UTF-8', f'(TO "{target_email}")')
                    if status == 'OK' and messages[0]:
                        msg_ids = [msg_id.decode('utf-8') if isinstance(msg_id, bytes) else str(msg_id)
                                  for msg_id in messages[0].split()]
                except:
                    pass

                # 处理找到的邮件
                if msg_ids:
                    recent_msgs = msg_ids[-10:] if len(msg_ids) > 10 else msg_ids

                    for msg_id in reversed(recent_msgs):
                        if msg_id in last_checked_msg_ids:
                            continue

                        try:
                            _, msg_data = mail.fetch(msg_id, '(RFC822)')
                            raw_email = msg_data[0][1]
                            msg = email.message_from_bytes(raw_email)

                            # 解析邮件内容
                            body = ""
                            if msg.is_multipart():
                                for part in msg.walk():
                                    if part.get_content_type() == 'text/plain':
                                        try:
                                            body = part.get_payload(decode=True).decode('utf-8', 'ignore')
                                        except:
                                            try:
                                                body = part.get_payload(decode=True).decode('gbk', 'ignore')
                                            except:
                                                pass
                                        break
                            else:
                                try:
                                    body = msg.get_payload(decode=True).decode('utf-8', 'ignore')
                                except:
                                    try:
                                        body = msg.get_payload(decode=True).decode('gbk', 'ignore')
                                    except:
                                        pass

                            # 提取验证码
                            if body:
                                matches = re.findall(r'\b\d{6}\b', body)
                                if matches:
                                    code = matches[-1]
                                    try:
                                        mail.store(msg_id, '+FLAGS', r'(\Deleted)')
                                        mail.expunge()
                                    except Exception:
                                        pass
                                    break

                            last_checked_msg_ids.add(msg_id)
                        except Exception as e:
                            continue

                if code is None:
                    time.sleep(2)

            return code

        except Exception as e:
            return None
        finally:
            if mail:
                try:
                    mail.close()
                    mail.logout()
                except:
                    pass

    def _get_verification_code_tempmail(self, target_email: str, timeout: int = 300, start_timestamp: float = 0) -> Optional[str]:
        """使用tempmail.plus API获取验证码（完全复刻旧版本逻辑）"""
        # 初始化 session
        self.session = requests.Session()
        from requests.adapters import HTTPAdapter
        from urllib3.util.retry import Retry
        
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "OPTIONS"]
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("https://", adapter)
        self.session.mount("http://", adapter)
        
        start_time = time.time()
        attempt = 0
        
        logger.info(f"开始获取验证码（每秒检查，最多{timeout}秒）...")
        
        # 初始等待 10 秒，确保邮件已发送且不是读取旧邮件
        logger.info("⏳ 等待 10 秒以接收最新邮件...")
        time.sleep(10)
        
        while (time.time() - start_time) < timeout:
            try:
                attempt += 1
                if attempt % 5 == 0:
                    logger.info(f"尝试获取验证码 (第 {attempt} 次)...")

                verify_code, first_id = self._get_latest_mail_code(target_email, start_timestamp)
                if verify_code is not None and first_id is not None:
                    self._cleanup_mail(first_id)
                    return verify_code

                time.sleep(1)

            except Exception as e:
                logger.error(f"获取验证码失败: {e}")
                time.sleep(1)

        logger.error(f"经过 {timeout} 秒后仍未获取到验证码")
        return None

    def _get_latest_mail_code(self, target_email, start_timestamp=0):
        """
        获取最新邮件中的验证码（智能过滤发给注册邮箱的邮件）
        """
        try:
            # 获取邮件列表
            receiving_email = self.config['receiving_email']
            pin = self.config['pin']
            
            url = f"https://tempmail.plus/api/mails?email={receiving_email}&limit=20&epin={pin}"
            response = self.session.get(url, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                
                if not data.get("result"):
                    return None, None
                
                # 改进：遍历最近的多封邮件
                mail_ids = []
                
                # 从API响应中提取邮件ID列表
                first_id = data.get("first_id")
                if first_id:
                    mail_ids.append(first_id)
                
                # 如果API返回了邮件列表，也加入
                mails_data = data.get("mail_list", []) or data.get("mails", [])
                for mail in mails_data[:5]:  # 最多检查5封邮件
                    if isinstance(mail, dict) and (mail.get("id") or mail.get("mail_id")):
                        current_id = mail.get("id") or mail.get("mail_id")
                        if current_id not in mail_ids:
                            mail_ids.append(current_id)
                
                if not mail_ids:
                    return None, None
                
                # 遍历邮件列表
                for idx, mail_id in enumerate(mail_ids):
                    # 获取邮件详情
                    mail_url = f"https://tempmail.plus/api/mails/{mail_id}?email={receiving_email}&epin={pin}"
                    mail_response = self.session.get(mail_url, timeout=30)
                    
                    if mail_response.status_code == 200:
                        mail_data = mail_response.json()
                        
                        if mail_data.get("result"):
                            mail_text = mail_data.get("text", "")
                            mail_subject = mail_data.get("subject", "")
                            mail_to = mail_data.get("to", "")
                            mail_from = mail_data.get("from", "")
                            mail_date = mail_data.get("date", "")
                            
                            # 检查邮件时间
                            if mail_date:
                                try:
                                    mail_timestamp = None
                                    if isinstance(mail_date, str) and mail_date.isdigit():
                                        mail_timestamp = int(mail_date)
                                    elif isinstance(mail_date, (int, float)):
                                        mail_timestamp = int(mail_date)
                                    else:
                                        try:
                                            from dateutil import parser
                                            parsed_date = parser.parse(mail_date)
                                            mail_timestamp = int(parsed_date.timestamp())
                                        except:
                                            pass
                                    
                                    if mail_timestamp is not None:
                                        current_timestamp = int(time.time())
                                        
                                        # 1. 基础时效性检查（保留原来的5分钟检查）
                                        time_diff_minutes = (current_timestamp - mail_timestamp) / 60
                                        if time_diff_minutes > 5:  # 超过5分钟前的绝对旧邮件
                                            logger.warning(f"❌ 邮件时间超过5分钟（{time_diff_minutes:.1f}分钟前），跳过")
                                            continue
                                            
                                        # 2. 严格时间戳过滤（如果指定了 start_timestamp）
                                        if start_timestamp > 0 and mail_timestamp < (start_timestamp - 60):
                                            logger.warning(f"❌ 忽略旧邮件 (接收时间 {mail_timestamp} < 发送时间 {start_timestamp} - 60s)")
                                            continue
                                            
                                except Exception as e:
                                    pass
                            
                            # 验证收件人是否匹配
                            recipient_match = False
                            target_lower = target_email.lower() if target_email else ""
                            
                            if mail_to and target_lower and target_lower in mail_to.lower():
                                recipient_match = True
                            elif target_lower and target_lower in mail_text.lower():
                                recipient_match = True
                            elif target_lower and target_lower in mail_subject.lower():
                                recipient_match = True
                            
                            # 提前定义 is_cursor_email
                            is_cursor_email = (
                                'cursor' in mail_from.lower() or
                                'no-reply@cursor' in mail_from.lower() or
                                'noreply@cursor' in mail_from.lower()
                            )
                            
                            # 重新检查 Cursor 邮件放行逻辑
                            if not recipient_match and is_cursor_email:
                                logger.warning(f"⚠️ 邮件未明确包含目标邮箱 {target_email}，但发件人是 Cursor，尝试放行！")
                                recipient_match = True

                            if not recipient_match:
                                logger.warning(f"❌ 收件人不匹配 (期望: {target_email}, 实际: {mail_to})")
                                continue
                            
                            if is_cursor_email:
                                logger.info(f"✅ 发现匹配的 Cursor 官方邮件 (ID: {mail_id})")
                                
                                # 提取验证码
                                code = self._extract_code(mail_text, target_email)
                                
                                if not code:
                                     logger.warning(f"⚠️ 常规提取失败，尝试保留邮箱地址提取...")
                                     code = self._extract_code(mail_text, "")
                                
                                if code:
                                    logger.info(f"✅ 提取到验证码: {code}")
                                    return code, mail_id
                                else:
                                    logger.warning(f"⚠️ 未找到验证码")
                
                return None, None
            else:
                return None, None
            
        except Exception as e:
            logger.error(f"获取邮件失败: {e}")
            return None, None

    def _extract_code(self, text, target_email):
        """从文本中提取6位验证码"""
        try:
            if not text:
                return None
            
            # 移除邮箱地址（避免域名被误识别）
            if target_email:
                text = text.replace(target_email, '')
            
            # 使用正则表达式提取 6 位数字验证码
            code_match = re.search(r"(?<![a-zA-Z@.])\b\d{6}\b", text)
            
            if code_match:
                return code_match.group()
            
            return None
            
        except Exception as e:
            logger.error(f"提取验证码失败: {e}")
            return None

    def _cleanup_mail(self, mail_id):
        """删除已读邮件"""
        try:
            receiving_email = self.config['receiving_email']
            pin = self.config['pin']
            
            delete_url = "https://tempmail.plus/api/mails/"
            payload = {
                "email": receiving_email,
                "first_id": mail_id,
                "epin": pin,
            }
            
            for attempt in range(3):
                response = self.session.delete(delete_url, data=payload, timeout=30)
                try:
                    result = response.json().get("result")
                    if result is True:
                        logger.info(f"邮件已删除: {mail_id}")
                        return True
                except:
                    pass
                time.sleep(0.5)
            
            return False
            
        except Exception as e:
            logger.error(f"删除邮件异常: {e}")
            return False





