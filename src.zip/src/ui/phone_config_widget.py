#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
手机接码配置页面
"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QGroupBox, QCheckBox, 
    QLineEdit, QFormLayout, QPushButton, QHBoxLayout
)
from PyQt6.QtCore import Qt, QUrl
from PyQt6.QtGui import QDesktopServices

from ui.styles import CyberTheme
from ui.custom_widgets import CyberMessageBox
from utils.app_paths import resource_path

class PhoneConfigWidget(QWidget):
    """手机接码配置组件"""
    
    def __init__(self, config_manager):
        super().__init__()
        self.config_manager = config_manager
        self.init_ui()
        
    def init_ui(self):
        """初始化 UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)
        
        # 手机验证设置卡片
        self.init_phone_card(layout)

        layout.addStretch()

    def init_phone_card(self, parent_layout):
        """初始化手机验证设置卡片"""
        group = QGroupBox("自定义接码平台配置")
        group.setStyleSheet(f"""
            QGroupBox {{
                font-weight: bold;
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 15px;
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                background-color: {CyberTheme.COLOR_BG_CARD};
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                subcontrol-position: top left;
                left: 15px;
                padding: 0 5px;
                color: {CyberTheme.COLOR_PRIMARY};
            }}
        """)
        
        layout = QVBoxLayout(group)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # 启用开关
        self.phone_enabled_cb = QCheckBox("启用自动接码")
        sms_config = self.config_manager.sms_config
        self.phone_enabled_cb.setChecked(sms_config.enabled)
        
        check_icon_path = resource_path("src/assets/check.svg").as_posix()
        self.phone_enabled_cb.setStyleSheet(f"""
            QCheckBox {{
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                spacing: 8px;
                font-weight: bold;
            }}
            QCheckBox::indicator {{
                width: 18px;
                height: 18px;
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
            }}
            QCheckBox::indicator:checked {{
                background-color: {CyberTheme.COLOR_PRIMARY};
                border-color: {CyberTheme.COLOR_PRIMARY};
                image: url({check_icon_path});
            }}
        """)
        self.phone_enabled_cb.stateChanged.connect(self.on_auto_save)
        layout.addWidget(self.phone_enabled_cb)
        
        # 平台引导行
        guide_layout = QHBoxLayout()
        guide_layout.setSpacing(10)
        
        platform_label = QLabel("接码平台:豪猪码")
        platform_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_PRIMARY}; font-weight: bold;")
        guide_layout.addWidget(platform_label)
        
        reg_btn = QPushButton("注册账号")
        reg_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        reg_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                color: {CyberTheme.COLOR_PRIMARY};
                border: 1px solid {CyberTheme.COLOR_PRIMARY};
                border-radius: 4px;
                padding: 4px 10px;
                font-size: 12px;
            }}
            QPushButton:hover {{
                background-color: {CyberTheme.COLOR_PRIMARY};
                color: {CyberTheme.COLOR_BG_PRIMARY};
            }}
        """)
        reg_btn.clicked.connect(self.open_register_url)
        guide_layout.addWidget(reg_btn)
        
        tutorial_btn = QPushButton("使用说明")
        tutorial_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        tutorial_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: transparent;
                color: {CyberTheme.COLOR_TEXT_SECONDARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
                padding: 4px 10px;
                font-size: 12px;
            }}
            QPushButton:hover {{
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                border-color: {CyberTheme.COLOR_TEXT_PRIMARY};
            }}
        """)
        tutorial_btn.clicked.connect(self.open_tutorial_url)
        guide_layout.addWidget(tutorial_btn)
        
        guide_layout.addStretch()
        layout.addLayout(guide_layout)
        
        # 详细配置表单
        form_layout = QFormLayout()
        form_layout.setContentsMargins(0, 10, 0, 0)
        form_layout.setSpacing(16)
        # 设置标签和字段的伸缩因子，使标签左对齐
        form_layout.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)
        form_layout.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow)
        
        # API 账号
        self.api_user_input = QLineEdit()
        self.api_user_input.setPlaceholderText("请输入API账号")
        self.api_user_input.setText(sms_config.user)
        self.api_user_input.setStyleSheet(self._get_input_style())
        self.api_user_input.setFixedWidth(300)  # 设置固定宽度
        form_layout.addRow(self._create_label("API账号:"), self.api_user_input)
        
        # API 密码
        self.api_pass_input = QLineEdit()
        self.api_pass_input.setPlaceholderText("请输入API密码")
        self.api_pass_input.setText(sms_config.password)
        self.api_pass_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.api_pass_input.setStyleSheet(self._get_input_style())
        self.api_pass_input.setFixedWidth(300)  # 设置固定宽度
        form_layout.addRow(self._create_label("API密码:"), self.api_pass_input)
        
        # 项目 ID
        self.sid_input = QLineEdit()
        self.sid_input.setPlaceholderText("请输入项目ID")
        # 如果 selected_project 是数字或像ID，则显示它；如果是 p1 这种旧格式，尝试转换或清空
        # 这里假设用户已经知道要填什么，如果之前存的是 p1，这里会显示 p1，用户需要手动改为 ID
        # 或者我们可以尝试转换一下
        initial_sid = sms_config.selected_project
        # 如果是默认值 "P1" 或 "p1"，则不显示，让用户重新输入
        if initial_sid and str(initial_sid).lower() == "p1":
            initial_sid = ""
        elif initial_sid and initial_sid in sms_config.sid_map:
             initial_sid = str(sms_config.sid_map[initial_sid])
        self.sid_input.setText(initial_sid)
        self.sid_input.setStyleSheet(self._get_input_style())
        self.sid_input.setFixedWidth(300)  # 设置固定宽度
        form_layout.addRow(self._create_label("项目ID:"), self.sid_input)
        
        layout.addLayout(form_layout)
        
        # 提示信息
        hint_label = QLabel("注：请填写您在接码平台的API账号、API密码及项目ID。配置将直接保存在本地，软件直接请求平台接口，不经过第三方服务器。")
        hint_label.setWordWrap(True)
        hint_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_MUTED}; font-size: 11px; margin-top: 10px;")
        layout.addWidget(hint_label)
        
        # 保存按钮
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        
        self.save_btn = QPushButton("保存配置")
        self.save_btn.setFixedWidth(120)
        self.save_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_PRIMARY};
                color: {CyberTheme.COLOR_BG_PRIMARY};
                border: none;
                border-radius: 4px;
                padding: 6px 12px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: #33ffb2;
            }}
        """)
        self.save_btn.clicked.connect(self.on_save_config)
        btn_layout.addWidget(self.save_btn)
        
        layout.addLayout(btn_layout)
        
        parent_layout.addWidget(group)

    def _get_input_style(self):
        return f"""
            QLineEdit {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
                padding: 6px;
            }}
            QLineEdit:focus {{
                border-color: {CyberTheme.COLOR_PRIMARY};
            }}
        """

    def _create_label(self, text):
        label = QLabel(text)
        label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; font-weight: bold;")
        return label

    def on_auto_save(self, _state=None):
        """仅用于 Checkbox 的自动保存"""
        config = self.config_manager.sms_config
        config.enabled = self.phone_enabled_cb.isChecked()
        self.config_manager.save_config()

    def on_save_config(self, _checked=False):
        """手动保存所有配置"""
        user = self.api_user_input.text().strip()
        password = self.api_pass_input.text().strip()
        sid = self.sid_input.text().strip()
        
        # 验证必填项
        missing_fields = []
        if not user:
            missing_fields.append("API 账号")
        if not password:
            missing_fields.append("API 密码")
        if not sid:
            missing_fields.append("项目 ID")
            
        if missing_fields:
            CyberMessageBox.warning(self, "配置缺失", f"请填写以下信息: {', '.join(missing_fields)}")
            return

        config = self.config_manager.sms_config
        config.enabled = self.phone_enabled_cb.isChecked()
        config.user = user
        config.password = password
        config.selected_project = sid 
        
        self.config_manager.save_config()
        CyberMessageBox.information(self, "保存成功", "接码配置已更新！")

    def open_register_url(self, _checked=False):
        """打开注册链接"""
        url = QUrl("https://h5.haozhuma.com/reg.html?action=luyefei520")
        QDesktopServices.openUrl(url)
        
    def open_tutorial_url(self, _checked=False):
        """打开使用教程链接"""
        url = QUrl("https://docs.qq.com/doc/p/1efed8ba4df72926b241511a6b7e6c6ee14c4451?nlc=1")
        QDesktopServices.openUrl(url)
