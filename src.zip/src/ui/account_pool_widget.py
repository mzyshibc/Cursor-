#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
账户池组件 - 重构版
"""

from typing import List, Optional
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QMenu,
    QMessageBox, QFrame, QLineEdit, QFileDialog
)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer, QUrl
from PyQt6.QtGui import QColor, QDesktopServices
from PyQt6.QtGui import QColor

from core.account_manager import AccountManager, AccountInfo
from utils.config import ConfigManager
from ui.styles import CyberTheme
from ui.custom_widgets import CyberMessageBox


class AccountPoolWidget(QWidget):
    """账户池组件"""

    account_selected = pyqtSignal(AccountInfo)
    account_switched = pyqtSignal(AccountInfo)
    account_deleted = pyqtSignal(int)
    refresh_requested = pyqtSignal()

    def __init__(self, account_manager: AccountManager, parent=None):
        super().__init__(parent)
        self.account_manager = account_manager
        self.config_manager = ConfigManager()
        self.accounts: List[AccountInfo] = []
        self.selected_account: Optional[AccountInfo] = None

        self.init_ui()
        self.setup_connections()
        self.load_accounts()
        self.load_cursor_path()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        # 1. 顶部工具栏 (标题 + 搜索 + 刷新)
        toolbar_layout = QHBoxLayout()
        
        title_label = QLabel("账户管理池")
        title_label.setFont(CyberTheme.get_font(18, True))
        title_label.setStyleSheet(f"color: {CyberTheme.COLOR_PRIMARY};")
        toolbar_layout.addWidget(title_label)

        toolbar_layout.addStretch()

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("搜索邮箱...")
        self.search_input.setFixedWidth(240)
        toolbar_layout.addWidget(self.search_input)

        self.refresh_btn = QPushButton("刷新")
        self.refresh_btn.setFixedWidth(80)
        toolbar_layout.addWidget(self.refresh_btn)
        
        self.add_btn = QPushButton("添加账户")
        self.add_btn.setFixedWidth(80)
        self.add_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_PRIMARY};
                color: white;
                border: none;
                border-radius: 4px;
                padding: 4px;
                font-weight: bold;
            }}
            QPushButton:hover {{ background-color: {CyberTheme.COLOR_PRIMARY_HOVER}; }}
        """)
        toolbar_layout.addWidget(self.add_btn)

        layout.addLayout(toolbar_layout)

        # 1.5 Cursor 启动路径设置
        path_layout = QHBoxLayout()
        path_label = QLabel("Cursor 启动路径:")
        path_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; font-weight: bold;")
        path_layout.addWidget(path_label)

        self.path_input = QLineEdit()
        self.path_input.setPlaceholderText("未设置 (将尝试自动搜索，支持全盘扫描)")
        self.path_input.setReadOnly(True)
        self.path_input.setStyleSheet(f"""
            QLineEdit {{
                background-color: {CyberTheme.COLOR_BG_TERTIARY};
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
                padding: 4px 8px;
            }}
        """)
        path_layout.addWidget(self.path_input)

        self.browse_btn = QPushButton("设置路径")
        self.browse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.browse_btn.setFixedWidth(80)
        self.browse_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_PRIMARY};
                color: white;
                border: none;
                border-radius: 4px;
                padding: 4px;
                font-weight: bold;
            }}
            QPushButton:hover {{ background-color: {CyberTheme.COLOR_PRIMARY_HOVER}; }}
        """)
        self.browse_btn.clicked.connect(self.on_browse_path_clicked)
        path_layout.addWidget(self.browse_btn)
        self.open_config_btn = QPushButton("打开配置目录")
        self.open_config_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.open_config_btn.setFixedWidth(100)
        self.open_config_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
                padding: 4px;
                font-weight: bold;
            }}
            QPushButton:hover {{ border-color: {CyberTheme.COLOR_PRIMARY}; color: {CyberTheme.COLOR_PRIMARY}; }}
        """)
        self.open_config_btn.clicked.connect(self.on_open_config_dir_clicked)
        path_layout.addWidget(self.open_config_btn)
        
        layout.addLayout(path_layout)

        # 2. 统计条 (紧凑的一行)
        self.stats_frame = QFrame()
        self.stats_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
            }}
            QLabel {{
                border: none;
                padding: 4px;
            }}
        """)
        stats_layout = QHBoxLayout(self.stats_frame)
        stats_layout.setContentsMargins(10, 5, 10, 5)
        
        self.stats_labels = {}
        stats_items = [
            ("总数", "total", CyberTheme.COLOR_TEXT_PRIMARY),
            ("活跃", "active", CyberTheme.COLOR_SUCCESS),
            ("Pro版", "pro", CyberTheme.COLOR_ACCENT),
            ("已失效", "expired", CyberTheme.COLOR_TEXT_MUTED),
            ("有效Token", "valid_tokens", CyberTheme.COLOR_SECONDARY)
        ]

        for label, key, color in stats_items:
            container = QHBoxLayout()
            container.setSpacing(5)
            
            lbl_name = QLabel(label)
            lbl_name.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; font-size: 12px;")
            
            lbl_val = QLabel("0")
            lbl_val.setStyleSheet(f"color: {color}; font-weight: bold; font-size: 14px;")
            self.stats_labels[key] = lbl_val
            
            container.addWidget(lbl_name)
            container.addWidget(lbl_val)
            stats_layout.addLayout(container)
            
            if key != "valid_tokens":
                line = QFrame()
                line.setFrameShape(QFrame.Shape.VLine)
                line.setStyleSheet(f"color: {CyberTheme.COLOR_BORDER};")
                stats_layout.addWidget(line)
        
        stats_layout.addStretch()
        layout.addWidget(self.stats_frame)

        # 3. 账户表格
        self.table = QTableWidget()
        self.table.setColumnCount(6) # 减少列数
        self.table.setHorizontalHeaderLabels([
            "邮箱账户", "状态", "Token", "会员类型", "订阅状态", "操作"
        ])
        
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Fixed)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.Fixed)
        header.setSectionResizeMode(4, QHeaderView.ResizeMode.Fixed)
        header.setSectionResizeMode(5, QHeaderView.ResizeMode.Fixed)
        
        self.table.setColumnWidth(1, 100) # 增加宽度以显示完整状态文本
        self.table.setColumnWidth(2, 60)
        self.table.setColumnWidth(3, 80)
        self.table.setColumnWidth(4, 80)
        self.table.setColumnWidth(5, 200) # 保持足够宽度

        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.setShowGrid(False) # 去除网格线，更现代
        self.table.verticalHeader().setVisible(False)
        
        # 4. 确保表格支持滚动
        self.table.setVerticalScrollMode(QTableWidget.ScrollMode.ScrollPerPixel)
        self.table.setHorizontalScrollMode(QTableWidget.ScrollMode.ScrollPerPixel)
        
        layout.addWidget(self.table)

    def setup_connections(self):
        self.search_input.textChanged.connect(self.on_search_text_changed)
        self.refresh_btn.clicked.connect(self.on_refresh_clicked)
        self.add_btn.clicked.connect(self.on_add_account_clicked)
        self.table.itemSelectionChanged.connect(self.on_selection_changed)
        self.table.customContextMenuRequested.connect(self.on_context_menu_requested)
        self.table.cellDoubleClicked.connect(self.on_cell_double_clicked)

    def load_accounts(self):
        try:
            self.accounts = self.account_manager.get_all_accounts()
            
            # ⭐ 排序：按创建时间倒序（最新的在最前面）
            # 假设 AccountInfo 有 created_at 属性，如果没有则按列表默认顺序倒序
            # 实际上 AccountInfo 可能没有 created_at，但 ID 通常是时间戳或者自增
            # 我们可以简单地反转列表，因为通常新添加的在最后
            
            # 如果 AccountInfo 有 created_at 属性
            if self.accounts and hasattr(self.accounts[0], 'created_at'):
                self.accounts.sort(key=lambda x: x.created_at, reverse=True)
            else:
                # 否则简单反转（假设新加的在后面）
                self.accounts.reverse()
                
            self.update_table()
            self.update_statistics()
        except Exception as e:
            print(f"加载账户列表失败: {e}")
            CyberMessageBox.critical(self, "错误", f"加载账户列表失败: {str(e)}")

    def update_table(self, filter_text: str = ""):
        if filter_text:
            filtered_accounts = [
                acc for acc in self.accounts
                if filter_text.lower() in acc.email.lower()
            ]
        else:
            filtered_accounts = self.accounts

        self.table.setRowCount(len(filtered_accounts))

        for row, account in enumerate(filtered_accounts):
            self.table.setRowHeight(row, 42) # 增加行高

            # 邮箱
            email_item = QTableWidgetItem(account.email)
            email_item.setData(Qt.ItemDataRole.UserRole, account.id)
            self.table.setItem(row, 0, email_item)

            # 状态
            if account.status == 'invalid':
                status_text = "已失效"
                status_color = CyberTheme.COLOR_TEXT_MUTED
            else:
                # 只要不是 invalid，都显示活跃 (包括 active, past_due, trialing 等)
                status_text = "活跃"
                # 使用更鲜艳的翡翠绿/荧光绿，更具科技感
                status_color = "#34d399" # Emerald 400
            
            # 检查是否为当前正在使用的账号 (仅当状态有效时)
            current_acc = self.account_manager.get_current_account()
            if current_acc and current_acc.email == account.email and account.status != 'invalid':
                status_text = "正在使用"
                # 使用亮青色/蓝色，区别于普通的活跃
                status_color = "#38bdf8" # Sky 400
            
            # 使用 QLabel 作为单元格小部件以确保样式生效
            status_label = QLabel(status_text)
            status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            
            # 为"正在使用"添加特殊光晕效果
            if status_text == "正在使用":
                 status_style = f"""
                    QLabel {{
                        color: {status_color};
                        font-weight: bold;
                        text-shadow: 0 0 5px {status_color};
                        background-color: rgba(56, 189, 248, 0.1); /* 轻微背景色 */
                        border-radius: 4px;
                        padding: 2px 4px;
                    }}
                """
            else:
                 status_style = f"""
                    QLabel {{
                        color: {status_color};
                        font-weight: bold;
                        background-color: transparent;
                    }}
                """

            status_label.setStyleSheet(status_style)
            self.table.setCellWidget(row, 1, status_label)

            # Token
            token_info = account.get_token_info()
            token_text = "有效" if token_info['token_valid'] else "失效"
            
            # 如果账号状态标记为无效，强制显示为失效
            if account.status == 'invalid':
                token_text = "已失效"
                token_info['token_valid'] = False
            
            # 使用 QLabel 作为单元格小部件
            token_label = QLabel(token_text)
            token_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            
            # Token 有效使用蓝色 (Blue)，失效使用红色 (Red)，已失效使用灰色 - 区分颜色
            if account.status == 'invalid':
                token_color = CyberTheme.COLOR_TEXT_MUTED
            else:
                # 有效Token使用紫色/靛青色，显得更高级且与状态的绿色区分开
                token_color = "#818cf8" if token_info['token_valid'] else "#ef4444" # Indigo 400
            
            token_label.setStyleSheet(f"""
                QLabel {{
                    color: {token_color};
                    font-weight: bold;
                    background-color: transparent;
                }}
            """)
            self.table.setCellWidget(row, 2, token_label)

            # 会员类型 (原订阅类型)
            sub_info = account.get_subscription_status()
            sub_type_str = sub_info['type'].upper()
            
            # 使用 QLabel 以保持样式统一和字体加粗
            type_label = QLabel(sub_type_str)
            type_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            
            # 根据类型设置不同颜色
            if 'PRO' in sub_type_str:
                # PRO 用户：金色/琥珀色，凸显尊贵
                type_style = """
                    QLabel {
                        color: #fbbf24;
                        font-weight: bold;
                        font-size: 13px;
                    }
                """
            elif 'TRIAL' in sub_type_str:
                # 试用：青色
                type_style = """
                    QLabel {
                        color: #22d3ee;
                        font-weight: bold;
                    }
                """
            else:
                # FREE：浅灰色
                type_style = """
                    QLabel {
                        color: #a1a1aa;
                        font-weight: bold;
                    }
                """
            
            type_label.setStyleSheet(type_style)
            self.table.setCellWidget(row, 3, type_label)
            
            # 订阅状态 (原剩余天数)
            # 映射状态文本和颜色
            # 优先用账户主状态作为订阅状态
            current_status = account.status if account.status else 'active'
            
            status_map = {
                'active': ('正常', CyberTheme.COLOR_SUCCESS),
                'unpaid': ('未付款', CyberTheme.COLOR_DANGER),
                'past_due': ('逾期', CyberTheme.COLOR_WARNING),
                'canceled': ('已取消', CyberTheme.COLOR_TEXT_MUTED),
                'incomplete': ('未完成', CyberTheme.COLOR_WARNING),
                'incomplete_expired': ('未完成且过期', CyberTheme.COLOR_TEXT_MUTED),
                'trialing': ('试用中', CyberTheme.COLOR_ACCENT),
                'paused': ('已暂停', CyberTheme.COLOR_TEXT_MUTED)
            }
            
            # 获取状态
            # 使用上面设置的 current_status
            
            # 如果是 Free 账号且状态是 active，显示"免费版"
            # 注意：如果状态是 invalid，优先显示"已失效"
            is_rainbow = False
            if current_status == 'invalid':
                display_text, color = ("已失效", CyberTheme.COLOR_TEXT_MUTED) # 深灰色
            elif sub_info['type'] == 'free' and current_status == 'active':
                 display_text, color = ("免费版", "transparent") # 使用彩虹色背景，文字颜色需特殊处理
                 is_rainbow = True
            else:
                 display_text, color = status_map.get(current_status, (current_status, CyberTheme.COLOR_TEXT_PRIMARY))
            
            # 额外调整：如果是已取消，颜色区分
            if current_status == 'canceled':
                 color = "#f87171" # Red 400 (淡红色)
            elif current_status == 'past_due':
                 color = CyberTheme.COLOR_WARNING # 保持警告色
            
            # 使用 QLabel 作为单元格小部件
            status_label = QLabel(display_text)
            status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            
            if is_rainbow:
                status_label.setStyleSheet(f"""
                    QLabel {{
                        color: white;
                        font-weight: bold;
                        background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #f472b6, stop:0.5 #a78bfa, stop:1 #22d3ee);
                        border-radius: 4px;
                        padding: 2px 8px;
                    }}
                """)
            else:
                status_label.setStyleSheet(f"""
                    QLabel {{
                        color: {color};
                        font-weight: bold;
                        background-color: transparent;
                    }}
                """)
            self.table.setCellWidget(row, 4, status_label)

            # 操作按钮
            action_widget = self.create_action_widget(account)
            self.table.setCellWidget(row, 5, action_widget)

    def create_action_widget(self, account: AccountInfo) -> QWidget:
        widget = QWidget()
        layout = QHBoxLayout(widget)
        layout.setContentsMargins(2, 2, 2, 2)
        layout.setSpacing(4)


        # 切换按钮 - 核心操作，保持醒目的蓝色，引导用户点击
        switch_btn = QPushButton("切换")
        switch_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        switch_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: rgba(56, 189, 248, 0.1);
                border: 1px solid #38bdf8;
                color: #38bdf8;
                border-radius: 3px;
                padding: 2px 6px;
                font-size: 11px;
                min-width: 30px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: #38bdf8;
                color: #ffffff;
            }}
        """)
        switch_btn.clicked.connect(lambda: self.on_switch_account(account))

        # 详情按钮 - 辅助操作，平时显示为灰色，悬停时显示紫色
        detail_btn = QPushButton("详情")
        detail_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        detail_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: transparent;
                border: 1px solid #52525b; /* Zinc 600 - 低调的深灰边框 */
                color: #a1a1aa; /* Zinc 400 - 浅灰文字 */
                border-radius: 3px;
                padding: 2px 6px;
                font-size: 11px;
                min-width: 30px;
            }}
            QPushButton:hover {{
                border-color: #818cf8; /* 悬停变紫 */
                color: #818cf8;
            }}
        """)
        detail_btn.clicked.connect(lambda: self.on_show_details(account))

        # 更新按钮 - 辅助操作，平时显示为灰色，悬停时显示绿色
        update_btn = QPushButton("更新")
        update_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        update_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: transparent;
                border: 1px solid #52525b; /* Zinc 600 */
                color: #a1a1aa; /* Zinc 400 */
                border-radius: 3px;
                padding: 2px 6px;
                font-size: 11px;
                min-width: 30px;
            }}
            QPushButton:hover {{
                border-color: #34d399; /* 悬停变绿 */
                color: #34d399;
            }}
        """)
        update_btn.clicked.connect(lambda: self.on_update_account(account))

        # 删除按钮 - 危险操作，保持红色，但稍微降低亮度，悬停时高亮
        del_btn = QPushButton("删除")
        del_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        del_btn.setToolTip("删除账户")
        del_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: transparent;
                border: 1px solid #7f1d1d; /* Red 900 - 暗红边框，不刺眼 */
                color: #f87171; /* Red 400 - 文字保持淡红 */
                border-radius: 3px;
                padding: 2px 6px;
                font-size: 11px;
                min-width: 30px;
            }}
            QPushButton:hover {{
                background-color: #ef4444;
                border-color: #ef4444;
                color: white;
            }}
        """)
        del_btn.clicked.connect(lambda: self.on_delete_account(account))

        layout.addStretch(1) # 左侧弹性大一点
        layout.addWidget(switch_btn)
        layout.addWidget(detail_btn)
        layout.addWidget(update_btn)  # 添加更新按钮
        layout.addWidget(del_btn)
        # 右侧不留间距，完全贴边
        return widget

    def update_statistics(self):
        try:
            summary = self.account_manager.get_accounts_summary()
            self.stats_labels['total'].setText(str(summary['total_accounts']))
            self.stats_labels['active'].setText(str(summary['active_accounts']))
            self.stats_labels['pro'].setText(str(summary['pro_accounts']))
            self.stats_labels['expired'].setText(str(summary['expired_accounts']))
            self.stats_labels['valid_tokens'].setText(str(summary['valid_tokens']))
        except Exception:
            pass

    def on_search_text_changed(self, text: str):
        self.update_table(text)

    def on_refresh_clicked(self, _checked=False):
        self.search_input.clear() # 清空搜索，确保显示所有
        self.refresh_btn.setEnabled(False)
        self.refresh_btn.setText("刷新中...")
        QTimer.singleShot(500, self._do_refresh)

    def _do_refresh(self):
        self.refresh_requested.emit()
        self.load_accounts()
        self.refresh_btn.setEnabled(True)
        self.refresh_btn.setText("刷新")
        CyberMessageBox.information(self, "刷新完成", "账户列表已更新")

    def on_add_account_clicked(self, _checked=False):
        from ui.add_account_dialog import AddAccountDialog
        dialog = AddAccountDialog(self)
        dialog.account_added.connect(self.on_account_added)
        dialog.exec()

    def on_account_added(self, account: AccountInfo):
        result = self.account_manager.add_account(account)

        # 移除弹窗，直接刷新列表并显示状态栏提示（如果主窗口支持）
        self.load_accounts()
        # CyberMessageBox.information(self, "成功", "账户添加成功！") # 已禁用

    def on_selection_changed(self):
        current_row = self.table.currentRow()
        if current_row >= 0:
            account_id = self.table.item(current_row, 0).data(Qt.ItemDataRole.UserRole)
            account = next((acc for acc in self.accounts if acc.id == account_id), None)
            if account:
                self.selected_account = account
                self.account_selected.emit(account)

    def on_cell_double_clicked(self, row: int, column: int):
        if column == 5: return
        account_id = self.table.item(row, 0).data(Qt.ItemDataRole.UserRole)
        account = next((acc for acc in self.accounts if acc.id == account_id), None)
        if account:
            self.on_show_details(account)

    def on_context_menu_requested(self, position):
        row = self.table.rowAt(position.y())
        if row < 0: return
        account_id = self.table.item(row, 0).data(Qt.ItemDataRole.UserRole)
        account = next((acc for acc in self.accounts if acc.id == account_id), None)
        if not account: return

        menu = QMenu(self)
        menu.setStyleSheet(f"""
            QMenu {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
            }}
            QMenu::item {{
                padding: 5px 20px;
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
            }}
            QMenu::item:selected {{
                background-color: {CyberTheme.COLOR_BG_TERTIARY};
            }}
        """)

        menu.addAction("切换到此账户", lambda: self.on_switch_account(account))
        menu.addAction("查看详情", lambda: self.on_show_details(account))
        menu.addAction("刷新信息", lambda: self.on_refresh_account(account))
        menu.addSeparator()
        
        del_action = menu.addAction("删除账户", lambda: self.on_delete_account(account))
        del_action.setStyleSheet(f"color: {CyberTheme.COLOR_DANGER};")

        menu.exec(self.table.mapToGlobal(position))

    def on_switch_account(self, account: AccountInfo):
        reply = CyberMessageBox.question(
            self, "确认切换",
            f"确定要切换到账户：{account.email}？"
        )
        if reply == QMessageBox.StandardButton.Yes:
            success, message = self.account_manager.switch_to_account(account.id)
            if success:
                CyberMessageBox.information(self, "切换成功", message)
                self.account_switched.emit(account)
                self.load_accounts()  # 强制刷新列表以显示"正在使用"状态
            else:
                CyberMessageBox.critical(self, "切换失败", message)

    def on_update_account(self, account: AccountInfo):
        """处理更新按钮点击"""
        self.refresh_btn.setEnabled(False) # 暂时禁用全局刷新防止冲突
        success, message = self.account_manager.refresh_account_info(account.id)
        self.refresh_btn.setEnabled(True)
        
        if success:
            CyberMessageBox.information(self, "更新成功", message)
            self.load_accounts()
        else:
            CyberMessageBox.warning(self, "更新失败", message)
            self.load_accounts() # 即使失败也要刷新，因为状态可能已变为 invalid

    def on_show_details(self, account: AccountInfo):
        from ui.account_detail_dialog import AccountDetailDialog
        dialog = AccountDetailDialog(account, self.account_manager, self)
        dialog.exec()

    def on_refresh_account(self, account: AccountInfo):
        success, message = self.account_manager.refresh_account_info(account.id)
        if success:
            CyberMessageBox.information(self, "刷新成功", message)
            self.load_accounts()
        else:
            CyberMessageBox.warning(self, "刷新失败", message)

    def on_delete_account(self, account: AccountInfo):
        reply = CyberMessageBox.question(
            self, "确认删除",
            f"确定要删除账户：{account.email}？"
        )
        if reply == QMessageBox.StandardButton.Yes:
            if self.account_manager.delete_account(account.id):
                self.account_deleted.emit(account.id)
                self.load_accounts()

    def add_account(self, account: AccountInfo):
        self.accounts.append(account)
        self.update_table()
        self.update_statistics()

    def load_cursor_path(self):
        try:
            path = self.config_manager.get_system_config().cursor_path
            if path:
                self.path_input.setText(path)
            else:
                self.path_input.clear()
        except Exception as e:
            print(f"加载 Cursor 路径失败: {e}")

    def on_browse_path_clicked(self, _checked=False):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "选择 Cursor 可执行文件", 
            self.path_input.text() or "C:/", 
            "Executable Files (*.exe);;All Files (*)"
        )
        if file_path:
            self.path_input.setText(file_path)
            
            # [关键修复] 重新加载完整配置 -> 修改 -> 保存
            # 避免直接获取 config 对象后修改，因为 get_system_config 返回的可能是副本或未同步的状态
            # 并且确保 config_manager.system_config 是最新的
            
            try:
                # 重新从文件加载一次确保最新
                self.config_manager.load_config() 
                
                # 更新内存中的配置
                self.config_manager.system_config.cursor_path = file_path
                
                # 保存配置
                self.config_manager.save_config()
                
                # 再次验证保存是否成功
                # print(f"DEBUG: Saved cursor_path: {self.config_manager.system_config.cursor_path}")
                
                CyberMessageBox.information(self, "设置成功", "Cursor 启动路径已更新")
            except Exception as e:
                CyberMessageBox.warning(self, "保存失败", f"配置保存失败: {str(e)}")
    def on_open_config_dir_clicked(self, _checked=False):
        try:
            cm = self.config_manager
            cm.load_config()
            config_dir = cm.config_dir
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(config_dir)))
        except Exception as e:
            CyberMessageBox.warning(self, "打开失败", f"无法打开配置目录: {str(e)}")
