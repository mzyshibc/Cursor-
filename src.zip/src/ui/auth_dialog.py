#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
授权对话框 - 重构版
"""

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QProgressBar, QWidget
)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QMouseEvent

from utils.config import ConfigManager
from utils.license_validator import LicenseValidator
from ui.styles import CyberTheme
from ui.custom_widgets import RainbowTitleLabel


class AuthDialog(QDialog):
    """授权对话框"""

    # 信号定义
    auth_success = pyqtSignal(dict)  # 授权成功信号

    def __init__(self, config_manager: ConfigManager, parent=None):
        super().__init__(parent)
        self.config_manager = config_manager
        self.license_validator = LicenseValidator(config_manager)
        self._drag_pos = None

        self.setWindowTitle("Cursor VIP - 授权验证")
        self.setModal(True)
        self.setFixedSize(420, 320)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Dialog)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        self.init_ui()
        self.setup_connections()

    def init_ui(self):
        """初始化UI"""
        # 主容器
        main_widget = QWidget(self)
        main_widget.setGeometry(0, 0, self.width(), self.height())
        main_widget.setStyleSheet(f"""
            QWidget {{
                background-color: {CyberTheme.COLOR_BG_PRIMARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 8px;
            }}
        """)
        
        layout = QVBoxLayout(main_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # 1. 标题栏
        title_bar = QWidget()
        title_bar.setFixedHeight(40)
        title_bar.setStyleSheet(f"""
            QWidget {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                border-bottom: 1px solid {CyberTheme.COLOR_BORDER};
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                border-bottom-left-radius: 0;
                border-bottom-right-radius: 0;
                border: none;
                border-bottom: 1px solid {CyberTheme.COLOR_BORDER};
            }}
        """)
        title_layout = QHBoxLayout(title_bar)
        title_layout.setContentsMargins(16, 0, 8, 0)
        
        # 跑马灯标题
        title_label = RainbowTitleLabel("授权验证", font_size=14, bold=True)
        title_layout.addWidget(title_label)
        
        title_layout.addStretch()
        
        close_btn = QPushButton("✕")
        close_btn.setFixedSize(32, 24)
        close_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: transparent;
                border: none;
                border-radius: 4px;
                color: {CyberTheme.COLOR_TEXT_SECONDARY};
                font-family: "Segoe MDL2 Assets", "Segoe UI Symbol", sans-serif;
                font-size: 12px;
                padding: 0;
            }}
            QPushButton:hover {{
                background-color: {CyberTheme.COLOR_DANGER};
                color: #ffffff;
            }}
        """)
        close_btn.clicked.connect(self.reject)
        title_layout.addWidget(close_btn)
        
        layout.addWidget(title_bar)

        # 2. 内容区域
        content_widget = QWidget()
        content_widget.setStyleSheet("background-color: transparent; border: none;")
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(24, 24, 24, 24)
        content_layout.setSpacing(16)

        subtitle_label = QLabel("请输入您的VIP授权码以激活软件")
        subtitle_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; font-size: 13px; border: none;")
        content_layout.addWidget(subtitle_label)

        # 授权码输入
        input_container = QWidget()
        input_container.setStyleSheet("background-color: transparent; border: none;")
        input_layout = QVBoxLayout(input_container)
        input_layout.setContentsMargins(0, 0, 0, 0)
        input_layout.setSpacing(8)

        self.license_input = QLineEdit()
        self.license_input.setPlaceholderText("请输入授权码...")
        self.license_input.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.license_input.setStyleSheet(f"""
            QLineEdit {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
                padding: 10px;
                font-size: 14px;
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                font-family: Consolas, monospace;
            }}
            QLineEdit:focus {{
                border-color: {CyberTheme.COLOR_PRIMARY};
                background-color: {CyberTheme.COLOR_BG_TERTIARY};
            }}
        """)
        input_layout.addWidget(self.license_input)
        content_layout.addWidget(input_container)

        # 进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setFixedHeight(4)
        self.progress_bar.setTextVisible(False)
        content_layout.addWidget(self.progress_bar)

        # 状态标签
        self.status_label = QLabel("")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.status_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_MUTED}; font-size: 12px; border: none;")
        content_layout.addWidget(self.status_label)

        content_layout.addStretch()

        # 3. 按钮区域
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(12)

        self.cancel_btn = QPushButton("取消")
        self.cancel_btn.setMinimumHeight(32)
        self.cancel_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                border-radius: 4px;
            }}
            QPushButton:hover {{
                background-color: {CyberTheme.COLOR_BG_TERTIARY};
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
            }}
        """)

        self.activate_btn = QPushButton("立即激活")
        self.activate_btn.setMinimumHeight(32)
        self.activate_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_PRIMARY};
                color: #ffffff;
                border: none;
                border-radius: 4px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: {CyberTheme.COLOR_PRIMARY_HOVER};
            }}
            QPushButton:disabled {{
                background-color: {CyberTheme.COLOR_BG_TERTIARY};
                color: {CyberTheme.COLOR_TEXT_MUTED};
            }}
        """)

        btn_layout.addWidget(self.cancel_btn)
        btn_layout.addWidget(self.activate_btn)
        content_layout.addLayout(btn_layout)

        layout.addWidget(content_widget)

    def setup_connections(self):
        self.cancel_btn.clicked.connect(self.reject)
        self.activate_btn.clicked.connect(self.on_activate_clicked)
        self.license_input.returnPressed.connect(self.on_activate_clicked)

    def on_activate_clicked(self, _checked=False):
        license_key = self.license_input.text().strip()
        if not license_key:
            self.shake_window()
            return

        self.activate_btn.setEnabled(False)
        self.activate_btn.setText("验证中...")
        self.license_input.setEnabled(False)
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 0)
        self.status_label.setText("正在连接服务器...")
        
        QTimer.singleShot(500, lambda: self.do_activation(license_key))

    def do_activation(self, license_key: str):
        try:
            success, result = self.license_validator.activate_license(license_key)
            if success:
                self.status_label.setText("激活成功！")
                self.status_label.setStyleSheet(f"color: {CyberTheme.COLOR_SUCCESS}; font-weight: bold; border: none;")
                self.progress_bar.setVisible(False)
                self.auth_success.emit(result)
                QTimer.singleShot(1000, self.accept)
            else:
                error_msg = result.get('message', '激活失败')
                self.status_label.setText(f"失败: {error_msg}")
                self.status_label.setStyleSheet(f"color: {CyberTheme.COLOR_DANGER}; border: none;")
                self.reset_ui()
                self.shake_window()
        except Exception as e:
            self.status_label.setText(f"错误: {str(e)}")
            self.reset_ui()

    def reset_ui(self):
        self.activate_btn.setEnabled(True)
        self.activate_btn.setText("立即激活")
        self.license_input.setEnabled(True)
        self.progress_bar.setVisible(False)
        self.license_input.setFocus()

    def shake_window(self):
        # 简单震动效果提示错误
        original_pos = self.pos()
        QTimer.singleShot(0, lambda: self.move(original_pos.x() + 5, original_pos.y()))
        QTimer.singleShot(50, lambda: self.move(original_pos.x() - 5, original_pos.y()))
        QTimer.singleShot(100, lambda: self.move(original_pos.x() + 5, original_pos.y()))
        QTimer.singleShot(150, lambda: self.move(original_pos.x(), original_pos.y()))

    # --- 窗口拖动逻辑 ---
    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            if event.position().y() < 40:
                self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
                event.accept()

    def mouseMoveEvent(self, event: QMouseEvent):
        if event.buttons() == Qt.MouseButton.LeftButton and self._drag_pos:
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def mouseReleaseEvent(self, event: QMouseEvent):
        self._drag_pos = None
