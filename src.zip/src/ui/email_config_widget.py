#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
邮箱配置组件 - 重构版
"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox,
    QLineEdit, QPushButton, QButtonGroup, QCheckBox, QSpinBox, QFormLayout, QFrame,
    QStackedWidget, QTextEdit
)


from core.backend_api import BackendAPI
from core.email_handler import EmailHandler
from utils.config import ConfigManager, EmailConfig
from ui.styles import CyberTheme
from ui.custom_widgets import CyberMessageBox

class EmailConfigWidget(QWidget):
    """邮箱配置组件"""

    def __init__(self, config_manager: ConfigManager, parent=None):
        super().__init__(parent)
        self.config_manager = config_manager
        self.email_handler = None
        
        # 初始化后端 API
        # 传入 config 字典
        self.backend_api = BackendAPI(self.config_manager.config)
        # 系统动态配置缓存
        self.system_email_config = {}

        self.init_ui()
        
        # 异步加载系统配置
        self.load_system_config()
        
        self.load_config()

    def load_system_config(self):
        """加载系统动态配置"""
        try:
            config = self.backend_api.get_system_config()
            if config:
                self.system_email_config = config
                self.update_ui_options()
        except Exception as e:
            print(f"加载系统配置失败: {e}")

    def update_ui_options(self):
        """根据系统配置更新 UI 选项"""
        if not self.system_email_config:
            return

        # 1. 更新 TempMail 域名列表
        # 无论是否有配置，都应该刷新列表，以支持"后端删除配置前端同步删除"的需求
        tempmail_domains = self.system_email_config.get('tempmail_domains', [])
        
        current_idx = self.domain_combo.currentIndex()
        current_text = self.domain_combo.currentText()
        
        self.domain_combo.clear()
        
        if tempmail_domains:
            # 倒序遍历，确保新添加的（在列表末尾的）显示在最前面
            for item in reversed(tempmail_domains):
                name = item.get('name', '')
                domain = item.get('domain', '')
                self.domain_combo.addItem(f"{name} ({domain})", item)
        
        self.domain_combo.addItem("自定义域名 (手动配置)")
        
        # 尝试恢复选中项
        found = False
        for i in range(self.domain_combo.count()):
            if current_text in self.domain_combo.itemText(i):
                self.domain_combo.setCurrentIndex(i)
                found = True
                break
        if not found:
            self.domain_combo.setCurrentIndex(0)

        # 2. 更新 IMAP 配置提示
        imap_config = self.system_email_config.get('imap_config', {})
        if imap_config:
            server = imap_config.get('server', '2925.com')
            user = imap_config.get('username', 'default')
            self.default_imap_info.setText(f"使用系统内置的 {server} 邮箱服务\n账号: {user}\n无需手动填写服务器信息")
        else:
            # 如果配置被清空，恢复默认显示或提示暂无配置
            self.default_imap_info.setText("系统内置邮箱服务暂不可用\n请使用自定义配置")

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(16)

        # 标题
        header_layout = QHBoxLayout()
        title_label = QLabel("邮箱配置")
        title_label.setFont(CyberTheme.get_font(18, True))
        title_label.setStyleSheet(f"color: {CyberTheme.COLOR_PRIMARY};")
        header_layout.addWidget(title_label)
        layout.addLayout(header_layout)

        # 模式切换 - 使用类似 Tab 的按钮组
        mode_container = QWidget()
        mode_layout = QHBoxLayout(mode_container)
        mode_layout.setContentsMargins(0, 0, 0, 0)
        mode_layout.setSpacing(10)
        
        self.mode_group = QButtonGroup(self)
        
        self.tempmail_btn = QPushButton("TempMail 模式")
        self.tempmail_btn.setCheckable(True)
        self.tempmail_btn.setChecked(True)
        self.tempmail_btn.setMinimumHeight(32)
        self.tempmail_btn.setStyleSheet(self._get_tab_style())
        self.mode_group.addButton(self.tempmail_btn, 0)
        
        self.imap_btn = QPushButton("IMAP 模式")
        self.imap_btn.setCheckable(True)
        self.imap_btn.setMinimumHeight(32)
        self.imap_btn.setStyleSheet(self._get_tab_style())
        self.mode_group.addButton(self.imap_btn, 1)
        
        mode_layout.addWidget(self.tempmail_btn)
        mode_layout.addWidget(self.imap_btn)
        mode_layout.addStretch()
        
        layout.addWidget(mode_container)

        # 配置堆栈
        self.stack = QStackedWidget()
        
        # 1. TempMail 页面
        self.tempmail_page = QWidget()
        self._init_tempmail_ui()
        self.stack.addWidget(self.tempmail_page)
        
        # 2. IMAP 页面
        self.imap_page = QWidget()
        self._init_imap_ui()
        self.stack.addWidget(self.imap_page)
        
        layout.addWidget(self.stack)
        
        layout.addStretch() # 底部弹簧

        # 底部操作栏
        action_bar = QFrame()
        action_bar.setStyleSheet(f"""
            QFrame {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                border-top: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
            }}
        """)
        action_layout = QHBoxLayout(action_bar)
        action_layout.setContentsMargins(16, 12, 16, 12)
        
        self.status_label = QLabel("")
        action_layout.addWidget(self.status_label)
        
        action_layout.addStretch()
        
        self.test_btn = QPushButton("测试连接")
        self.test_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_BG_TERTIARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
            }}
            QPushButton:hover {{
                border-color: {CyberTheme.COLOR_PRIMARY};
            }}
        """)
        
        self.save_btn = QPushButton("保存并生效")
        self.save_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_PRIMARY};
                color: {CyberTheme.COLOR_BG_PRIMARY};
                font-weight: bold;
                border: none;
            }}
            QPushButton:hover {{
                background-color: #33ffb2;
            }}
        """)
        
        action_layout.addWidget(self.test_btn)
        action_layout.addWidget(self.save_btn)
        
        layout.addWidget(action_bar)

        self.setup_connections()

    def _get_tab_style(self):
        return f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                color: {CyberTheme.COLOR_TEXT_SECONDARY};
                border-radius: 4px;
                padding: 4px 16px;
                font-weight: bold;
            }}
            QPushButton:checked {{
                background-color: {CyberTheme.COLOR_PRIMARY};
                color: {CyberTheme.COLOR_BG_PRIMARY};
                border-color: {CyberTheme.COLOR_PRIMARY};
            }}
            QPushButton:hover:!checked {{
                border-color: {CyberTheme.COLOR_TEXT_PRIMARY};
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
            }}
        """

    def _init_tempmail_ui(self):
        layout = QVBoxLayout(self.tempmail_page)
        layout.setContentsMargins(0, 0, 0, 0)
        
        form_frame = QFrame()
        form_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {CyberTheme.COLOR_BG_CARD};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 6px;
            }}
        """)
        form_layout = QFormLayout(form_frame)
        form_layout.setContentsMargins(20, 20, 20, 20)
        form_layout.setSpacing(16)
        
        # 域名选择
        self.domain_combo = QComboBox()
        # 初始只添加自定义，确保完全依赖服务器返回（或者依赖 update_ui_options 的刷新）
        # 但为了用户体验（避免刚打开时空白），可以先保留硬编码的默认值，
        # 等 load_system_config 返回后再覆盖。
        # 不过用户担心"删除了客户端也会删除"，所以这里应该只保留"自定义"，
        # 或者在 init 时留空，等 load 完成。
        # 为了稳妥，我们在这里不做预设，只添加"自定义"，
        # 这样如果没有网络或服务器删除了，用户就只能看到"自定义"。
        self.domain_combo.addItem("自定义域名 (手动配置)")
        
        form_layout.addRow("选择域名:", self.domain_combo)
        
        # 默认选中第一个 (mzyota)
        self.domain_combo.setCurrentIndex(0)
        
        # TempMail 默认配置信息 (只读显示)
        self.tempmail_default_info = QLabel("使用系统自动分配的临时邮箱\n无需手动填写信息")
        self.tempmail_default_info.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; font-size: 12px;")
        form_layout.addRow("", self.tempmail_default_info)

        # TempMail 常规配置 (隐藏，仅作为数据存储)
        self.tempmail_email_input = QLineEdit()
        self.tempmail_email_input.setVisible(False)
        self.tempmail_pin_input = QLineEdit()
        self.tempmail_pin_input.setVisible(False)
        
        # 自定义域名配置 (默认隐藏)
        self.custom_config_widget = QWidget()
        custom_layout = QFormLayout(self.custom_config_widget)
        custom_layout.setContentsMargins(0, 0, 0, 0)
        
        self.custom_receiving_email_input = QLineEdit()
        self.custom_receiving_email_input.setPlaceholderText("yourname@tempmail.plus")
        custom_layout.addRow("TempMail邮箱:", self.custom_receiving_email_input)
        
        self.custom_pin_input = QLineEdit()
        self.custom_pin_input.setEchoMode(QLineEdit.EchoMode.Password)
        custom_layout.addRow("PIN码:", self.custom_pin_input)
        
        self.custom_domain_input = QLineEdit()
        self.custom_domain_input.setPlaceholderText("yourdomain.com")
        custom_layout.addRow("显示域名:", self.custom_domain_input)
        
        # 添加自定义域名配置指南 (使用 QTextEdit 支持 HTML)
        self.guide_label = QTextEdit()
        self.guide_label.setReadOnly(True)
        self.guide_label.setStyleSheet(f"""
            QTextEdit {{
                background-color: transparent;
                border: none;
                color: {CyberTheme.COLOR_TEXT_SECONDARY};
                font-size: 12px;
                margin-top: 10px;
            }}
        """)
        self.guide_label.setMinimumHeight(200)  # 设置最小高度确保可见
        
        guide_text = """
        <div style='line-height: 1.4;'>
        <b>TempMail 自定义域名转发配置指南</b><br>
        利用 Cloudflare Email Routing 实现用自己的域名接收 TempMail 邮件。<br>
        <br>
        <b>步骤 1: 准备 TempMail 邮箱</b><br>
        1. 访问 <a href='https://tempmail.plus' style='color: #00aaff;'>tempmail.plus</a><br>
        2. 设置一个 PIN 码（密码）并记住它。<br>
        3. 获取分配的临时邮箱地址（例如 <code>mybox@tempmail.plus</code>）。<br>
        <br>
        <b>步骤 2: 配置 Cloudflare 域名转发</b><br>
        1. 登录 Cloudflare 控制台，进入你的域名管理页面。<br>
        2. 点击左侧菜单的 <b>Email (电子邮件)</b> > <b>Email Routing (路由)</b>。<br>
        3. 在 <b>Destination addresses (目标地址)</b> 中添加你的 TempMail 邮箱 (<code>mybox@tempmail.plus</code>)，并按提示验证（需在 tempmail.plus 查收验证邮件）。<br>
        4. 在 <b>Custom addresses (自定义地址)</b> 中创建规则：<br>
           - Custom address: 填入你想用的前缀（如 <code>cursor</code>），域名选你的域名。<br>
           - Action: <code>Send to</code><br>
           - Destination: 选择刚才添加的 <code>mybox@tempmail.plus</code>。<br>
           - 状态设为 <b>Active</b>。<br>
        <br>
        <b>步骤 3: 填写本软件配置</b><br>
        1. <b>TempMail邮箱</b>: 填入你的目标邮箱 (<code>mybox@tempmail.plus</code>)。<br>
        2. <b>PIN码</b>: 填入你在 TempMail 设置的 PIN。<br>
        3. <b>显示域名</b>: 填入你的自定义域名 (<code>yourdomain.com</code>)。<br>
        <br>
        <i>配置完成后，所有发往 <code>cursor@yourdomain.com</code> 的邮件都会自动转发到 TempMail，软件即可自动读取验证码。</i>
        </div>
        """
        self.guide_label.setHtml(guide_text)
        
        custom_layout.addRow(self.guide_label)
        
        form_layout.addRow(self.custom_config_widget)

        # 添加 TempMail 网络提示
        self.tempmail_network_warning = QLabel("⚠️ 注意：TempMail 服务位于海外，此模式需要连接国际网络（开启代理/VPN）才能正常接收验证码。如没有代理软件可使用 IMAP 模式。")
        self.tempmail_network_warning.setWordWrap(True)
        self.tempmail_network_warning.setStyleSheet(f"""
            QLabel {{
                color: {CyberTheme.COLOR_WARNING};
                font-size: 12px;
                padding: 8px;
                background-color: rgba(255, 165, 0, 0.1);
                border: 1px solid {CyberTheme.COLOR_WARNING};
                border-radius: 4px;
                margin-top: 10px;
            }}
        """)
        form_layout.addRow(self.tempmail_network_warning)
        
        layout.addWidget(form_frame)
        layout.addStretch()

    def _init_imap_ui(self):
        layout = QVBoxLayout(self.imap_page)
        layout.setContentsMargins(0, 0, 0, 0)
        
        form_frame = QFrame()
        form_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {CyberTheme.COLOR_BG_CARD};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 6px;
            }}
        """)
        form_layout = QFormLayout(form_frame)
        form_layout.setContentsMargins(20, 20, 20, 20)
        form_layout.setSpacing(16)
        
        # 域名选择
        self.imap_domain_combo = QComboBox()
        self.imap_domain_combo.addItems([
            "2925 (系统默认)",
            "自定义 IMAP (手动配置)"
        ])
        form_layout.addRow("选择配置:", self.imap_domain_combo)
        
        # 2925 默认配置信息 (只读显示)
        self.default_imap_info = QLabel("使用系统内置的 2925.com 邮箱服务\n无需手动填写服务器信息")
        self.default_imap_info.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; font-size: 12px;")
        form_layout.addRow("", self.default_imap_info)
        
        # 自定义 IMAP 配置区域 (默认隐藏)
        self.custom_imap_widget = QWidget()
        custom_imap_layout = QFormLayout(self.custom_imap_widget)
        custom_imap_layout.setContentsMargins(0, 0, 0, 0)
        custom_imap_layout.setSpacing(16)

        self.imap_server_input = QLineEdit()
        self.imap_server_input.setPlaceholderText("imap.gmail.com")
        custom_imap_layout.addRow("IMAP服务器:", self.imap_server_input)
        
        port_box = QWidget()
        port_layout = QHBoxLayout(port_box)
        port_layout.setContentsMargins(0, 0, 0, 0)
        
        self.imap_port_input = QSpinBox()
        self.imap_port_input.setRange(1, 65535)
        self.imap_port_input.setValue(993)
        self.imap_port_input.setFixedWidth(80)
        
        self.imap_ssl_checkbox = QCheckBox("SSL/TLS")
        self.imap_ssl_checkbox.setChecked(True)
        
        port_layout.addWidget(self.imap_port_input)
        port_layout.addWidget(self.imap_ssl_checkbox)
        port_layout.addStretch()
        
        custom_imap_layout.addRow("端口:", port_box)
        
        self.imap_email_input = QLineEdit()
        self.imap_email_input.setPlaceholderText("user@gmail.com")
        custom_imap_layout.addRow("邮箱账号:", self.imap_email_input)
        
        self.imap_password_input = QLineEdit()
        self.imap_password_input.setPlaceholderText("应用专用密码")
        self.imap_password_input.setEchoMode(QLineEdit.EchoMode.Password)
        custom_imap_layout.addRow("密码/令牌:", self.imap_password_input)
        
        self.imap_folder_input = QLineEdit()
        self.imap_folder_input.setText("INBOX")
        custom_imap_layout.addRow("文件夹:", self.imap_folder_input)
        
        # 添加自定义 IMAP 配置指南
        self.imap_guide_label = QTextEdit()
        self.imap_guide_label.setReadOnly(True)
        self.imap_guide_label.setStyleSheet(f"""
            QTextEdit {{
                background-color: transparent;
                border: none;
                color: {CyberTheme.COLOR_TEXT_SECONDARY};
                font-size: 12px;
                margin-top: 10px;
            }}
        """)
        self.imap_guide_label.setMinimumHeight(150)
        
        imap_guide_text = """
        <div style='line-height: 1.4;'>
        <b>自定义 IMAP 配置指南</b><br>
        如果您拥有自己的域名邮箱（如企业邮箱）或支持 IMAP 的邮箱（如 Gmail），可以使用此模式。<br>
        <br>
        <b>配置说明：</b><br>
        1. <b>IMAP服务器</b>: 填写邮箱服务商提供的 IMAP 地址（例如 <code>imap.gmail.com</code>）。<br>
        2. <b>端口</b>: 通常为 <code>993</code> (SSL) 或 <code>143</code> (非SSL)。推荐使用 SSL。<br>
        3. <b>邮箱账号</b>: 您的完整邮箱地址。<br>
        4. <b>密码/令牌</b>: 邮箱登录密码。如果是 Gmail 等，通常需要使用<b>应用专用密码</b>。<br>
        5. <b>文件夹</b>: 默认为 <code>INBOX</code>，除非您设置了过滤器将邮件移动到其他文件夹。<br>
        <br>
        <i>注意：请确保您的邮箱已开启 IMAP 服务。对于 Gmail，请在“设置”->“转发和 POP/IMAP”中启用 IMAP。</i>
        </div>
        """
        self.imap_guide_label.setHtml(imap_guide_text)
        custom_imap_layout.addRow(self.imap_guide_label)
        
        form_layout.addRow(self.custom_imap_widget)
        
        layout.addWidget(form_frame)
        layout.addStretch()

    def setup_connections(self):
        self.mode_group.idClicked.connect(self.on_mode_changed)
        self.domain_combo.currentIndexChanged.connect(self.on_domain_changed)
        self.imap_domain_combo.currentIndexChanged.connect(self.on_imap_domain_changed) # 新增连接
        self.test_btn.clicked.connect(self.on_test_connection)
        self.save_btn.clicked.connect(self.on_save_config)

    def load_config(self):
        email_config = self.config_manager.get_email_config()

        # 设置模式
        if email_config.mode == 'imap':
            self.imap_btn.setChecked(True)
            self.stack.setCurrentIndex(1)
        else:
            self.tempmail_btn.setChecked(True)
            self.stack.setCurrentIndex(0)

        # TempMail配置
        domain_map = {'mzyota': 0, 'yefota': 1, 'gotool': 2, 'custom': 3}
        domain = getattr(email_config, 'domain', 'mzyota')
        
        # 兼容旧配置：如果旧配置是 '2925'，强制转为 'mzyota'
        if domain == '2925':
            domain = 'mzyota'
            
        self.domain_combo.setCurrentIndex(domain_map.get(domain, 0)) # 默认 0 (mzyota)

        if hasattr(email_config, 'custom_receiving_email'):
            self.custom_receiving_email_input.setText(getattr(email_config, 'custom_receiving_email', ''))
        if hasattr(email_config, 'custom_pin'):
            self.custom_pin_input.setText(getattr(email_config, 'custom_pin', ''))
        if hasattr(email_config, 'custom_domain'):
            self.custom_domain_input.setText(getattr(email_config, 'custom_domain', ''))

        self.tempmail_email_input.setText(email_config.tempmail_email)
        self.tempmail_pin_input.setText(email_config.tempmail_pin)
        
        self.on_domain_changed() # 刷新可见性

        # IMAP配置
        imap_domain_map = {'2925': 0, 'custom': 1}
        # 如果是 2925，自动切到系统默认
        if email_config.domain == '2925' and email_config.mode == 'imap':
             self.imap_domain_combo.setCurrentIndex(0)
        elif email_config.mode == 'imap':
             self.imap_domain_combo.setCurrentIndex(1)
        else:
             self.imap_domain_combo.setCurrentIndex(0) # 默认

        self.imap_server_input.setText(email_config.imap_server)
        self.imap_port_input.setValue(email_config.imap_port)
        self.imap_ssl_checkbox.setChecked(email_config.use_ssl)
        self.imap_email_input.setText(email_config.imap_username)
        self.imap_password_input.setText(email_config.imap_password)
        self.imap_folder_input.setText(email_config.imap_folder)
        
        self.on_imap_domain_changed() # 刷新可见性

    def on_mode_changed(self, index):
        self.stack.setCurrentIndex(index)
        self.status_label.setText("")

    def on_domain_changed(self, index=None):
        is_custom = self.domain_combo.currentIndex() == 3 # 调整索引：mzyota=0, yefota=1, gotool=2, custom=3
        self.custom_config_widget.setVisible(is_custom)
        self.tempmail_default_info.setVisible(not is_custom)
        
        # 标准输入框始终隐藏，因为标准模式下自动生成
        self.tempmail_email_input.setVisible(False)
        self.tempmail_pin_input.setVisible(False)

    def on_imap_domain_changed(self, index=None):
        is_custom_imap = self.imap_domain_combo.currentIndex() == 1
        self.custom_imap_widget.setVisible(is_custom_imap)
        self.default_imap_info.setVisible(not is_custom_imap)

    def on_test_connection(self, checked=False):
        self.status_label.setText("正在测试连接...")
        self.status_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY};")
        
        try:
            config = self.get_current_config()
            email_config = EmailConfig(**config)
            self.email_handler = EmailHandler(email_config)
            
            success, message = self.email_handler.test_connection()
            if success:
                self.status_label.setText("连接测试成功")
                self.status_label.setStyleSheet(f"color: {CyberTheme.COLOR_SUCCESS};")
            else:
                self.status_label.setText(f"连接测试失败: {message}")
                self.status_label.setStyleSheet(f"color: {CyberTheme.COLOR_DANGER};")
        except Exception as e:
            error_msg = str(e)
            if "Missing required fields" in error_msg:
                friendly_msg = "请填写完整的邮箱和 PIN 码"
            elif "authentication failed" in error_msg.lower():
                friendly_msg = "认证失败，请检查 PIN 码是否正确"
            elif "timed out" in error_msg.lower():
                friendly_msg = "连接超时，请检查网络"
            else:
                friendly_msg = "配置信息不完整或有误，请检查输入"
            
            self.status_label.setText(f"测试异常: {friendly_msg}")
            self.status_label.setStyleSheet(f"color: {CyberTheme.COLOR_DANGER};")
            # 只有在非预期错误时才打印详细堆栈
            print(f"DEBUG: Connection test failed: {e}")

    def on_save_config(self, checked=False):
        try:
            config = self.get_current_config()
            email_config = EmailConfig(**config)
            
            # 1. 保存到配置文件 (持久化)
            self.config_manager.set_email_config(email_config)
            
            # 2. 重新加载 (确保内存中的 ConfigManager 更新)
            # set_email_config 内部已经更新了 self.config_manager.email_config
            # 但为了保险，我们可以再次确认
            
            self.status_label.setText("配置已保存并立即生效")
            self.status_label.setStyleSheet(f"color: {CyberTheme.COLOR_SUCCESS};")
            CyberMessageBox.information(self, "保存成功", "邮箱配置已保存并立即生效！\n无需重启程序。")
        except Exception as e:
            self.status_label.setText(f"保存失败: {str(e)}")
            self.status_label.setStyleSheet(f"color: {CyberTheme.COLOR_DANGER};")

    def get_current_config(self) -> dict:
        # 1. 获取选中的 TempMail 域名配置
        selected_domain_config = None
        if self.system_email_config and self.domain_combo.currentIndex() < self.domain_combo.count() - 1:
             # 如果是动态配置且不是最后一项（自定义）
             item_data = self.domain_combo.currentData()
             if item_data:
                 selected_domain_config = item_data

        domain_map = {0: 'mzyota', 1: 'yefota', 2: 'gotool', 3: 'custom'}
        # 优先使用动态配置的名字，否则使用旧映射
        if selected_domain_config:
            selected_domain = selected_domain_config.get('name', 'custom')
        else:
            selected_domain = domain_map.get(self.domain_combo.currentIndex(), 'mzyota')

        if self.tempmail_btn.isChecked():
            # 基础配置
            config = {
                'mode': 'tempmail',
                'domain': selected_domain,
                'tempmail_service': 'legacy_imap',
                'imap_server': '', 'imap_port': 993, 'imap_username': '', 'imap_password': '', 'imap_folder': 'INBOX', 'use_ssl': True
            }
            
            # 如果是动态配置，直接填充 email 和 pin
            if selected_domain_config:
                 config['tempmail_email'] = selected_domain_config.get('email', '')
                 config['tempmail_pin'] = selected_domain_config.get('pin', '')
                 # 确保 Config 对象能识别这些动态值，这里我们可能需要扩展 Config 结构，或者复用 tempmail_email 字段
            
            if self.domain_combo.currentIndex() == self.domain_combo.count() - 1: # 最后一项是自定义
                # 自定义模式：直接使用自定义输入框的值作为标准字段
                # 避免传递 EmailConfig 中不存在的 custom_receiving_email 等字段
                config['tempmail_email'] = self.custom_receiving_email_input.text().strip()
                config['tempmail_pin'] = self.custom_pin_input.text().strip()
                config['domain'] = 'custom'
                
                # custom_domain 可以作为附加信息，如果 EmailConfig 不支持则不传递
                # 这里我们假设 EmailConfig 主要是为了 handler 使用，而 handler 只需要 email 和 pin
            elif not selected_domain_config:
                # 默认模式（旧逻辑）：使用标准输入框
                config['tempmail_email'] = self.tempmail_email_input.text().strip()
                config['tempmail_pin'] = self.tempmail_pin_input.text().strip()
                
            return config
        else:
            # IMAP 模式
            imap_domain_map = {0: '2925', 1: 'custom'}
            selected_imap_domain = imap_domain_map.get(self.imap_domain_combo.currentIndex(), '2925')
            
            if selected_imap_domain == '2925':
                # 2925 使用系统配置（如果获取到）或硬编码
                imap_sys_config = self.system_email_config.get('imap_config', {})
                return {
                    'mode': 'imap',
                    'domain': '2925',
                    'tempmail_service': 'tempmail.plus', 
                    'tempmail_email': '', 'tempmail_pin': '',
                    'imap_server': imap_sys_config.get('server', 'imap.2925.com'),
                    'imap_port': imap_sys_config.get('port', 993),
                    'imap_username': imap_sys_config.get('username', 'bluesky78@2925.com'),
                    'imap_password': imap_sys_config.get('password', 'a251314'),
                    'imap_folder': imap_sys_config.get('folder', 'INBOX'),
                    'use_ssl': imap_sys_config.get('ssl', True)
                }
            else:
                # 自定义 IMAP
                return {
                    'mode': 'imap',
                    'domain': 'custom', 
                    'tempmail_service': 'tempmail.plus',
                    'tempmail_email': '', 'tempmail_pin': '',
                    'imap_server': self.imap_server_input.text().strip(),
                    'imap_port': self.imap_port_input.value(),
                    'imap_username': self.imap_email_input.text().strip(),
                    'imap_password': self.imap_password_input.text().strip(),
                    'imap_folder': self.imap_folder_input.text().strip(),
                    'use_ssl': self.imap_ssl_checkbox.isChecked()
                }
