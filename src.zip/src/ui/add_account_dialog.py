#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
添加账户对话框
"""

import threading
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QProgressBar, QWidget,
    QTabWidget, QTextEdit
)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QMouseEvent

from ui.styles import CyberTheme
from ui.custom_widgets import RainbowTitleLabel, CyberMessageBox
from core.cursor_api import CursorOfficialAPI
from core.account_manager import AccountInfo

import logging

class LogCaptureHandler(logging.Handler):
    """捕获日志并发送到信号的 Handler"""
    def __init__(self, signal):
        super().__init__()
        self.signal = signal

    def emit(self, record):
        if record.levelno >= logging.INFO:
            text = record.getMessage()
            
            # --- 严格白名单过滤 ---
            # 只允许显示特定的几类关键信息
            
            should_show = False
            
            # 1. 用户信息
            if "成功获取用户信息" in text and "Cookie" not in text: # 避免重复，只留一条最简单的
                should_show = True
                
            # 2. 使用情况
            elif "成功获取使用情况" in text:
                should_show = True
                
            # 3. 交易/订阅信息 (Stripe)
            elif "Stripe" in text:
                text = text.replace("Stripe 信息", "交易信息")
                should_show = True
                
            # 4. 使用记录 (Usage Events)
            elif "获取使用记录成功" in text:
                # 保持原样: ✓ 获取使用记录成功，共 450 条...
                should_show = True
                
            # 5. 费用信息
            elif "get_usage_events" in text:
                text = text.replace("成功通过 get_usage_events 获取费用信息", "成功获取费用信息")
                should_show = True
                
            # 6. 账户详情
            elif "成功获取账户详细信息" in text:
                should_show = True
                
            # 7. 最终成功提示
            elif "添加成功" in text:
                should_show = True
            
            # 8. 错误信息 (永远显示)
            elif "失败" in text or "异常" in text or "错误" in text:
                should_show = True
            
            if not should_show:
                return # 其他所有杂七杂八的日志全部丢弃
            
            # 简单美化前缀
            text = text.strip() # 去除首尾空格
            if "成功" in text or "✓" in text:
                if not text.startswith("✅"):
                    text = f"✅ {text.replace('✓', '').strip()}"
            elif "失败" in text or "异常" in text:
                if not text.startswith("❌"):
                    text = f"❌ {text}"
            
            # 发送信号更新 UI
            self.signal.emit(text, True)

class AddAccountDialog(QDialog):
    """添加账户对话框"""

    account_added = pyqtSignal(AccountInfo)
    verify_finished = pyqtSignal(bool, str, object)  # success, message, account

    # 定义信号，必须在类级别定义
    progress_update_signal = pyqtSignal(str, bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._drag_pos = None
        
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Dialog)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.resize(550, 500)
        
        self.init_ui()
        
        # 连接信号
        self.verify_finished.connect(self._on_verify_finished)
        self.progress_update_signal.connect(self.update_progress_text) # 连接信号到槽函数

    def init_ui(self):
        # 主容器
        main_widget = QWidget(self)
        main_widget.setGeometry(0, 0, self.width(), self.height())
        main_widget.setStyleSheet(f"""
            QWidget {{
                background-color: {CyberTheme.COLOR_BG_PRIMARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 8px;
            }}
        """)
        
        layout = QVBoxLayout(main_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # 1. 标题栏
        title_bar = QWidget()
        title_bar.setFixedHeight(40)
        title_bar.setStyleSheet(f"""
            QWidget {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                border-bottom: 1px solid {CyberTheme.COLOR_BORDER};
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                border: none;
                border-bottom: 1px solid {CyberTheme.COLOR_BORDER};
            }}
        """)
        title_layout = QHBoxLayout(title_bar)
        title_layout.setContentsMargins(16, 0, 8, 0)
        
        title_label = RainbowTitleLabel("添加账户 (Pro)", font_size=14, bold=True)
        title_layout.addWidget(title_label)
        title_layout.addStretch()
        
        # 与主窗口保持一致的关闭按钮样式
        close_btn = QPushButton("✕")
        close_btn.setFixedSize(32, 24)
        close_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: transparent;
                border: none;
                border-radius: 4px;
                color: {CyberTheme.COLOR_TEXT_SECONDARY};
                font-family: "Segoe MDL2 Assets", "Segoe UI Symbol", sans-serif;
                font-size: 12px;
                padding: 0;
            }}
            QPushButton:hover {{
                background-color: {CyberTheme.COLOR_DANGER};
                color: white;
            }}
        """)
        # 强制直接关闭
        close_btn.clicked.connect(lambda: self.done(0)) 
        title_layout.addWidget(close_btn)
        layout.addWidget(title_bar)
        
        # 2. 内容区 (Tab Widget)
        content_container = QWidget()
        content_container.setStyleSheet("background-color: transparent; border: none;")
        content_layout = QVBoxLayout(content_container)
        content_layout.setContentsMargins(20, 20, 20, 20)
        content_layout.setSpacing(16)
        
        self.tab_widget = QTabWidget()
        self.tab_widget.setCursor(Qt.CursorShape.PointingHandCursor)
        self.tab_widget.setStyleSheet(f"""
            QTabWidget::pane {{
                border: 1px solid {CyberTheme.COLOR_BORDER};
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                border-radius: 4px;
            }}
            QTabBar::tab {{
                background-color: {CyberTheme.COLOR_BG_PRIMARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                padding: 8px 20px;
                margin-right: 4px;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
                color: {CyberTheme.COLOR_TEXT_SECONDARY};
                min-width: 100px;
            }}
            QTabBar::tab:selected {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                color: {CyberTheme.COLOR_PRIMARY};
                border-bottom-color: {CyberTheme.COLOR_BG_SECONDARY};
                font-weight: bold;
            }}
        """)
        
        # Tab 1: Session Token
        self.session_tab = QWidget()
        self.init_session_tab()
        self.tab_widget.addTab(self.session_tab, "Session Token")
        
        # Tab 2: Access Token
        self.access_tab = QWidget()
        self.init_access_tab()
        self.tab_widget.addTab(self.access_tab, "Access Token")
        
        content_layout.addWidget(self.tab_widget)
        
        # 进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setFixedHeight(4)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setStyleSheet(f"""
            QProgressBar {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                border: none;
                border-radius: 2px;
            }}
            QProgressBar::chunk {{ background-color: {CyberTheme.COLOR_PRIMARY}; }}
        """)
        content_layout.addWidget(self.progress_bar)
        
        # 状态信息 - 使用 QTextEdit 而不是 QLabel 以支持多行滚动和更好的显示
        self.status_console = QTextEdit()
        self.status_console.setReadOnly(True)
        self.status_console.setVisible(False) # 初始隐藏
        self.status_console.setFixedHeight(100) # 给足够的高度
        self.status_console.setStyleSheet(f"""
            QTextEdit {{
                background-color: #000000; /* 纯黑背景 */
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
                color: #00FF00;  /* 亮绿色字体，类似终端 */
                font-family: Consolas, monospace;
                font-size: 12px;
                padding: 6px;
            }}
            
            /* 滚动条样式优化 */
            QScrollBar:vertical {{
                border: none;
                background-color: #000000;
                width: 10px;
                margin: 0px;
            }}
            QScrollBar::handle:vertical {{
                background-color: {CyberTheme.COLOR_BG_TERTIARY};
                min-height: 30px;
                border-radius: 5px;
                margin: 2px;
            }}
            QScrollBar::handle:vertical:hover {{
                background-color: {CyberTheme.COLOR_TEXT_SECONDARY};
            }}
            QScrollBar::handle:vertical:pressed {{
                background-color: {CyberTheme.COLOR_PRIMARY};
            }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
                height: 0px;
                background: none;
            }}
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{
                background: none;
            }}
        """)
        content_layout.addWidget(self.status_console)
        
        # 旧的 status_label 仅用于显示最终的一句话结果，或者干脆移除
        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        self.status_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_MUTED}; font-size: 12px;")
        content_layout.addWidget(self.status_label)
        
        # 按钮区
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        
        self.cancel_btn = QPushButton("关闭")
        self.cancel_btn.setFixedSize(80, 32)
        self.cancel_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: transparent;
                border: 1px solid {CyberTheme.COLOR_BORDER};
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                border-radius: 4px;
            }}
            QPushButton:hover {{ border-color: {CyberTheme.COLOR_TEXT_SECONDARY}; }}
        """)
        # 强制直接关闭，不经过任何中间逻辑
        self.cancel_btn.clicked.connect(lambda: self.done(0)) 
        
        self.confirm_btn = QPushButton("验证并添加")
        self.confirm_btn.setFixedSize(100, 32)
        self.confirm_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_PRIMARY};
                border: none;
                color: white;
                border-radius: 4px;
                font-weight: bold;
            }}
            QPushButton:hover {{ background-color: {CyberTheme.COLOR_PRIMARY_HOVER}; }}
            QPushButton:disabled {{ background-color: {CyberTheme.COLOR_BG_TERTIARY}; color: {CyberTheme.COLOR_TEXT_MUTED}; }}
        """)
        self.confirm_btn.clicked.connect(self.on_verify_clicked)
        
        btn_layout.addWidget(self.cancel_btn)
        btn_layout.addWidget(self.confirm_btn)
        content_layout.addLayout(btn_layout)
        
        layout.addWidget(content_container)

    def closeEvent(self, event):
        """重写关闭事件，确保窗口能被关闭"""
        event.accept()

    def keyPressEvent(self, event):
        """处理ESC键关闭"""
        if event.key() == Qt.Key.Key_Escape:
            self.done(0)
        else:
            super().keyPressEvent(event)

        
    def init_session_tab(self):
        layout = QVBoxLayout(self.session_tab)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)
        
        desc = QLabel("只需输入 Session Token 即可自动识别账户信息。\n(Token 通常以 user_ 开头)")
        desc.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; font-size: 13px;")
        desc.setWordWrap(True)
        layout.addWidget(desc)
        
        self.session_input = QTextEdit()
        self.session_input.setPlaceholderText("在此粘贴 Session Token...\nuser_...")
        self.session_input.setStyleSheet(f"""
            QTextEdit {{
                background-color: {CyberTheme.COLOR_BG_PRIMARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
                padding: 8px;
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
            }}
            QTextEdit:focus {{ border-color: {CyberTheme.COLOR_PRIMARY}; }}
        """)
        layout.addWidget(self.session_input)
        
    def init_access_tab(self):
        layout = QVBoxLayout(self.access_tab)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)
        
        desc = QLabel("需同时提供 Access Token 和对应的邮箱账号。")
        desc.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; font-size: 13px;")
        layout.addWidget(desc)
        
        # 邮箱
        email_lbl = QLabel("邮箱账号 (必填)")
        email_lbl.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_PRIMARY}; font-weight: bold;")
        self.email_input = QLineEdit()
        self.email_input.setPlaceholderText("user@example.com")
        self.email_input.setStyleSheet(f"""
            QLineEdit {{
                background-color: {CyberTheme.COLOR_BG_PRIMARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
                padding: 8px;
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
            }}
            QLineEdit:focus {{ border-color: {CyberTheme.COLOR_PRIMARY}; }}
        """)
        layout.addWidget(email_lbl)
        layout.addWidget(self.email_input)
        
        # Access Token
        token_lbl = QLabel("Access Token (必填)")
        token_lbl.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_PRIMARY}; font-weight: bold;")
        self.access_input = QTextEdit()
        self.access_input.setPlaceholderText("在此粘贴 Access Token...\neyJ...")
        self.access_input.setStyleSheet(f"""
            QTextEdit {{
                background-color: {CyberTheme.COLOR_BG_PRIMARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
                padding: 8px;
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
            }}
            QTextEdit:focus {{ border-color: {CyberTheme.COLOR_PRIMARY}; }}
        """)
        layout.addWidget(token_lbl)
        layout.addWidget(self.access_input)
        
    def on_verify_clicked(self, _checked=False):
        mode = self.tab_widget.currentIndex() # 0: Session, 1: Access
        
        self.verify_data = {}
        
        if mode == 0:
            # Session Token Mode
            token = self.session_input.toPlainText().strip()
            if not token:
                CyberMessageBox.warning(self, "输入错误", "Session Token 不能为空")
                return
            # 移除 user_ 前缀校验
            
            self.verify_data = {
                'type': 'session',
                'token': token
            }
            
        else:
            # Access Token Mode
            email = self.email_input.text().strip()
            token = self.access_input.toPlainText().strip()
            
            if not email:
                CyberMessageBox.warning(self, "输入错误", "邮箱账号不能为空")
                return
            if not token:
                CyberMessageBox.warning(self, "输入错误", "Access Token 不能为空")
                return
                
            self.verify_data = {
                'type': 'access',
                'email': email,
                'token': token
            }
        
        # 锁定 UI (保留关闭按钮可用)
        self.confirm_btn.setEnabled(False)
        # self.cancel_btn.setEnabled(False) # 允许用户取消/关闭
        self.tab_widget.setEnabled(False)
        self.progress_bar.setVisible(True)
        self.status_console.setVisible(True) # 显示日志框
        self.status_console.clear() # 清空旧日志
        self.progress_bar.setRange(0, 0)
        
        # 移除旧的 status_label 设置，改用新的 update_progress_text
        # self.status_label.setText("正在连接 Cursor API 验证账户信息...")
        # self.status_label.setStyleSheet(f"color: {CyberTheme.COLOR_PRIMARY};")
        
        # 异步验证
        threading.Thread(target=self._verify_thread, daemon=True).start()
        try:
            def watchdog():
                if not self.confirm_btn.isEnabled() and self.progress_bar.isVisible():
                    self.verify_finished.emit(False, "验证超时或接口无响应，请检查令牌是否有效。", None)
            QTimer.singleShot(10000, watchdog)
        except:
            pass

    def update_progress_text(self, text, append=False):
        """更新进度文字"""
        # 确保控件可见
        if not self.status_console.isVisible():
            self.status_console.setVisible(True)
            
        if append:
            self.status_console.append(text) # QTextEdit 的 append 方法自动换行
        else:
            self.status_console.setText(text)
            
        # 自动滚动到底部
        scrollbar = self.status_console.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())
        
        # 强制立即重绘，不依赖事件循环
        self.status_console.repaint() 
        # from PyQt6.QtWidgets import QApplication
        # QApplication.processEvents() # 在槽函数中通常不需要手动处理事件循环，因为Qt主循环会自动处理

    def _verify_thread(self):
        log_handler = None
        try:
            # ⭐ 终极修正：使用标准的 pyqtSignal 发送信号
            # 这比 invokeMethod 更稳定，不容易报错
            def set_text(msg, append=False):
                self.progress_update_signal.emit(msg, append)

            # 注册日志捕获器
            logger = logging.getLogger("cursor_vip")
            log_handler = LogCaptureHandler(self.progress_update_signal)
            logger.addHandler(log_handler)

            set_text("正在连接 Cursor API 验证账户信息...")
            api = CursorOfficialAPI()
            mode = self.verify_data['type']
            token = self.verify_data['token']
            
            # ... (中间代码省略，保留原样) ...
            
            # 移除所有空白字符（防止复制粘贴带换行）
            token = "".join(token.split())
            
            access_token = token
            session_token = None
            
            print(f"DEBUG: AddAccountDialog verify_token mode={mode} token_len={len(token)}")
            
            # 1. 解析/提取 Access Token
            if mode == 'session':
                session_token = token 
                access_token = session_token
                
            # 2. 直接获取账户详情
            # set_text("正在获取使用情况...", append=True) # 日志里会有，这里不需要重复
            import time
            time.sleep(0.3) # 强制给UI一点渲染时间
            
            try:
                import urllib.parse, re, jwt
                request_token = token
                if mode == 'session':
                    decoded = urllib.parse.unquote(session_token or "")
                    jwt_part = ""
                    if "::" in decoded:
                        parts = decoded.split("::")
                        if len(parts) > 1:
                            jwt_part = parts[1]
                    elif decoded.startswith("user_"):
                        m = re.search(r"(eyJ[\w-]*\.[\w-]*\.[\w-]*)", decoded)
                        if m:
                            jwt_part = m.group(1)
                    else:
                        jwt_part = decoded
                    uid = ""
                    try:
                        if jwt_part:
                            payload = jwt.decode(jwt_part, options={"verify_signature": False})
                            sub = str(payload.get("sub", ""))
                            uid = sub.split("|")[-1] if "|" in sub else sub
                    except:
                        uid = ""
                    if jwt_part and uid:
                        if not uid.startswith("user_"):
                            uid = "user_" + uid
                        request_token = f"{uid}::{jwt_part}"
                    else:
                        request_token = session_token or token
                else:
                    uid = ""
                    try:
                        payload = jwt.decode(access_token, options={"verify_signature": False})
                        sub = str(payload.get("sub", ""))
                        uid = sub.split("|")[-1] if "|" in sub else sub
                    except:
                        uid = ""
                    if uid:
                        if not uid.startswith("user_"):
                            uid = "user_" + uid
                        request_token = f"{uid}::{access_token}"
                    else:
                        request_token = access_token
                details = api.get_account_details(request_token)
            except:
                try:
                    details = api.get_account_details(access_token)
                except:
                    details = None
            
            # if details:
            #     set_text("✅ 使用情况获取成功", append=True)
            # else:
            #     set_text("⚠️ 使用情况获取失败 (将仅保存基础信息)", append=True)

            # set_text("正在获取使用记录...", append=True) # API 日志里会有
            time.sleep(0.3) # 强制给UI一点渲染时间
            
            # 模拟一点点延迟让用户看清，或者如果API本身很快就不用
            # import time
            # time.sleep(0.5)
            
            # ... (后续代码保留) ...
            
            # ... (中间省略获取 email 的逻辑，保持不变) ...

            if not details or not details.get('user_info'):
                self.verify_finished.emit(False, "账号已失效或被封禁，无法添加。", None)
                return
            user_info = details.get('user_info', {})
            email = user_info.get('email')

            # 如果 API 没给 email，尝试本地解析
            if not email:
                 try:
                    import jwt
                    # 这里尝试解析 JWT，需要从 session_token 中提取 payload
                    # 因为 session_token 可能是 user_xxx::jwt
                    jwt_to_decode = access_token
                    if "::" in access_token:
                        parts = access_token.split("::")
                        if len(parts) > 1:
                            jwt_to_decode = parts[1]
                    elif "%3A%3A" in access_token: # 如果用户真的没解码就传进来了
                         # 这里为了解析邮箱，我们必须临时解码一下，但不影响保存的值
                         import urllib.parse
                         decoded = urllib.parse.unquote(access_token)
                         if "::" in decoded:
                             jwt_to_decode = decoded.split("::")[1]
                    
                    payload = jwt.decode(jwt_to_decode, options={"verify_signature": False})
                    # 优先找 email，其次找 sub，最后找 user_id
                    email = payload.get('email') or payload.get('sub') or payload.get('user_id')
                    print(f"DEBUG: 本地解析结果 email={email}")
                 except Exception as e:
                    print(f"DEBUG: 本地解析失败 {e}")
            
            # 如果本地解析也没给，尝试直接从 Token 字符串抠
            if not email:
                self.verify_finished.emit(False, "无法从接口或令牌解析邮箱，账号无效，无法添加。", None)
                return

            # 只有当 email 还是 None 时（几乎不可能），才报错
            if not email:
                self.verify_finished.emit(False, "无法从 Token 解析出任何用户标识。", None)
                return
                
            # 构造账户信息
            from datetime import datetime
            
            # [2024-01-24 终极修正 V3]
            # 分离显示与功能：
            # 1. session_token: 保持用户输入的原始格式 (带 user_xxx%3A%3A 或 user_xxx::)，用于界面显示。
            # 2. final_access_token: 必须是纯 JWT，用于 IDE 注入和防止掉线。
            
            final_access_token = access_token
            
            # 智能提取纯 JWT
            # 先尝试处理 URL 编码的情况 (%3A%3A)
            if "%3A%3A" in access_token:
                try:
                    import urllib.parse
                    decoded_temp = urllib.parse.unquote(access_token)
                    if "::" in decoded_temp:
                            parts = decoded_temp.split("::")
                            if len(parts) > 1:
                                potential_jwt = parts[-1]
                                if potential_jwt.startswith("eyJ"):
                                    final_access_token = potential_jwt
                                    # print("DEBUG: 已从 URL 编码的 Token 中提取纯 JWT") # 移除英文调试日志
                except:
                    pass
        
            # 再尝试处理未编码的情况 (::)
            # 注意：如果上面已经提取成功，final_access_token 已经是纯 JWT，这里不会匹配
            elif "::" in access_token:
                parts = access_token.split("::")
                if len(parts) > 1:
                    potential_jwt = parts[-1]
                    if potential_jwt.startswith("eyJ"):
                            final_access_token = potential_jwt
                            # print("DEBUG: 已从普通 Token 中提取纯 JWT") # 移除英文调试日志
            
            # [关键新增] 自动补全 Refresh Token
            refresh_token = None
            if mode == 'access': # Access Token 模式
                    # 许多自动注册的账号 Access Token 和 Refresh Token 是相同的
                    refresh_token = final_access_token
                    # print(f"DEBUG: 自动将 Access Token 复制为 Refresh Token") # 移除英文调试日志
            elif mode == 'session':
                    # Session Token 模式通常只提供一个 token，也做同样处理
                    refresh_token = final_access_token

            account = AccountInfo(
                email=str(email),
                access_token=final_access_token, # 存入纯 JWT (用于功能)
                refresh_token=refresh_token,     # 存入纯 JWT (用于防掉线)
                session_token=session_token,     # 存入原始输入 (用于界面显示)
                user_id=user_info.get('id'),
                membership_type=details.get('subscription_info', {}).get('plan', 'unknown') if details else 'unknown',
                created_at=datetime.now().isoformat(),
                status='active',
                register_type='manual_import'
            )
            
            # 手动注入 usage 数据 (如果 API 获取到了)
            if details:
                # 1. 尝试填充基础配额字段 (如果有)
                if 'used' in details:
                    account.used = details['used']
                if 'limit' in details:
                    account.limit_value = details['limit']
                if 'usage_percent' in details:
                    account.usage_percent = details['usage_percent']

                # 2. 构造并填充详细消耗统计 (token_consumption)
                # 这是 AccountInfo 的标准字段，会被保存到数据库
                consumption = {
                    'total_cost': details.get('total_cost', 0),
                    'unpaid_amount': details.get('unpaid_amount', 0),
                    'total_tokens': details.get('total_tokens', 0),
                    'model_usage': details.get('model_usage', {}), # 即使 API 没返回，也初始化为空字典
                    'last_updated': datetime.now().isoformat()
                }
                # 如果 API 返回了 by_model 数据（虽然目前 get_account_details 好像没透传），也可以加上
                if 'by_model' in details:
                    consumption['model_usage'] = details['by_model']
                
                account.token_consumption = consumption
                
                # 3. 填充天数信息
                if 'days_remaining' in details:
                    account.days_remaining = details['days_remaining']
                
                # 还可以注入其他有用信息
                account.stripe_info = details.get('subscription_info')
            
            # 这里不要重复 emit，只在 verify_finished 统一处理
            # self.verify_finished.emit(True, "添加成功！", account)

        except Exception as e:
            # 即使发生异常，也尝试添加
            print(f"验证过程异常: {e}")
            self.verify_finished.emit(False, f"验证过程发生异常: {str(e)}", None)
            return
        finally:
            # 移除日志捕获器
            if log_handler:
                logging.getLogger("cursor_vip").removeHandler(log_handler)

        # 正常结束，发送成功信号
        self.verify_finished.emit(True, "添加成功！", account)

    def _on_verify_finished(self, success, message, account):
        self.progress_bar.setVisible(False)
        self.confirm_btn.setEnabled(True)
        self.cancel_btn.setEnabled(True)
        self.tab_widget.setEnabled(True)
        
        if success:
            # 成功后不立即关闭，而是更改按钮状态让用户确认
            self.account_added.emit(account) # 先触发添加逻辑
            
            # 1. 更新日志
            self.update_progress_text(f"✅ 添加成功: {account.email}", append=True)
            
            # 2. 更改按钮为“完成”
            self.confirm_btn.setText("完成")
            self.confirm_btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: {CyberTheme.COLOR_SUCCESS};
                    border: none;
                    color: white;
                    border-radius: 4px;
                    font-weight: bold;
                }}
                QPushButton:hover {{ background-color: {CyberTheme.COLOR_SUCCESS}99; }}
            """)
            
            # 3. 断开原有的验证连接，改为关闭窗口
            try:
                self.confirm_btn.clicked.disconnect()
            except:
                pass
            self.confirm_btn.clicked.connect(self.accept)
            
            # 移除自动关闭定时器
            # QTimer.singleShot(500, self.accept) 
        else:
            self.update_progress_text(f"❌ {message}", append=True)
            self.status_label.setText(f"❌ {message}")
            self.status_label.setStyleSheet(f"color: {CyberTheme.COLOR_DANGER};")
            # CyberMessageBox.warning(self, "验证失败", message) # 日志已经显示了，弹窗可选

    # --- 拖动逻辑 ---
    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            if event.position().y() < 40:
                self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
                event.accept()

    def mouseMoveEvent(self, event: QMouseEvent):
        if event.buttons() == Qt.MouseButton.LeftButton and self._drag_pos:
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def mouseReleaseEvent(self, event: QMouseEvent):
        self._drag_pos = None
