#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
关于页面
"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
    QGroupBox
)
from PyQt6.QtGui import QDesktopServices, QPixmap
from PyQt6.QtCore import QUrl, Qt
from pathlib import Path

from ui.styles import CyberTheme
from ui.custom_widgets import CyberMessageBox
from utils.version_checker import VersionChecker
from utils.app_paths import resource_path

class AboutWidget(QWidget):
    """关于软件页面组件"""
    
    def __init__(self, config_manager=None):
        super().__init__()
        self.config_manager = config_manager
        self.init_ui()
        
    def init_ui(self):
        """初始化 UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)
        
        # 顶部 Logo 和标题
        header_layout = QVBoxLayout()
        header_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header_layout.setSpacing(10)
        
        # Logo
        logo_label = QLabel()
        logo_label.setFixedSize(64, 64)
        logo_label.setScaledContents(True)
        
        # 尝试加载图标
        # 优先加载高清PNG
        logo_path = resource_path("src/assets/logo_large.png")
        icon_path = resource_path("src/assets/icon.ico")
        
        pixmap = None
        if logo_path.exists():
             pixmap = QPixmap(str(logo_path))
        elif icon_path.exists():
            pixmap = QPixmap(str(icon_path))
            
        if pixmap and not pixmap.isNull():
            logo_label.setPixmap(pixmap)
            # 设置平滑缩放
            logo_label.setScaledContents(True)
        
        header_layout.addWidget(logo_label, alignment=Qt.AlignmentFlag.AlignCenter)
        
        # 标题
        title_label = QLabel("Cursor Pro Manager")
        title_label.setStyleSheet(f"color: {CyberTheme.COLOR_PRIMARY}; font-size: 24px; font-weight: bold;")
        header_layout.addWidget(title_label, alignment=Qt.AlignmentFlag.AlignCenter)
        
        layout.addLayout(header_layout)
        
        # 信息卡片
        self.init_info_card(layout)
        
        layout.addStretch()

    def init_info_card(self, parent_layout):
        """软件信息区域"""
        group = QGroupBox("软件信息")
        group.setStyleSheet(f"""
            QGroupBox {{
                font-weight: bold;
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 15px;
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                background-color: {CyberTheme.COLOR_BG_CARD};
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                subcontrol-position: top left;
                left: 15px;
                padding: 0 5px;
                color: {CyberTheme.COLOR_ACCENT};
            }}
        """)
        
        layout = QVBoxLayout(group)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)
        
        # 版本信息行
        version_layout = QHBoxLayout()
        version_label = QLabel("当前版本: v1.0.0")
        version_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; font-size: 14px;")
        
        self.check_update_btn = QPushButton("检查更新")
        self.check_update_btn.setFixedSize(120, 36)
        self.check_update_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_PRIMARY};
                color: white;
                border: none;
                border-radius: 4px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: {CyberTheme.COLOR_PRIMARY_HOVER};
            }}
        """)
        self.check_update_btn.clicked.connect(self.on_check_update)
        
        version_layout.addWidget(version_label)
        version_layout.addStretch()
        version_layout.addWidget(self.check_update_btn)
        
        layout.addLayout(version_layout)
        
        # 分隔线
        line = QLabel()
        line.setFixedHeight(1)
        line.setStyleSheet(f"background-color: {CyberTheme.COLOR_BORDER};")
        layout.addWidget(line)
        
        # 描述文本
        desc_label = QLabel(
            "Cursor Pro Manager 是一款专为 Cursor 编辑器设计的高级管理工具。\n\n"
            "主要功能：\n"
            "• 无限邮箱账号自动注册\n"
            "• 智能机器码管理与重置\n"
            "• 一键配置备份与恢复\n"
            "• 全自动 Token 提取与注入"
        )
        desc_label.setWordWrap(True)
        desc_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; line-height: 1.6; font-size: 13px;")
        layout.addWidget(desc_label)
        
        # 版权信息
        copyright_label = QLabel("© 2026 Cursor Pro Manager. 保留所有权利。")
        copyright_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        copyright_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_MUTED}; font-size: 12px; margin-top: 20px;")
        layout.addWidget(copyright_label)
        
        parent_layout.addWidget(group)

    def on_check_update(self, checked=False):
        """检查更新"""
        self.check_update_btn.setText("检查中...")
        self.check_update_btn.setEnabled(False)
        
        # 从配置中获取更新地址
        update_url = self.config_manager.get_system_config().update_url
        
        self.update_checker = VersionChecker("1.0.0", update_url)
        self.update_checker.finished.connect(self.on_update_checked)
        self.update_checker.start()
        
    def on_update_checked(self, has_update, version, url):
        self.check_update_btn.setText("检查更新")
        self.check_update_btn.setEnabled(True)
        
        if has_update:
            res = CyberMessageBox.question(
                self, 
                "发现新版本", 
                f"发现新版本 v{version}！\n是否前往下载？"
            )
            if res == 16384: # Yes
                QDesktopServices.openUrl(QUrl(url))
        elif version == "error":
             CyberMessageBox.warning(self, "检查失败", "网络不可达，稍后重试")
        else:
            CyberMessageBox.information(self, "已是最新", "当前已是最新版本。")
