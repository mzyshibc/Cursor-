#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
注册组件 - 重构版
"""

from datetime import datetime
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QRadioButton, QButtonGroup, QTextEdit,
    QProgressBar, QFrame
)
from PyQt6.QtCore import pyqtSignal, QThread

from core.account_manager import AccountManager, AccountInfo
from core.registration_engine import RegistrationEngine
from utils.config import ConfigManager
from ui.styles import CyberTheme
from ui.custom_widgets import CyberMessageBox
from utils.app_paths import resource_path


class RegistrationWorker(QThread):
    """注册工作线程 - 保持逻辑不变"""

    progress_signal = pyqtSignal(str, int)
    finished_signal = pyqtSignal(bool, str, dict)

    def __init__(self, email: str, config: dict):
        super().__init__()
        self.email = email
        self.config = config
        self.register_instance = None

    def run(self):
        try:
            self.progress_signal.emit("初始化注册引擎...", 5)
            self.register_instance = RegistrationEngine(self.config['email_config'], self.config['selected_domain'])
            self.progress_signal.emit("注册引擎初始化完成", 10)

            def progress_callback(msg, percent):
                self.progress_signal.emit(f"{msg} ({percent}%)", percent // 5)

            self.progress_signal.emit("开始注册流程...", 15)
            
            try:
                result = self.register_instance.register_account(progress_callback, email=self.email)

                if result.success:
                    self.progress_signal.emit("注册成功！", 100)
                    account_data = {
                        'access_token': result.access_token,
                        'refresh_token': result.refresh_token,
                        'session_token': result.session_token,
                        'email': result.email
                    }
                    self.finished_signal.emit(True, result.message, account_data)
                else:
                    self.progress_signal.emit(f"注册失败: {result.message}", 0)
                    self.finished_signal.emit(False, result.message, {})

            except Exception as e:
                import traceback
                error_details = traceback.format_exc()
                self.progress_signal.emit(f"发生未捕获异常: {str(e)}", 0)
                self.finished_signal.emit(False, f"{str(e)}\n{error_details}", {})

        except Exception as e:
            import traceback
            error_details = traceback.format_exc()
            self.progress_signal.emit(f"线程初始化异常: {str(e)}", 0)
            self.finished_signal.emit(False, f"{str(e)}\n{error_details}", {})


class RegistrationWidget(QWidget):
    """注册组件"""

    account_registered = pyqtSignal(AccountInfo)

    def __init__(self, account_manager: AccountManager, config_manager: ConfigManager, parent=None):
        super().__init__(parent)
        self.account_manager = account_manager
        self.config_manager = config_manager
        self.worker = None
        self.selected_domain = 'mzyota'

        self.init_ui()
        self.setup_connections()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(16)

        # 标题区域
        header_layout = QHBoxLayout()
        title_label = QLabel("账户注册")
        title_label.setFont(CyberTheme.get_font(18, True))
        title_label.setStyleSheet(f"color: {CyberTheme.COLOR_PRIMARY};")
        header_layout.addWidget(title_label)
        header_layout.addStretch()
        layout.addLayout(header_layout)

        # 主要内容区 - 左右布局
        content_layout = QHBoxLayout()
        content_layout.setSpacing(20)

        # 左侧：控制区
        left_panel = QVBoxLayout()
        left_panel.setSpacing(16)

        # 1. 模式选择卡片
        mode_frame = QFrame()
        mode_frame.setObjectName("Card")
        mode_frame.setStyleSheet(f"""
            #Card {{
                background-color: {CyberTheme.COLOR_BG_CARD};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 6px;
            }}
        """)
        mode_layout = QVBoxLayout(mode_frame)
        mode_layout.setContentsMargins(16, 16, 16, 16)
        
        mode_label = QLabel("选择注册模式")
        mode_label.setFont(CyberTheme.get_font(14, True))
        mode_layout.addWidget(mode_label)

        self.mode_group = QButtonGroup(self)
        
        self.auto_radio = QRadioButton("自动注册")
        self.auto_radio.setToolTip("全自动完成注册流程，包括邮箱验证")
        self.auto_radio.setChecked(True)
        self.mode_group.addButton(self.auto_radio, 0)
        check_icon_path = resource_path("src/assets/check.svg").as_posix()
        self.auto_radio.setStyleSheet(f"""
            QRadioButton {{
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                spacing: 8px;
            }}
            QRadioButton::indicator {{
                width: 18px;
                height: 18px;
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
            }}
            QRadioButton::indicator:checked {{
                background-color: {CyberTheme.COLOR_PRIMARY};
                border-color: {CyberTheme.COLOR_PRIMARY};
                image: url({check_icon_path});
            }}
            QRadioButton::indicator:hover {{
                border-color: {CyberTheme.COLOR_PRIMARY};
            }}
        """)
        mode_layout.addWidget(self.auto_radio)
        
        auto_desc = QLabel("自动完成邮箱生成、验证码接收和注册流程。")
        auto_desc.setWordWrap(True)
        auto_desc.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; font-size: 12px; margin-left: 20px;")
        mode_layout.addWidget(auto_desc)

        mode_layout.addSpacing(10)

        self.manual_radio = QRadioButton("手动注册")
        self.manual_radio.setToolTip("引导用户手动打开浏览器完成注册")
        self.mode_group.addButton(self.manual_radio, 1)
        self.manual_radio.setStyleSheet(f"""
            QRadioButton {{
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                spacing: 8px;
            }}
            QRadioButton::indicator {{
                width: 18px;
                height: 18px;
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
            }}
            QRadioButton::indicator:checked {{
                background-color: {CyberTheme.COLOR_PRIMARY};
                border-color: {CyberTheme.COLOR_PRIMARY};
                image: url({check_icon_path});
            }}
            QRadioButton::indicator:hover {{
                border-color: {CyberTheme.COLOR_PRIMARY};
            }}
        """)
        mode_layout.addWidget(self.manual_radio)
        
        manual_desc = QLabel("手动打开浏览器注册，随后注入认证信息。")
        manual_desc.setWordWrap(True)
        manual_desc.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; font-size: 12px; margin-left: 20px;")
        mode_layout.addWidget(manual_desc)

        left_panel.addWidget(mode_frame)
        
        # 2. 状态/进度区
        self.progress_frame = QFrame()
        self.progress_frame.setVisible(False)
        self.progress_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 6px;
                padding: 12px;
            }}
        """)
        progress_layout = QVBoxLayout(self.progress_frame)
        
        progress_header = QHBoxLayout()
        self.progress_label = QLabel("正在注册...")
        self.progress_label.setFont(CyberTheme.get_font(13, True))
        progress_header.addWidget(self.progress_label)
        progress_layout.addLayout(progress_header)

        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(6)
        self.progress_bar.setTextVisible(False)
        progress_layout.addWidget(self.progress_bar)

        self.progress_text = QLabel("准备开始...")
        self.progress_text.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; font-size: 12px;")
        progress_layout.addWidget(self.progress_text)
        
        left_panel.addWidget(self.progress_frame)

        # 3. 操作按钮
        btn_layout = QHBoxLayout()
        self.start_btn = QPushButton("开始注册")
        self.start_btn.setMinimumHeight(40)
        self.start_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_PRIMARY};
                color: {CyberTheme.COLOR_BG_PRIMARY};
                font-weight: bold;
                font-size: 14px;
                border: none;
                border-radius: 4px;
            }}
            QPushButton:hover {{
                background-color: #33ffb2;
            }}
            QPushButton:disabled {{
                background-color: {CyberTheme.COLOR_BG_TERTIARY};
                color: {CyberTheme.COLOR_TEXT_MUTED};
            }}
        """)
        
        self.stop_btn = QPushButton("停止")
        self.stop_btn.setMinimumHeight(40)
        self.stop_btn.setEnabled(False)
        self.stop_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                border: 1px solid {CyberTheme.COLOR_DANGER};
                color: {CyberTheme.COLOR_DANGER};
                border-radius: 4px;
            }}
            QPushButton:hover {{
                background-color: {CyberTheme.COLOR_DANGER};
                color: white;
            }}
             QPushButton:disabled {{
                border-color: {CyberTheme.COLOR_BORDER};
                color: {CyberTheme.COLOR_TEXT_MUTED};
            }}
        """)

        btn_layout.addWidget(self.start_btn, 2)
        btn_layout.addWidget(self.stop_btn, 1)
        left_panel.addLayout(btn_layout)
        
        left_panel.addStretch() # 底部弹簧

        # 右侧：日志区
        right_panel = QVBoxLayout()
        
        log_label = QLabel("运行日志")
        log_label.setFont(CyberTheme.get_font(13, True))
        right_panel.addWidget(log_label)

        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setStyleSheet(f"""
            QTextEdit {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
                color: {CyberTheme.COLOR_TEXT_SECONDARY};
                font-family: 'Consolas', 'Monaco', monospace;
                font-size: 12px;
                padding: 8px;
            }}
            
            /* 滚动条样式优化 */
            QScrollBar:vertical {{
                border: none;
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                width: 10px;
                margin: 0px;
            }}
            QScrollBar::handle:vertical {{
                background-color: {CyberTheme.COLOR_BG_TERTIARY};
                min-height: 30px;
                border-radius: 5px;
                margin: 2px;
            }}
            QScrollBar::handle:vertical:hover {{
                background-color: {CyberTheme.COLOR_TEXT_SECONDARY};
            }}
            QScrollBar::handle:vertical:pressed {{
                background-color: {CyberTheme.COLOR_PRIMARY};
            }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
                height: 0px;
                background: none;
            }}
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{
                background: none;
            }}
        """)
        right_panel.addWidget(self.log_text)

        # 添加左右布局
        content_layout.addLayout(left_panel, 1)
        content_layout.addLayout(right_panel, 1)
        
        layout.addLayout(content_layout)

    def setup_connections(self):
        self.start_btn.clicked.connect(self.on_start_registration)
        self.stop_btn.clicked.connect(self.on_stop_registration)

    def on_start_registration(self, _checked=False):
        try:
            self.log_text.clear()
            self.log_text.append(">>> 开始注册流程")
            
            # 生成邮箱
            email_config = self.config_manager.get_email_config()
            domain = getattr(email_config, 'domain', 'mzyota')
            
            if email_config.mode == 'imap':
                # IMAP 模式使用统一 EmailHandler (支持别名生成)
                from core.email_handler import EmailHandler
                email_handler = EmailHandler(email_config)
                email = email_handler.generate_email()
            else:
                # TempMail 模式使用 LegacyEmailHandler
                from core.legacy_email_handler import LegacyEmailHandler
                legacy_handler = LegacyEmailHandler(domain)
                email = legacy_handler.generate_email()
            
            self.log_text.append(f"目标邮箱: {email}")

            config = {
                'email_domain': domain,
                'email_config': email_config,
                'selected_domain': self.selected_domain
            }

            self.worker = RegistrationWorker(email, config)
            self.worker.progress_signal.connect(self.on_progress_update)
            self.worker.finished_signal.connect(self.on_registration_finished)

            self.worker.start()

            # UI状态更新
            self.start_btn.setEnabled(False)
            self.stop_btn.setEnabled(True)
            self.mode_group.blockSignals(True) # 暂时禁用模式切换
            
            self.progress_frame.setVisible(True)
            self.progress_bar.setValue(0)
            self.progress_text.setText("准备就绪")

        except RuntimeError as e:
            # 捕获浏览器未安装的错误
            self.log_text.append(f"环境错误: {str(e)}")
            res = CyberMessageBox.question(
                self,
                "缺少运行环境",
                f"{str(e)}\n\n是否立即前往下载？"
            )
            if res == 16384: # Yes
                from PyQt6.QtGui import QDesktopServices
                from PyQt6.QtCore import QUrl
                QDesktopServices.openUrl(QUrl("https://www.google.cn/chrome/"))
            self.reset_ui()

        except Exception as e:
            self.log_text.append(f"启动失败: {str(e)}")
            self.reset_ui()

    def on_stop_registration(self, _checked=False):
        if self.worker and self.worker.isRunning():
            self.worker.terminate()
            self.worker.wait()
        
        self.log_text.append(">>> 注册已手动停止")
        self.reset_ui()

    def on_progress_update(self, message: str, progress: int):
        self.progress_bar.setValue(progress)
        
        # 优化日志显示：去除纯数字进度消息，去除技术性堆栈
        clean_msg = message
        
        # 如果消息包含进度百分比，尝试提取核心内容
        if "%" in message:
            clean_msg = message.split("(")[0].strip()
        
        self.progress_text.setText(clean_msg)
        

        if "Traceback" in message or "File " in message:
            # 简化技术错误
            clean_msg = "发生内部错误，请重试"
            
        timestamp = datetime.now().strftime('%H:%M:%S')
        
        # 避免重复日志
        last_log = self.log_text.toPlainText().strip().split('\n')[-1] if self.log_text.toPlainText() else ""
        if clean_msg not in last_log:
            self.log_text.append(f"[{timestamp}] {clean_msg}")

    def on_registration_finished(self, success: bool, message: str, account_data: dict):
        self.reset_ui()
        
        if success:
            self.log_text.append(f">>> 注册成功: {message}")
            if account_data:
                try:
                    # 构造 AccountInfo 对象用于发送信号 (UI显示)
                    # 注意：
                    # 1. 此时底层(Drission模块)已经将完整数据(含机器码)保存到数据库
                    # 2. 这里不再调用 add_account，防止UI层覆盖底层的完整数据
                    # 3. 调整 Token 映射以符合 UI 显示需求：
                    #    - AccessToken 显示 SessionToken (ey...)
                    #    - RefreshToken 显示原始 AccessToken (user...)
                    
                    account = AccountInfo(
                        email=account_data.get('email', ''),
                        access_token=account_data.get('session_token', ''), # UI 显示 SessionToken
                        refresh_token=account_data.get('access_token', ''), # UI 显示原始 Token
                        session_token=account_data.get('session_token', ''),
                        membership_type=account_data.get('membership_type', 'free'),
                        days_remaining=account_data.get('days_remaining', 30),
                        register_type='auto' if self.auto_radio.isChecked() else 'manual',
                        created_at=datetime.now().isoformat()
                    )
                    
                    # 仅发送信号更新 UI，不重复保存
                    self.account_registered.emit(account)
                    self.log_text.append("账户已自动保存到账户池")
                    CyberMessageBox.information(self, "成功", "注册成功，账户已保存！")

                except Exception as e:
                    self.log_text.append(f"错误：数据处理异常 {str(e)}")
        else:
            self.log_text.append(f">>> 注册失败: {message}")
            CyberMessageBox.warning(self, "注册失败", f"注册过程中出现错误：\n{message}")

    def reset_ui(self):
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.mode_group.blockSignals(False)
        self.progress_frame.setVisible(False)
        if self.worker:
            self.worker = None
