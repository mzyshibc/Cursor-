#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
设置页面
包含重置机器码、备份配置、恢复配置功能
"""

import os
import shutil
import zipfile
import datetime
import time
from pathlib import Path
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
    QGroupBox, QFileDialog, QProgressBar, QCheckBox
)
from PyQt6.QtCore import QThread, pyqtSignal

from ui.styles import CyberTheme
from ui.custom_widgets import CyberMessageBox
from core.drission_modules.cursor_switcher import get_switcher
from utils.app_paths import resource_path
from utils.region_bypass import RegionBypass
from utils.update_blocker import UpdateBlocker

class BackupWorker(QThread):
    """备份任务线程"""
    progress = pyqtSignal(int, str)
    finished = pyqtSignal(bool, str)

    def __init__(self, save_path: str):
        super().__init__()
        self.save_path = save_path
        self.switcher = get_switcher()

    def run(self):
        try:
            zip_path = Path(self.save_path)
            
            # 获取目录路径
            cursor_dir = self.switcher.cursor_dir  # %APPDATA%/Cursor
            user_dir = cursor_dir / 'User'
            
            # 扩展目录通常在用户目录下
            home = Path.home()
            extensions_dir = home / '.cursor' / 'extensions'
            
            self.progress.emit(10, "正在扫描文件...")
            
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                # 1. 备份 User 目录 (排除一些大文件或缓存)
                if user_dir.exists():
                    self.progress.emit(20, "正在备份用户配置...")
                    for root, dirs, files in os.walk(user_dir):
                        for file in files:
                            file_path = Path(root) / file
                            # 计算相对路径
                            arcname = f"User/{file_path.relative_to(user_dir)}"
                            
                            # 过滤缓存文件
                            if 'Cache' in str(file_path) or 'Cached' in str(file_path):
                                continue
                            if file.endswith('.log') or file.endswith('.lock'):
                                continue
                                
                            zf.write(file_path, arcname)

                # 2. 备份扩展目录
                if extensions_dir.exists():
                    self.progress.emit(50, "正在备份扩展插件 (可能需要较长时间)...")
                    for root, dirs, files in os.walk(extensions_dir):
                        for file in files:
                            file_path = Path(root) / file
                            arcname = f"Extensions/{file_path.relative_to(extensions_dir)}"
                            zf.write(file_path, arcname)
            
            self.progress.emit(100, "备份完成")
            self.finished.emit(True, f"备份已保存至: {zip_path}")
            
        except Exception as e:
            self.finished.emit(False, str(e))


class RestoreWorker(QThread):
    """恢复任务线程"""
    progress = pyqtSignal(int, str)
    finished = pyqtSignal(bool, str)

    def __init__(self, backup_path: str):
        super().__init__()
        self.backup_path = backup_path
        self.switcher = get_switcher()

    def run(self):
        try:
            zip_path = Path(self.backup_path)
            if not zip_path.exists():
                raise FileNotFoundError("备份文件不存在")

            # 1. 强制关闭 Cursor
            self.progress.emit(10, "正在关闭 Cursor 进程...")
            if not self.switcher.close_cursor_gracefully():
                self.progress.emit(15, "无法完全关闭 Cursor，尝试强制清理...")
                self.switcher.kill_cursor_force()
            
            time.sleep(1)

            # 2. 准备目录
            cursor_dir = self.switcher.cursor_dir
            user_dir = cursor_dir / 'User'
            home = Path.home()
            extensions_dir = home / '.cursor' / 'extensions'

            self.progress.emit(30, "正在清理旧配置...")
            
            with zipfile.ZipFile(zip_path, 'r') as zf:
                file_list = zf.namelist()
                has_ext = any(f.startswith('Extensions/') for f in file_list)
                
                if has_ext and extensions_dir.exists():
                    try:
                        shutil.rmtree(extensions_dir)
                    except:
                        pass
                    extensions_dir.mkdir(parents=True, exist_ok=True)

                self.progress.emit(50, "正在解压文件...")
                
                total_files = len(file_list)
                for idx, file in enumerate(file_list):
                    if idx % 50 == 0:
                        percent = 50 + int((idx / total_files) * 40)
                        self.progress.emit(percent, f"正在恢复: {file}")
                    
                    if file.startswith('User/'):
                        target_path = user_dir / file[5:]
                        target_path.parent.mkdir(parents=True, exist_ok=True)
                        with zf.open(file) as source, open(target_path, "wb") as target:
                            shutil.copyfileobj(source, target)
                            
                    elif file.startswith('Extensions/'):
                        target_path = extensions_dir / file[11:]
                        target_path.parent.mkdir(parents=True, exist_ok=True)
                        with zf.open(file) as source, open(target_path, "wb") as target:
                            shutil.copyfileobj(source, target)

            self.progress.emit(100, "恢复完成")
            self.finished.emit(True, "配置已成功恢复，请重启 Cursor")

        except Exception as e:
            self.finished.emit(False, str(e))


class SettingsWidget(QWidget):
    """设置页面组件"""
    
    def __init__(self, config_manager=None):
        super().__init__()
        self.config_manager = config_manager
        self.switcher = get_switcher()
        self.region_bypass = RegionBypass()
        self.update_blocker = UpdateBlocker()
        self.init_ui()
        
    def init_ui(self):
        """初始化 UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)
        
        # 1. 机器码管理卡片
        self.init_machine_id_card(layout)
        
        # 2. 自动更新管理卡片
        self.init_update_blocker_card(layout)
        
        # 3. 地区限制管理卡片
        self.init_region_card(layout)
        
        # 4. 备份恢复卡片
        self.init_backup_restore_card(layout)

        layout.addStretch()

    def init_machine_id_card(self, parent_layout):
        """机器码管理区域"""
        group = QGroupBox("机器码管理")
        group.setStyleSheet(f"""
            QGroupBox {{
                font-weight: bold;
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 15px;
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                background-color: {CyberTheme.COLOR_BG_CARD};
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                subcontrol-position: top left;
                left: 15px;
                padding: 0 5px;
                color: {CyberTheme.COLOR_PRIMARY};
            }}
        """)
        
        layout = QVBoxLayout(group)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        info_label = QLabel(
            "重置机器码可生成新设备指纹，解决设备被封禁问题。\n"
            "注意：Cursor 将被重启并识别为新设备。"
        )
        info_label.setWordWrap(True)
        info_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; font-size: 12px;")
        layout.addWidget(info_label)
        
        btn_layout = QHBoxLayout()
        self.reset_btn = QPushButton("重置机器码")
        self.reset_btn.setFixedSize(140, 36)
        self.reset_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_PRIMARY};
                color: white;
                border: none;
                border-radius: 4px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: {CyberTheme.COLOR_PRIMARY_HOVER};
            }}
        """)
        self.reset_btn.clicked.connect(self.on_reset_machine_id)
        btn_layout.addWidget(self.reset_btn)
        btn_layout.addStretch()
        layout.addLayout(btn_layout)
        parent_layout.addWidget(group)

    def init_update_blocker_card(self, parent_layout):
        """屏蔽更新管理区域"""
        group = QGroupBox("自动更新管理")
        group.setStyleSheet(f"""
            QGroupBox {{
                font-weight: bold;
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 15px;
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                background-color: {CyberTheme.COLOR_BG_CARD};
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                subcontrol-position: top left;
                left: 15px;
                padding: 0 5px;
                color: {CyberTheme.COLOR_PRIMARY};
            }}
        """)
        
        layout = QVBoxLayout(group)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        self.block_update_cb = QCheckBox("屏蔽 Cursor 自动更新")
        self.block_update_cb.setChecked(False)
        check_icon_path = resource_path("src/assets/check.svg").as_posix()
        self.block_update_cb.setStyleSheet(f"""
            QCheckBox {{
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                spacing: 8px;
                font-weight: bold;
            }}
            QCheckBox::indicator {{
                width: 18px;
                height: 18px;
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
            }}
            QCheckBox::indicator:checked {{
                background-color: {CyberTheme.COLOR_PRIMARY};
                border-color: {CyberTheme.COLOR_PRIMARY};
                image: url({check_icon_path});
            }}
        """)
        self.block_update_cb.clicked.connect(self.on_block_update_toggled)
        
        desc_label = QLabel("开启后将修改 Cursor 配置以禁用自动更新，防止版本升级导致插件失效。")
        desc_label.setWordWrap(True)
        desc_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; font-size: 12px; margin-top: 2px;")
        
        layout.addWidget(self.block_update_cb)
        layout.addWidget(desc_label)
        parent_layout.addWidget(group)

    def on_block_update_toggled(self, _checked=False):
        is_checked = self.block_update_cb.isChecked()
        if is_checked:
            success, msg = self.update_blocker.block_updates()
            if success:
                CyberMessageBox.information(self, "成功", msg)
            else:
                self.block_update_cb.setChecked(False)
                CyberMessageBox.critical(self, "失败", msg)
        else:
            success, msg = self.update_blocker.unblock_updates()
            if success:
                CyberMessageBox.information(self, "成功", msg)
            else:
                self.block_update_cb.setChecked(True)
                CyberMessageBox.critical(self, "失败", msg)

    def init_region_card(self, parent_layout):
        """地区限制管理区域"""
        group = QGroupBox("地区限制管理")
        group.setStyleSheet(f"""
            QGroupBox {{
                font-weight: bold;
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 15px;
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                background-color: {CyberTheme.COLOR_BG_CARD};
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                subcontrol-position: top left;
                left: 15px;
                padding: 0 5px;
                color: {CyberTheme.COLOR_PRIMARY};
            }}
        """)
        
        layout = QVBoxLayout(group)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        self.region_bypass_cb = QCheckBox("开启地区限制突破")
        self.region_bypass_cb.setChecked(False)
        check_icon_path = resource_path("src/assets/check.svg").as_posix()
        self.region_bypass_cb.setStyleSheet(f"""
            QCheckBox {{
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                spacing: 8px;
                font-weight: bold;
            }}
            QCheckBox::indicator {{
                width: 18px;
                height: 18px;
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
            }}
            QCheckBox::indicator:checked {{
                background-color: {CyberTheme.COLOR_PRIMARY};
                border-color: {CyberTheme.COLOR_PRIMARY};
                image: url({check_icon_path});
            }}
        """)
        self.region_bypass_cb.clicked.connect(self.on_region_bypass_toggled)
        
        desc_label = QLabel(
            "开启此功能将通过优化网络连接路径，解决部分地区因网络限制导致的 Cursor 服务响应超时或不可用问题。"
        )
        desc_label.setWordWrap(True)
        desc_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; font-size: 12px; margin-top: 2px;")
        
        layout.addWidget(self.region_bypass_cb)
        layout.addWidget(desc_label)
        parent_layout.addWidget(group)

    def on_region_bypass_toggled(self, _checked=False):
        is_checked = self.region_bypass_cb.isChecked()
        if is_checked:
            success, msg = self.region_bypass.enable()
            if success:
                CyberMessageBox.information(self, "成功", msg)
            else:
                self.region_bypass_cb.setChecked(False)
                CyberMessageBox.critical(self, "失败", msg)
        else:
            success, msg = self.region_bypass.disable()
            if success:
                CyberMessageBox.information(self, "成功", msg)
            else:
                self.region_bypass_cb.setChecked(True)
                CyberMessageBox.critical(self, "失败", msg)

    def init_backup_restore_card(self, parent_layout):
        """备份恢复区域"""
        group = QGroupBox("配置备份与恢复")
        group.setStyleSheet(f"""
            QGroupBox {{
                font-weight: bold;
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 15px;
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                background-color: {CyberTheme.COLOR_BG_CARD};
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                subcontrol-position: top left;
                left: 15px;
                padding: 0 5px;
                color: {CyberTheme.COLOR_ACCENT};
            }}
        """)
        
        layout = QVBoxLayout(group)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        info_label = QLabel("备份配置 (含设置、快捷键、扩展)，支持一键恢复。")
        info_label.setWordWrap(True)
        info_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; font-size: 12px;")
        layout.addWidget(info_label)
        
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(15)
        
        self.backup_btn = QPushButton("备份当前配置")
        self.backup_btn.setFixedSize(140, 36)
        self.backup_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
            }}
            QPushButton:hover {{
                border-color: {CyberTheme.COLOR_ACCENT};
                color: {CyberTheme.COLOR_ACCENT};
            }}
        """)
        self.backup_btn.clicked.connect(self.on_backup_config)
        
        self.restore_btn = QPushButton("恢复配置")
        self.restore_btn.setFixedSize(140, 36)
        self.restore_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
            }}
            QPushButton:hover {{
                border-color: {CyberTheme.COLOR_WARNING};
                color: {CyberTheme.COLOR_WARNING};
            }}
        """)
        self.restore_btn.clicked.connect(self.on_restore_config)
        
        btn_layout.addWidget(self.backup_btn)
        btn_layout.addWidget(self.restore_btn)
        btn_layout.addStretch()
        layout.addLayout(btn_layout)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(4)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.hide()
        layout.addWidget(self.progress_bar)
        
        self.status_label = QLabel("")
        self.status_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_MUTED}; font-size: 12px;")
        self.status_label.hide()
        layout.addWidget(self.status_label)
        
        parent_layout.addWidget(group)

    def on_reset_machine_id(self, _checked=False):
        result = CyberMessageBox.question(
            self, "确认重置", "确定要重置机器码吗？\n\n此操作将生成新的设备指纹，Cursor 将被重启。"
        )
        if result == 16384:
            try:
                self.switcher.close_cursor_gracefully()
                self.switcher.reset_machine_ids()
                self.switcher.start_cursor()
                CyberMessageBox.information(self, "成功", "机器码已成功重置！\n\nCursor 正在重启...")
            except Exception as e:
                CyberMessageBox.critical(self, "错误", f"重置失败: {str(e)}")

    def on_backup_config(self, _checked=False):
        default_name = f"cursor_backup_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
        file_path, _ = QFileDialog.getSaveFileName(
            self, "保存备份文件", str(Path.home() / "Desktop" / default_name), "ZIP 文件 (*.zip)"
        )
        if file_path:
            self.start_worker(BackupWorker(file_path))

    def on_restore_config(self, _checked=False):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "选择备份文件", str(Path.home() / "Desktop"), "ZIP 文件 (*.zip)"
        )
        if file_path:
            result = CyberMessageBox.question(
                self, "确认恢复", "恢复操作将覆盖现有的配置和扩展插件。\n\n确定要继续吗？"
            )
            if result == 16384:
                self.start_worker(RestoreWorker(file_path))

    def start_worker(self, worker):
        self.worker = worker
        self.backup_btn.setEnabled(False)
        self.restore_btn.setEnabled(False)
        self.progress_bar.setValue(0)
        self.progress_bar.show()
        self.status_label.setText("准备中...")
        self.status_label.show()
        self.worker.progress.connect(self.update_progress)
        self.worker.finished.connect(self.task_finished)
        self.worker.start()

    def update_progress(self, value, text):
        self.progress_bar.setValue(value)
        self.status_label.setText(text)

    def task_finished(self, success, message):
        self.backup_btn.setEnabled(True)
        self.restore_btn.setEnabled(True)
        self.progress_bar.hide()
        if success:
            self.status_label.setText("操作成功")
            CyberMessageBox.information(self, "成功", message)
        else:
            self.status_label.setText("操作失败")
            CyberMessageBox.critical(self, "错误", f"操作失败: {message}")
