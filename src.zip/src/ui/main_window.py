#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
主窗口 - 重构版
"""

from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QStackedWidget,
    QLabel, QPushButton, QListWidget, QListWidgetItem
)
from PyQt6.QtCore import Qt, QTimer, QSize
from PyQt6.QtGui import QIcon, QMouseEvent, QPixmap, QPainter, QColor, QFont
from pathlib import Path

from core.account_manager import AccountManager
from ui.account_pool_widget import AccountPoolWidget
from ui.email_config_widget import EmailConfigWidget
from ui.registration_widget import RegistrationWidget
from ui.settings_widget import SettingsWidget
from ui.about_widget import AboutWidget
from utils.config import ConfigManager
from utils.license_validator import LicenseValidator
from utils.license_monitor import LicenseMonitor
from ui.styles import CyberTheme
from ui.custom_widgets import RainbowTitleLabel, CyberMessageBox
from utils.app_paths import resource_path


class MainWindow(QMainWindow):
    """主窗口"""

    def __init__(self, license_data: dict = None, config_manager: ConfigManager = None):
        """
        初始化主窗口
        """
        super().__init__()
        self.license_data = license_data or {}
        self.config_manager = config_manager or ConfigManager()

        # 初始化核心组件
        self.account_manager = AccountManager()
        self.license_validator = LicenseValidator(self.config_manager)

        # 初始化实时监控
        auth_config = self.config_manager.get_auth_config()
        if auth_config and auth_config.server_url:
            self.license_monitor = LicenseMonitor(auth_config.server_url, self.license_validator.machine_id)
            self.license_monitor.license_revoked.connect(self.on_remote_revocation)
            self.license_monitor.config_updated.connect(self.on_config_updated)
            self.license_monitor.start()
        else:
            self.license_monitor = None

        # 拖动相关
        self._drag_pos = None

        # 设置窗口属性
        self.setWindowTitle("Cursor Pro Manager")
        self.setMinimumSize(960, 640) # 缩小最小尺寸
        self.resize(1000, 700)        # 默认尺寸
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint) # 无边框窗口
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        self.init_ui()
        self.setup_connections()

        # 启动定时器检查许可证状态
        self.license_check_timer = QTimer(self)
        self.license_check_timer.timeout.connect(self.check_license_status)
        self.license_check_timer.start(20000)  # 优化：每20秒检查一次本地文件防篡改


    def init_ui(self):
        """初始化UI"""
        # 创建中央组件 - 主容器
        central_widget = QWidget()
        central_widget.setObjectName("CentralWidget")
        central_widget.setStyleSheet(f"""
            #CentralWidget {{
                background-color: {CyberTheme.COLOR_BG_PRIMARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 8px;
            }}
        """)
        self.setCentralWidget(central_widget)

        # 主布局
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # 1. 自定义标题栏
        self.init_title_bar(main_layout)

        # 2. 内容区域 (水平布局: 左侧导航 + 右侧内容)
        content_layout = QHBoxLayout()
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)

        # 左侧导航栏
        self.init_sidebar(content_layout)

        # 右侧内容堆栈
        self.stack_widget = QStackedWidget()
        self.stack_widget.setStyleSheet("background-color: transparent;")
        
        # 初始化各个页面
        self.init_pages()
        
        content_layout.addWidget(self.stack_widget)
        main_layout.addLayout(content_layout)

        # 3. 状态栏 (自定义更紧凑的状态栏)
        self.init_status_bar(main_layout)

    def init_title_bar(self, parent_layout):
        """初始化标题栏"""
        title_bar = QWidget()
        title_bar.setFixedHeight(56) # 进一步增加高度以适应超大字体
        title_bar.setStyleSheet(f"""
            QWidget {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                border-bottom: 1px solid {CyberTheme.COLOR_BORDER};
            }}
        """)

        title_layout = QHBoxLayout(title_bar)
        title_layout.setContentsMargins(16, 0, 8, 0)
        title_layout.setSpacing(12)

        # 标题
        
        # 应用 Logo
        logo_label = QLabel()
        logo_label.setFixedSize(24, 24)
        logo_label.setScaledContents(True)
        
        # 获取图标路径
        # 使用 resource_path 获取打包后的正确路径
        icon_path = resource_path("src/assets/icon.ico")
        pixmap = QPixmap()
        
        if icon_path.exists():
            pixmap = QPixmap(str(icon_path))
            
        # 如果加载失败，尝试备用路径（兼容旧环境）
        if pixmap.isNull():
             backup_path = r"F:\Cursorzidongzhuce\cursor-vip-unified\src\assets\icon.ico"
             if Path(backup_path).exists():
                 pixmap = QPixmap(backup_path)

        if not pixmap.isNull():
            logo_label.setPixmap(pixmap)
            self.setWindowIcon(QIcon(pixmap))

        title_layout.addWidget(logo_label)

        title_label = RainbowTitleLabel("Cursor Pro Manager", font_size=18, bold=True)
        # 设置 SizePolicy 防止被压缩
        from PyQt6.QtWidgets import QSizePolicy
        title_label.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        title_layout.addWidget(title_label)

        # 增加一个弹簧，将许可证信息推向右侧
        title_layout.addStretch() 

        # 许可证信息
        self.license_info_label = QLabel()
        self.license_info_label.setStyleSheet("border: none; margin-right: 20px;") # 右边距
        self.update_license_display()
        title_layout.addWidget(self.license_info_label)

        # 增加一个弹簧，使许可证信息居中（如果左边也有弹簧的话）
        # 但由于左边的 Logo + Title 和右边的 Controls 宽度不同，物理居中需要调整 stretch 比例
        # 为了简单起见，我们假设左边 Logo+Title 占一部分，右边 Controls 占一部分
        # 如果要居中 License Info，我们需要在它两边都放 Stretch
        
        title_layout.addStretch()

        # 窗口控制按钮
        control_layout = QHBoxLayout()
        control_layout.setSpacing(4)

        btn_style = f"""
            QPushButton {{
                background-color: transparent;
                border: none;
                border-radius: 4px;
                color: {CyberTheme.COLOR_TEXT_SECONDARY};
                font-family: "Segoe MDL2 Assets", "Segoe UI Symbol", sans-serif;
                font-size: 12px;
                width: 32px;
                height: 24px;
                padding: 0;
            }}
            QPushButton:hover {{
                background-color: {CyberTheme.COLOR_BG_TERTIARY};
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
            }}
        """

        minimize_btn = QPushButton("─")
        minimize_btn.setStyleSheet(btn_style)
        minimize_btn.clicked.connect(self.showMinimized)

        close_btn = QPushButton("✕")
        close_btn.setStyleSheet(btn_style.replace(
            f"background-color: {CyberTheme.COLOR_BG_TERTIARY};", 
            f"background-color: {CyberTheme.COLOR_DANGER};"
        ))
        close_btn.clicked.connect(self.close)

        control_layout.addWidget(minimize_btn)
        control_layout.addWidget(close_btn)

        title_layout.addLayout(control_layout)
        parent_layout.addWidget(title_bar)

    def init_sidebar(self, parent_layout):
        """初始化左侧导航栏"""
        sidebar_container = QWidget()
        sidebar_container.setFixedWidth(160) # 更窄的侧边栏
        sidebar_container.setStyleSheet(f"""
            QWidget {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                border-right: 1px solid {CyberTheme.COLOR_BORDER};
                border-bottom-left-radius: 8px;
            }}
        """)
        
        sidebar_layout = QVBoxLayout(sidebar_container)
        sidebar_layout.setContentsMargins(0, 10, 0, 10)
        sidebar_layout.setSpacing(0)

        # 导航列表
        self.nav_list = QListWidget()
        self.nav_list.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.nav_list.setStyleSheet(f"""
            QListWidget {{
                background-color: transparent;
                border: none;
                outline: none;
            }}
            QListWidget::item {{
                height: 48px; /* 增加高度以容纳图标 */
                padding-left: 0px; /* 图标自带左间距 */
                color: {CyberTheme.COLOR_TEXT_SECONDARY};
                border-left: 3px solid transparent;
                margin-bottom: 2px;
                font-size: 13px;
            }}
            QListWidget::item:hover {{
                background-color: {CyberTheme.COLOR_BG_TERTIARY};
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
            }}
            QListWidget::item:selected {{
                background-color: {CyberTheme.COLOR_BG_TERTIARY};
                color: {CyberTheme.COLOR_PRIMARY};
                border-left: 3px solid {CyberTheme.COLOR_PRIMARY};
                font-weight: bold;
            }}
        """)
        
        # 添加导航项 (使用 Segoe MDL2 Assets 字体图标)
        # \xE77B (User), \xE710 (Add), \xE715 (Mail), \xE713 (Settings)
        self.add_nav_item("账户池", "\ue77b") 
        self.add_nav_item("注册", "\ue710")     
        self.add_nav_item("邮箱", "\ue715")     
        self.add_nav_item("设置", "\ue713") 
        self.add_nav_item("关于软件", "\ue946") # Info icon
        
        self.nav_list.currentRowChanged.connect(self.on_nav_changed)
        
        sidebar_layout.addWidget(self.nav_list)
        
        # 版本号
        version_label = QLabel("v1.0.0") # 统一使用 v1.0.0
        version_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        version_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_MUTED}; font-size: 11px; margin-bottom: 10px;")
        sidebar_layout.addWidget(version_label)
        
        parent_layout.addWidget(sidebar_container)

    def add_nav_item(self, text, icon_code):
        """添加导航项"""
        item = QListWidgetItem(text)
        item.setSizeHint(QSize(0, 48)) # 稍微增加高度
        
        # 生成字体图标
        icon = self.create_font_icon(icon_code)
        item.setIcon(icon)
        
        self.nav_list.addItem(item)

    def create_font_icon(self, char_code, size=24, color="#a1a1aa"):
        """从字体字符生成图标"""
        pixmap = QPixmap(size, size)
        pixmap.fill(Qt.GlobalColor.transparent)
        
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(QColor(color))
        
        font = QFont("Segoe MDL2 Assets", 14)
        painter.setFont(font)
        
        painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, char_code)
        painter.end()
        
        return QIcon(pixmap)

    def init_pages(self):
        """初始化所有页面"""
        # 1. 账户管理池
        self.account_pool = AccountPoolWidget(self.account_manager)
        self.stack_widget.addWidget(self.account_pool)

        # 2. 账户注册
        self.registration_widget = RegistrationWidget(self.account_manager, self.config_manager)
        self.stack_widget.addWidget(self.registration_widget)

        # 3. 邮箱配置
        self.email_config_widget = EmailConfigWidget(self.config_manager)
        self.stack_widget.addWidget(self.email_config_widget)

        # 4. 系统设置
        self.settings_widget = SettingsWidget(self.config_manager)
        self.stack_widget.addWidget(self.settings_widget)

        # 5. 关于页面
        self.about_widget = AboutWidget(self.config_manager)
        self.stack_widget.addWidget(self.about_widget)

        # 默认选中第一项
        self.nav_list.setCurrentRow(0)

    def init_status_bar(self, parent_layout):
        """初始化状态栏"""
        status_container = QWidget()
        status_container.setFixedHeight(28)
        status_container.setStyleSheet(f"""
            QWidget {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                border-top: 1px solid {CyberTheme.COLOR_BORDER};
                border-bottom-right-radius: 8px;
            }}
            QLabel {{
                border: none;
                color: {CyberTheme.COLOR_TEXT_SECONDARY};
                font-size: 11px;
            }}
        """)

        status_layout = QHBoxLayout(status_container)
        status_layout.setContentsMargins(12, 0, 12, 0)
        
        self.current_account_label = QLabel("当前账户: 无")
        status_layout.addWidget(self.current_account_label)
        
        status_layout.addStretch()
        
        status_layout.addWidget(QLabel("就绪"))

        parent_layout.addWidget(status_container)
        
        # 兼容旧代码的 status_bar 引用
        self.status_bar = type('MockStatusBar', (), {'showMessage': self.show_status_message})()

    def show_status_message(self, message, timeout=0):
        """模拟状态栏消息显示"""
        # 简单实现，这里可以扩展
        pass

    def on_nav_changed(self, row):
        """导航切换事件"""
        # 检查授权是否过期
        if self.license_validator.is_license_expired():
             CyberMessageBox.warning(self, "授权已过期", "您的授权码已到期，无法使用此功能。\n请点击右上角关闭按钮或重新运行程序进行激活。")

             self.handle_license_expired("授权已过期")
             return

        self.stack_widget.setCurrentIndex(row)

    # --- 窗口拖动逻辑 ---
    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            # 只有点击标题栏区域才允许拖动 (y < 40)
            if event.position().y() < 40:
                self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
                event.accept()

    def mouseMoveEvent(self, event: QMouseEvent):
        if event.buttons() == Qt.MouseButton.LeftButton and self._drag_pos:
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def mouseReleaseEvent(self, event: QMouseEvent):
        self._drag_pos = None

    # --- 业务逻辑连接 ---
    def setup_connections(self):
        """设置信号连接"""
        # 账户池信号
        self.account_pool.account_selected.connect(self.on_account_selected)
        self.account_pool.account_switched.connect(self.on_account_switched)
        self.account_pool.refresh_requested.connect(self.on_refresh_requested)

        # 注册组件信号
        if hasattr(self.registration_widget, 'account_registered'):
            self.registration_widget.account_registered.connect(self.on_account_registered)

    def update_license_display(self):
        """更新许可证显示"""

        if not hasattr(self, 'breathing_timer'):
            self.breathing_timer = QTimer(self)
            self.breathing_timer.timeout.connect(self._animate_breathing)
            self.breathing_phase = 0
            self.breathing_timer.start(50) # 加快刷新频率以获得更平滑的效果


        if not hasattr(self, 'license_dot_label'):

             pass

        if self.license_data:
            expires_at = self.license_data.get('expires_at', '未知')
            
            # 格式化时间
            try:
                import datetime
                if 'T' in expires_at:
                    dt = datetime.datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
                    local_dt = dt.astimezone()
                    expires_at = local_dt.strftime("%Y-%m-%d %H:%M:%S")
            except:
                pass


            
            self.license_text = f"授权有效 (到期时间: {expires_at})"
            self.current_license_color = "#00ff88" # 更亮的绿色
            self.current_text_color = "#00ff88" # 文字也使用绿色
        else:
            self.license_text = "授权码已到期，请重新授权 X"
            self.current_license_color = "#ff4444" # 更亮的红色
            self.current_text_color = "#ff4444" # 文字也使用红色
            
    def _animate_breathing(self):
        """模拟呼吸灯效果"""
        import math
        self.breathing_phase += 0.15 # 加快呼吸速度
        
        # 呼吸算法：透明度从 0.3 到 1.0
        opacity = 0.4 + 0.6 * (0.5 + 0.5 * math.sin(self.breathing_phase))
        
        # 颜色处理
        base_color = getattr(self, 'current_license_color', "#ff4444")
        text_color = getattr(self, 'current_text_color', "#ffffff")
        
        # 我们利用 QLabel 的 HTML 能力，只改变圆点的透明度/颜色
        # 为了实现“呼吸”，我们调整颜色的 alpha 通道
        
        try:
            r = int(base_color[1:3], 16)
            g = int(base_color[3:5], 16)
            b = int(base_color[5:7], 16)
            
            # 呼吸 alpha: 80 ~ 255
            alpha = int(opacity * 255)
            
            dot_color_rgba = f"rgba({r}, {g}, {b}, {alpha/255.0:.2f})"
            
            # 构造 HTML
            # 圆点使用 span 包裹，应用动态颜色
            # 文字使用静态颜色
            
            html = f"""
            <span style='color: {dot_color_rgba}; font-size: 14px;'>●</span>&nbsp;
            <span style='color: {text_color};'>{self.license_text}</span>
            """
            
            self.license_info_label.setText(html)
            self.license_info_label.setStyleSheet("font-size: 12px; font-weight: bold; border: none; background: transparent; margin-right: 20px;")
            
        except Exception as e:
            # print(f"Animation error: {e}")
            pass

    def on_remote_revocation(self, reason):
        """处理远程撤销"""
        print(f"收到远程撤销指令: {reason}")
        
        # 删除本地文件
        if hasattr(self.license_validator, 'license_file'):
            try:
                self.license_validator.license_file.unlink(missing_ok=True)
            except Exception as e:
                print(f"删除授权文件失败: {e}")
            
        # 更新 UI
        self.license_data = None
        self.update_license_display()
        
        # 弹窗提示并强制重新验证
        # 用户要求：去掉 "管理员已撤销您的授权" 前缀，只显示原因
        # 如果原因是英文的 "License deleted by admin" (兼容旧服务端)，则显示中文
        display_reason = reason
        if "License deleted" in reason or "revoked" in reason:
             display_reason = "您的授权已被撤销"
             
        self.handle_license_expired(f"{display_reason}")

    def on_config_updated(self):
        """处理云端配置更新"""
        print("收到云端配置更新，正在刷新界面...")
        if hasattr(self, 'email_config_widget'):
            # 重新拉取配置
            self.email_config_widget.load_system_config()
            # 提示用户
            CyberMessageBox.information(self, "配置更新", "系统配置已更新，相关选项已自动刷新。")

    def check_license_status(self):
        """检查许可证状态"""
        try:
            is_valid, data = self.license_validator.check_local_license()
            
            # 无论是否有效，都先更新数据以便 UI 显示
            # 如果无效，license_data 设为 None 或根据 data 判断
            if not is_valid:
                self.license_data = None # 或者保留 data 但标记为过期
                self.update_license_display() # 强制更新 UI 显示“已过期”
                
                reason = data.get('expired', '授权无效') if data else '授权无效'
                self.handle_license_expired(reason)
            else:
                self.license_data = data
                self.update_license_display()
        except Exception as e:
            print(f"许可证检查失败: {e}")

    def handle_license_expired(self, reason: str):
        """处理许可证过期"""
        self.license_check_timer.stop()
        # 用户要求：去掉 "您的授权已过期：" 前缀
        CyberMessageBox.warning(self, "授权过期", f"{reason}\n\n请重新授权后继续使用。")
        from ui.auth_dialog import AuthDialog
        auth_dialog = AuthDialog(self.config_manager, self)
        if auth_dialog.exec():
            self.license_data = auth_dialog.license_validator.get_license_info()
            self.update_license_display()
            self.license_check_timer.start()
        else:
            self.close()

    def on_account_selected(self, account):
        """账户选中事件"""
        self.current_account_label.setText(f"当前账户: {account.email}")

    def on_account_switched(self, account):
        """账户切换事件"""
        self.current_account_label.setText(f"当前账户: {account.email} (已切换)")
        QTimer.singleShot(3000, lambda: self.current_account_label.setText(f"当前账户: {account.email}"))

    def on_refresh_requested(self):
        """刷新请求事件"""
        pass # 状态栏简化了，不需要显示临时消息

    def on_account_registered(self, account):
        """账户注册事件"""
        # 重新加载账户列表以确保数据同步（包含正确的ID）
        self.account_pool.load_accounts()
        # 切换到账户池页面
        self.nav_list.setCurrentRow(0)

    def closeEvent(self, event):
        """关闭事件"""
        try:
            if self.license_monitor:
                self.license_monitor.stop()
            self.config_manager.save_config()
        except Exception as e:
            print(f"保存配置失败: {e}")
        event.accept()
