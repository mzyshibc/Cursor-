#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UI样式定义
"""

from PyQt6.QtGui import QColor, QPalette, QFont



class CyberTheme:
    """商业风格主题 - 沉稳蓝调"""

    # 颜色定义
    COLOR_PRIMARY = "#3b82f6"      # 商业蓝 (Blue 500) - 稳重、专业
    COLOR_PRIMARY_HOVER = "#60a5fa" # Blue 400
    COLOR_PRIMARY_PRESSED = "#2563eb" # Blue 600
    
    COLOR_SECONDARY = "#64748b"    # 蓝灰 (Slate 500)
    COLOR_ACCENT = "#8b5cf6"       # 紫色 (Violet 500)
    
    COLOR_WARNING = "#f59e0b"      # 琥珀色 (Amber 500)
    COLOR_DANGER = "#ef4444"       # 红色 (Red 500)
    COLOR_SUCCESS = "#10b981"      # 翡翠绿 (Emerald 500) - 仅用于状态指示

    # 背景色 - 深空灰
    COLOR_BG_PRIMARY = "#18181b"   # Zinc 950
    COLOR_BG_SECONDARY = "#27272a" # Zinc 900
    COLOR_BG_TERTIARY = "#3f3f46"  # Zinc 700 (Hover/Selected)
    COLOR_BG_CARD = "#27272a"      # Zinc 900

    # 文字颜色
    COLOR_TEXT_PRIMARY = "#e4e4e7"   # Zinc 200 - 灰白
    COLOR_TEXT_SECONDARY = "#a1a1aa" # Zinc 400 - 浅灰
    COLOR_TEXT_MUTED = "#71717a"     # Zinc 500 - 深灰
    
    # 边框颜色
    COLOR_BORDER = "#3f3f46"       # Zinc 700
    COLOR_BORDER_ACTIVE = COLOR_PRIMARY

    @staticmethod
    def get_palette() -> QPalette:
        """获取调色板"""
        palette = QPalette()

        # 设置背景色
        palette.setColor(QPalette.ColorRole.Window, QColor(CyberTheme.COLOR_BG_PRIMARY))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(CyberTheme.COLOR_TEXT_PRIMARY))
        palette.setColor(QPalette.ColorRole.Base, QColor(CyberTheme.COLOR_BG_SECONDARY))
        palette.setColor(QPalette.ColorRole.AlternateBase, QColor(CyberTheme.COLOR_BG_TERTIARY))
        palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(CyberTheme.COLOR_BG_CARD))
        palette.setColor(QPalette.ColorRole.ToolTipText, QColor(CyberTheme.COLOR_TEXT_PRIMARY))

        # 设置文字颜色
        palette.setColor(QPalette.ColorRole.Text, QColor(CyberTheme.COLOR_TEXT_PRIMARY))
        palette.setColor(QPalette.ColorRole.BrightText, QColor(CyberTheme.COLOR_TEXT_SECONDARY))
        palette.setColor(QPalette.ColorRole.Highlight, QColor(CyberTheme.COLOR_PRIMARY))
        palette.setColor(QPalette.ColorRole.HighlightedText, QColor("#ffffff"))

        # 设置按钮颜色
        palette.setColor(QPalette.ColorRole.Button, QColor(CyberTheme.COLOR_BG_SECONDARY))
        palette.setColor(QPalette.ColorRole.ButtonText, QColor(CyberTheme.COLOR_TEXT_PRIMARY))

        return palette

    @staticmethod
    def get_font(size: int = 13, bold: bool = False) -> QFont:
        """获取字体"""
        font = QFont("Microsoft YaHei UI", size)
        if bold:
            font.setBold(True)
        font.setStyleHint(QFont.StyleHint.System)
        return font

    @staticmethod
    def get_stylesheet() -> str:
        """获取样式表 - 商业风格"""
        return f"""
        /* 全局样式 */
        * {{
            font-family: 'Microsoft YaHei UI', 'Segoe UI', sans-serif;
            color: {CyberTheme.COLOR_TEXT_PRIMARY};
            font-size: 13px;
        }}

        /* 主窗口和对话框 */
        QMainWindow, QDialog {{
            background-color: {CyberTheme.COLOR_BG_PRIMARY};
        }}
        
        QDialog {{
            border: 1px solid {CyberTheme.COLOR_BORDER};
        }}

        /* 消息框 */
        QMessageBox {{
            background-color: {CyberTheme.COLOR_BG_PRIMARY};
        }}
        QMessageBox QLabel {{
            color: {CyberTheme.COLOR_TEXT_PRIMARY};
            background-color: transparent;
        }}

        /* 分组框 */
        QGroupBox {{
            font-weight: bold;
            border: 1px solid {CyberTheme.COLOR_BORDER};
            border-radius: 6px;
            margin-top: 20px;
            padding-top: 10px;
            color: {CyberTheme.COLOR_TEXT_PRIMARY};
        }}
        
        QGroupBox::title {{
            subcontrol-origin: margin;
            subcontrol-position: top left;
            left: 10px;
            padding: 0 5px;
            color: {CyberTheme.COLOR_PRIMARY};
        }}

        /* 卡片样式 */
        .card, #Card {{
            background-color: {CyberTheme.COLOR_BG_CARD};
            border: 1px solid {CyberTheme.COLOR_BORDER};
            border-radius: 6px;
            padding: 12px;
        }}

        /* 按钮样式 - 商业质感 */
        QPushButton {{
            background-color: {CyberTheme.COLOR_BG_SECONDARY};
            border: 1px solid {CyberTheme.COLOR_BORDER};
            border-radius: 4px;
            padding: 6px 16px;
            font-size: 13px;
            color: {CyberTheme.COLOR_TEXT_PRIMARY};
            min-height: 24px;
        }}

        QPushButton:hover {{
            background-color: {CyberTheme.COLOR_BG_TERTIARY};
            border-color: {CyberTheme.COLOR_TEXT_SECONDARY};
        }}

        QPushButton:pressed {{
            background-color: {CyberTheme.COLOR_BG_PRIMARY};
        }}

        QPushButton:disabled {{
            background-color: {CyberTheme.COLOR_BG_PRIMARY};
            color: {CyberTheme.COLOR_TEXT_MUTED};
            border-color: {CyberTheme.COLOR_BORDER};
        }}

        /* 主要按钮 (Primary) - 实心蓝 */
        QPushButton[class="btn-primary"], .btn-primary {{
            background-color: {CyberTheme.COLOR_PRIMARY};
            color: #ffffff;
            border: 1px solid {CyberTheme.COLOR_PRIMARY};
            font-weight: bold;
        }}

        QPushButton[class="btn-primary"]:hover, .btn-primary:hover {{
            background-color: {CyberTheme.COLOR_PRIMARY_HOVER};
            border-color: {CyberTheme.COLOR_PRIMARY_HOVER};
        }}
        
        QPushButton[class="btn-primary"]:pressed, .btn-primary:pressed {{
            background-color: {CyberTheme.COLOR_PRIMARY_PRESSED};
            border-color: {CyberTheme.COLOR_PRIMARY_PRESSED};
        }}

        /* 危险按钮 */
        QPushButton[class="btn-danger"], .btn-danger {{
            background-color: transparent;
            color: {CyberTheme.COLOR_DANGER};
            border: 1px solid {CyberTheme.COLOR_DANGER};
        }}
        
        QPushButton[class="btn-danger"]:hover, .btn-danger:hover {{
            background-color: {CyberTheme.COLOR_DANGER};
            color: #ffffff;
        }}

        /* 输入框样式 */
        QLineEdit, QTextEdit, QComboBox, QSpinBox {{
            background-color: {CyberTheme.COLOR_BG_SECONDARY};
            border: 1px solid {CyberTheme.COLOR_BORDER};
            border-radius: 4px;
            padding: 6px 8px;
            color: {CyberTheme.COLOR_TEXT_PRIMARY};
            selection-background-color: {CyberTheme.COLOR_PRIMARY};
            selection-color: #ffffff;
        }}

        QLineEdit:focus, QTextEdit:focus, QComboBox:focus, QSpinBox:focus {{
            border-color: {CyberTheme.COLOR_PRIMARY};
            background-color: {CyberTheme.COLOR_BG_SECONDARY};
        }}
        
        QLineEdit::placeholder {{
            color: {CyberTheme.COLOR_TEXT_MUTED};
        }}

        /* 下拉框 */
        QComboBox::drop-down {{
            border: none;
            width: 24px;
        }}
        QComboBox::down-arrow {{
            image: none;
            border: none;
            width: 0; 
            height: 0;
            border-left: 4px solid transparent;
            border-right: 4px solid transparent;
            border-top: 5px solid {CyberTheme.COLOR_TEXT_SECONDARY};
            margin-right: 10px;
        }}

        /* 表格样式 */
        QTableWidget {{
            background-color: {CyberTheme.COLOR_BG_SECONDARY};
            border: 1px solid {CyberTheme.COLOR_BORDER};
            border-radius: 4px;
            gridline-color: {CyberTheme.COLOR_BG_TERTIARY};
            alternate-background-color: #2a2a2d;
        }}

        QTableWidget::item {{
            padding: 4px 8px;
            border-bottom: 1px solid {CyberTheme.COLOR_BG_TERTIARY};
            color: {CyberTheme.COLOR_TEXT_PRIMARY};
        }}

        QTableWidget::item:selected {{
            background-color: {CyberTheme.COLOR_BG_TERTIARY};
            color: {CyberTheme.COLOR_PRIMARY};
            border: none;
            outline: none;
        }}

        QTableWidget:focus {{
            outline: none;
            border: 1px solid {CyberTheme.COLOR_BORDER};
        }}

        QHeaderView::section {{
            background-color: {CyberTheme.COLOR_BG_PRIMARY};
            padding: 8px;
            border: none;
            border-bottom: 1px solid {CyberTheme.COLOR_BORDER};
            font-weight: bold;
            color: {CyberTheme.COLOR_TEXT_SECONDARY};
            text-transform: uppercase;
            font-size: 11px;
        }}

        /* 滚动条 */
        QScrollBar:vertical {{
            background-color: {CyberTheme.COLOR_BG_PRIMARY};
            width: 10px;
            margin: 0;
        }}
        QScrollBar::handle:vertical {{
            background-color: {CyberTheme.COLOR_BG_TERTIARY};
            min-height: 20px;
            border-radius: 5px;
            margin: 2px;
        }}
        QScrollBar::handle:vertical:hover {{
            background-color: {CyberTheme.COLOR_TEXT_MUTED};
        }}
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
            height: 0px;
        }}

        /* 进度条 */
        QProgressBar {{
            border: 1px solid {CyberTheme.COLOR_BORDER};
            border-radius: 4px;
            text-align: center;
            background-color: {CyberTheme.COLOR_BG_SECONDARY};
            color: {CyberTheme.COLOR_TEXT_PRIMARY};
        }}
        QProgressBar::chunk {{
            background-color: {CyberTheme.COLOR_PRIMARY};
        }}
        
        /* 标签页 */
        QTabWidget::pane {{
            border: 1px solid {CyberTheme.COLOR_BORDER};
            background-color: {CyberTheme.COLOR_BG_SECONDARY};
            border-radius: 4px;
        }}
        QTabBar::tab {{
            background-color: {CyberTheme.COLOR_BG_PRIMARY};
            border: 1px solid {CyberTheme.COLOR_BORDER};
            padding: 8px 16px;
            margin-right: 4px;
            border-top-left-radius: 4px;
            border-top-right-radius: 4px;
            color: {CyberTheme.COLOR_TEXT_SECONDARY};
        }}
        QTabBar::tab:selected {{
            background-color: {CyberTheme.COLOR_BG_SECONDARY};
            color: {CyberTheme.COLOR_PRIMARY};
            border-bottom-color: {CyberTheme.COLOR_BG_SECONDARY};
            font-weight: bold;
        }}

        /* 列表样式 */
        QListWidget::item {{
            height: 48px;
            padding-left: 8px;
            color: {CyberTheme.COLOR_TEXT_SECONDARY};
            border-left: 3px solid transparent;
            margin-bottom: 4px;
            border-radius: 4px;
        }}

        QListWidget::item:hover {{
            background-color: {CyberTheme.COLOR_BG_TERTIARY};
            color: {CyberTheme.COLOR_TEXT_PRIMARY};
        }}

        QListWidget::item:selected {{
            background-color: {CyberTheme.COLOR_BG_TERTIARY};
            color: {CyberTheme.COLOR_PRIMARY};
            border-left: 3px solid {CyberTheme.COLOR_PRIMARY};
            font-weight: bold;
            background-color: rgba(59, 130, 246, 0.1);
            outline: none; /* 去除虚线框 */
        }}
        
        QListWidget:focus {{
            outline: none; /* 去除整个控件聚焦时的虚线框 */
        }}
        """

    @staticmethod
    def get_button_style(is_primary: bool = True) -> str:
        """获取按钮样式 (兼容旧接口)"""
        # 返回空字符串，让全局样式表生效
        # 除非需要特定覆盖
        return "" 

    @staticmethod
    def apply_global_style(app):
        """应用全局样式"""
        app.setStyleSheet(CyberTheme.get_stylesheet())
        app.setPalette(CyberTheme.get_palette())
