#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
账户详情对话框 - 重构版
"""

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QScrollArea, QWidget, QApplication,
    QProgressBar
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QMouseEvent

from core.account_manager import AccountInfo, AccountManager
from ui.styles import CyberTheme
from ui.custom_widgets import CyberMessageBox

class ClickableLabel(QLabel):
    """可点击的标签"""
    clicked = pyqtSignal()
    
    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit()
        super().mousePressEvent(event)

class AccountDetailDialog(QDialog):
    """账户详情对话框"""
    
    def __init__(self, account: AccountInfo, account_manager: AccountManager, parent=None):
        super().__init__(parent)
        self.account = account
        self.account_manager = account_manager
        self._drag_pos = None
        
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Dialog)
        self.resize(500, 680) # 更紧凑的尺寸
        self.setStyleSheet(f"background-color: {CyberTheme.COLOR_BG_PRIMARY}; border: 1px solid {CyberTheme.COLOR_BORDER}; border-radius: 8px;")
        
        self.init_ui()
        
    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(0)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # 1. 标题栏
        title_bar = QWidget()
        title_bar.setFixedHeight(40)
        title_bar.setStyleSheet(f"""
            QWidget {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                border-bottom: 1px solid {CyberTheme.COLOR_BORDER};
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                border-bottom-left-radius: 0;
                border-bottom-right-radius: 0;
            }}
        """)
        title_layout = QHBoxLayout(title_bar)
        title_layout.setContentsMargins(16, 0, 8, 0)
        
        # 使用普通 QLabel 替代 RainbowTitleLabel，去掉跑马灯和渐变效果
        title_label = QLabel("账号详情")
        title_label.setFont(CyberTheme.get_font(14, True))
        title_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_PRIMARY}; border: none; background: transparent;")
        title_layout.addWidget(title_label)
        
        title_layout.addStretch()
        
        close_btn = QPushButton("✕")
        close_btn.setFixedSize(32, 24)
        close_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: transparent;
                border: none;
                border-radius: 4px;
                color: {CyberTheme.COLOR_TEXT_SECONDARY};
                font-family: "Segoe MDL2 Assets", "Segoe UI Symbol", sans-serif;
                font-size: 12px;
                padding: 0;
            }}
            QPushButton:hover {{
                background-color: {CyberTheme.COLOR_DANGER};
                color: #ffffff;
            }}
        """)
        close_btn.clicked.connect(self.accept)
        title_layout.addWidget(close_btn)
        
        layout.addWidget(title_bar)
        
        # 2. 内容区域
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        # 现代风格滚动条样式
        scroll.setStyleSheet(f"""
            QScrollArea {{ border: none; background-color: transparent; }}
            
            /* 垂直滚动条整体 */
            QScrollBar:vertical {{
                border: none;
                background-color: {CyberTheme.COLOR_BG_PRIMARY};
                width: 10px; /* 稍微宽一点方便点击 */
                margin: 0px 0px 0px 0px;
            }}
            
            /* 滚动条滑块 */
            QScrollBar::handle:vertical {{
                background-color: {CyberTheme.COLOR_BG_TERTIARY};
                min-height: 30px;
                border-radius: 5px;
                margin: 2px 2px 2px 2px; /* 留出间隙 */
            }}
            
            /* 鼠标悬停在滑块上 */
            QScrollBar::handle:vertical:hover {{
                background-color: {CyberTheme.COLOR_TEXT_SECONDARY};
            }}
            
            /* 鼠标按下滑块 */
            QScrollBar::handle:vertical:pressed {{
                background-color: {CyberTheme.COLOR_PRIMARY};
            }}
            
            /* 轨道 */
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
                height: 0px;
                background: none;
            }}
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{
                background: none;
            }}
        """)
        
        content_widget = QWidget()
        content_widget.setStyleSheet("background-color: transparent; border: none;")
        content_layout = QVBoxLayout(content_widget)
        content_layout.setSpacing(16)
        content_layout.setContentsMargins(20, 20, 20, 20)
        
        # 基本信息
        self.add_section_title(content_layout, "基本信息")
        basic_layout = self.create_grid_layout()
        
        self.add_grid_row(basic_layout, "邮箱账户", self.account.email, True, allow_copy=True)
        
        status_text = self.get_status_text(self.account.status)
        status_color = CyberTheme.COLOR_TEXT_PRIMARY
        if self.account.status and self.account.status.lower() == 'invalid':
            status_color = CyberTheme.COLOR_TEXT_MUTED
        elif self.account.status and self.account.status.lower() == 'active':
            status_color = CyberTheme.COLOR_SUCCESS
            
        self.add_grid_row(basic_layout, "当前状态", status_text, False, status_color)
        self.add_grid_row(basic_layout, "注册时间", self.format_time(self.account.created_at))
        self.add_grid_row(basic_layout, "最后使用", self.format_time(self.account.last_used) if self.account.last_used else "未使用")
        
        content_layout.addLayout(basic_layout)
        
        # 订阅状态
        content_layout.addSpacing(10)
        self.add_section_title(content_layout, "订阅与消耗")
        sub_layout = self.create_grid_layout()
        
        sub_info = self.account.get_subscription_status()
        consumption = self.account.token_consumption or {}
        
        self.add_grid_row(sub_layout, "会员类型", sub_info['type'].upper(), False, CyberTheme.COLOR_ACCENT if sub_info['is_pro'] else None)
        
        # 订阅状态
        status_map = {
            'active': ('正常', CyberTheme.COLOR_SUCCESS),
            'unpaid': ('未付款', CyberTheme.COLOR_DANGER),
            'past_due': ('逾期', CyberTheme.COLOR_WARNING),
            'canceled': ('已取消', CyberTheme.COLOR_TEXT_MUTED),
            'incomplete': ('未完成', CyberTheme.COLOR_WARNING),
            'incomplete_expired': ('未完成且过期', CyberTheme.COLOR_TEXT_MUTED),
            'trialing': ('试用中', CyberTheme.COLOR_ACCENT),
            'paused': ('已暂停', CyberTheme.COLOR_TEXT_MUTED),
            'invalid': ('已失效', CyberTheme.COLOR_TEXT_MUTED)
        }
        
        current_status = self.account.status or 'active'
        
        # 如果是 Free 账号且状态是 active，显示"免费版"
        if sub_info['type'] == 'free' and current_status == 'active':
             display_text, color = ("免费版", CyberTheme.COLOR_TEXT_SECONDARY)
        else:
             display_text, color = status_map.get(current_status, (current_status, CyberTheme.COLOR_TEXT_PRIMARY))
             
        self.add_grid_row(sub_layout, "订阅状态", display_text, False, color)
        
        # 优先显示总费用和欠费
        total_cost = consumption.get('total_cost', 0)
        unpaid_amount = consumption.get('unpaid_amount', 0)
        total_tokens = consumption.get('total_tokens', 0)
        

        # 强制为总费用显示进度条
        # Free套餐$10，Pro套餐$20，作为进度条的分母
        limit = 20.0 if sub_info.get('is_pro') else 10.0
        usage_percent = min(100, (total_cost / limit) * 100) if limit > 0 else 0
        color = CyberTheme.COLOR_DANGER if usage_percent > 90 else (CyberTheme.COLOR_WARNING if usage_percent > 70 else CyberTheme.COLOR_PRIMARY)
        
        # 替换原来的总费用行
        # self.add_grid_row(sub_layout, "总费用", f"${total_cost:.2f}") # 原来的
        self.add_progress_row(sub_layout, "总费用", f"${total_cost:.2f}", usage_percent, color)
        
        # 如果有欠费，用红色显示
        unpaid_color = CyberTheme.COLOR_DANGER if unpaid_amount > 0 else CyberTheme.COLOR_SUCCESS
        self.add_grid_row(sub_layout, "当前欠费", f"${unpaid_amount:.2f}", False, unpaid_color)
        
        # 显示 Token 总消耗
        if total_tokens > 1000000:
             token_str = f"{total_tokens / 1000000:.1f}M"
        elif total_tokens > 1000:
             token_str = f"{total_tokens / 1000:.1f}K"
        else:
             token_str = str(total_tokens)
        self.add_grid_row(sub_layout, "Token消耗", f"{token_str} Tokens")
        
        content_layout.addLayout(sub_layout)
        
        # 模型使用详情 (如果有)
        model_usage = consumption.get('model_usage', {})
        if model_usage:
            content_layout.addSpacing(10)
            self.add_section_title(content_layout, "模型使用详情")
            model_layout = self.create_grid_layout()
            
            # 按费用排序
            sorted_models = sorted(model_usage.items(), key=lambda x: x[1].get('cost', 0), reverse=True)
            
            for model_name, info in sorted_models:
                cost = info.get('cost', 0)
                if cost > 0: # 只显示有费用的模型
                    self.add_grid_row(model_layout, model_name, f"${cost:.2f}")
            
            content_layout.addLayout(model_layout)
        
        # Token 信息
        content_layout.addSpacing(10)
        self.add_section_title(content_layout, "认证凭证")
        
        token_info = self.account.get_token_info()
        valid_text = "有效" if token_info['token_valid'] else "失效"
        valid_color = CyberTheme.COLOR_SUCCESS if token_info['token_valid'] else CyberTheme.COLOR_DANGER
        
        # 如果账号状态标记为无效，强制显示为已失效
        if self.account.status == 'invalid':
            valid_text = "已失效"
            valid_color = CyberTheme.COLOR_TEXT_MUTED
        
        status_lbl = QLabel(f"凭证状态: {valid_text}")
        status_lbl.setStyleSheet(f"color: {valid_color}; font-weight: bold; margin-bottom: 8px; border: none;")
        content_layout.addWidget(status_lbl)
        
        # Token 显示逻辑处理
        raw_access_token = self.account.access_token or ""
        raw_session_token = self.account.session_token or ""
        
        display_jwt = ""
        display_user = ""
        
        # 1. 获取 Session Token (user_...)
        # 优先从 session_token 字段获取
        if raw_session_token.startswith("user_"):
            display_user = raw_session_token
        # 其次尝试从 access_token 字段获取 (如果混用了)
        elif raw_access_token.startswith("user_"):
            display_user = raw_access_token
            
        # 2. 获取 Access Token (ey...)
        # 优先从 access_token 字段获取
        if raw_access_token.startswith("ey"):
            display_jwt = raw_access_token
        # 其次尝试从 session_token 字段获取 (如果混用了)
        elif raw_session_token.startswith("ey"):
            display_jwt = raw_session_token
            
        # 3. 交叉提取兜底
        # 如果 Access Token 还没找到，尝试从 Session Token 中提取 (user_...::ey...)
        if not display_jwt and display_user and "::" in display_user:
            parts = display_user.split("::")
            if len(parts) > 1 and parts[1].startswith("ey"):
                display_jwt = parts[1]

        # 4. 最终正则提取兜底 (针对非常规格式)
        if not display_jwt:
            import re
            # 在两个字段里都找一下
            match = re.search(r'(eyJ[\w-]*\.eyJ[\w-]*\.[\w-]*)', raw_access_token)
            if not match:
                match = re.search(r'(eyJ[\w-]*\.eyJ[\w-]*\.[\w-]*)', raw_session_token)
            
            if match:
                display_jwt = match.group(1)
        
        self.add_token_field(content_layout, "Access Token", display_jwt)
        self.add_token_field(content_layout, "Session Token", display_user)
        # self.add_token_field(content_layout, "Refresh Token", self.account.refresh_token) # 已隐藏
        
        content_layout.addStretch()
        scroll.setWidget(content_widget)
        layout.addWidget(scroll)
        
        # 3. 底部按钮
        btn_bar = QWidget()
        btn_bar.setStyleSheet(f"border-top: 1px solid {CyberTheme.COLOR_BORDER}; border-radius: 0; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px;")
        btn_layout = QHBoxLayout(btn_bar)
        btn_layout.setContentsMargins(20, 12, 20, 12)
        
        btn_layout.addStretch()
        
        ok_btn = QPushButton("确定")
        ok_btn.setFixedSize(100, 32)
        ok_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_PRIMARY};
                color: {CyberTheme.COLOR_BG_PRIMARY};
                font-weight: bold;
                border-radius: 4px;
                border: none;
            }}
            QPushButton:hover {{
                background-color: #33ffb2;
            }}
        """)
        ok_btn.clicked.connect(self.accept)
        btn_layout.addWidget(ok_btn)
        
        layout.addWidget(btn_bar)
        
    def create_grid_layout(self) -> QVBoxLayout:
        layout = QVBoxLayout()
        layout.setSpacing(8)
        return layout
        
    def add_section_title(self, layout, title):
        label = QLabel(title)
        label.setFont(CyberTheme.get_font(13, True))
        label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; margin-bottom: 4px; border: none;")
        layout.addWidget(label)
        
    def add_grid_row(self, layout, label_text, value_text, is_primary=False, color=None, allow_copy=False):
        row = QWidget()
        row.setStyleSheet(f"background-color: {CyberTheme.COLOR_BG_SECONDARY}; border-radius: 4px; border: none;")
        row_layout = QHBoxLayout(row)
        row_layout.setContentsMargins(12, 8, 12, 8)
        
        lbl = QLabel(label_text)
        lbl.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; border: none;")
        
        # 值部分
        text_color = color if color else CyberTheme.COLOR_TEXT_PRIMARY
        
        if allow_copy:
            # 使用可点击标签
            val = ClickableLabel(str(value_text))
            val.setCursor(Qt.CursorShape.PointingHandCursor)
            val.setToolTip("点击复制")
            # 添加下划线效果表示可点击（可选，这里用 hover 颜色变化更自然）
            val.setStyleSheet(f"""
                QLabel {{
                    color: {text_color};
                    font-weight: {'bold' if is_primary else 'normal'};
                    border: none;
                }}
                QLabel:hover {{
                    color: {CyberTheme.COLOR_PRIMARY};
                }}
            """)
            val.clicked.connect(lambda: self.copy_to_clipboard(value_text, label_text))
        else:
            # 普通标签
            val = QLabel(str(value_text))
            val.setStyleSheet(f"color: {text_color}; font-weight: {'bold' if is_primary else 'normal'}; border: none;")
            val.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            
        row_layout.addWidget(lbl)
        row_layout.addStretch()
        row_layout.addWidget(val)
        
        layout.addWidget(row)

    def add_progress_row(self, layout, label_text, value_text, percent, color=None):
        """添加带进度条的行"""
        row = QWidget()
        row.setStyleSheet(f"background-color: {CyberTheme.COLOR_BG_SECONDARY}; border-radius: 4px; border: none;")
        row_layout = QHBoxLayout(row)
        row_layout.setContentsMargins(12, 8, 12, 8)
        
        lbl = QLabel(label_text)
        lbl.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; border: none; min-width: 60px;")
        
        # 进度条
        progress = QProgressBar()
        progress.setFixedHeight(6)
        progress.setTextVisible(False)
        progress.setRange(0, 100)
        progress.setValue(min(100, max(0, int(percent))))
        
        # 样式
        bar_color = color if color else CyberTheme.COLOR_PRIMARY
        progress.setStyleSheet(f"""
            QProgressBar {{
                background-color: {CyberTheme.COLOR_BG_TERTIARY};
                border-radius: 3px;
                border: none;
            }}
            QProgressBar::chunk {{
                background-color: {bar_color};
                border-radius: 3px;
            }}
        """)
        
        val = QLabel(str(value_text))
        val.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_PRIMARY}; font-weight: bold; border: none; min-width: 80px;")
        val.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        
        row_layout.addWidget(lbl)
        row_layout.addWidget(progress, 1) # 1 表示占用剩余空间
        row_layout.addSpacing(10)
        row_layout.addWidget(val)
        
        layout.addWidget(row)

    def add_token_field(self, layout, label_text, token_value):
        container = QWidget()
        container.setStyleSheet(f"background-color: {CyberTheme.COLOR_BG_SECONDARY}; border-radius: 4px; border: none;")
        v_layout = QVBoxLayout(container)
        v_layout.setContentsMargins(12, 8, 12, 8)
        v_layout.setSpacing(4)
        
        header = QHBoxLayout()
        lbl = QLabel(label_text)
        lbl.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; font-size: 11px; border: none;")
        header.addWidget(lbl)
        header.addStretch()
        
        if token_value:
            copy_btn = QPushButton("复制")
            copy_btn.setFixedSize(50, 22) # 稍微加大
            copy_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            # 使用与邮箱界面保存按钮一致的 Primary 风格
            copy_btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: {CyberTheme.COLOR_PRIMARY};
                    color: {CyberTheme.COLOR_BG_PRIMARY};
                    border: none;
                    border-radius: 4px;
                    font-size: 11px;
                    font-weight: bold;
                    padding: 0;
                }}
                QPushButton:hover {{
                    background-color: {CyberTheme.COLOR_PRIMARY_HOVER};
                }}
            """)
            copy_btn.clicked.connect(lambda: self.copy_to_clipboard(token_value, label_text))
            header.addWidget(copy_btn)
            
        v_layout.addLayout(header)
        
        val = QLabel(token_value[:60] + "..." if token_value and len(token_value) > 60 else (token_value or "无"))
        val.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_MUTED}; font-family: Consolas, monospace; font-size: 11px; border: none;")
        val.setWordWrap(True)
        v_layout.addWidget(val)
        
        layout.addWidget(container)
            
    def copy_to_clipboard(self, text, label="内容"):
        clipboard = QApplication.clipboard()
        clipboard.setText(text)
        # 去掉可能的冒号或多余空格，并移除"账户"等后缀让提示更自然
        clean_label = label.replace(":", "").replace("账户", "").strip()
        CyberMessageBox.information(self, "复制成功", f"{clean_label} 已成功复制到剪贴板！")
        
    def get_status_text(self, status):
        if not status: return ""
        s = status.lower()
        if s == 'active': return "活跃"
        if s == 'inactive': return "未激活"
        if s == 'expired': return "已过期"
        if s == 'invalid': return "已失效"
        return status
        
    def format_time(self, iso_time):
        if not iso_time: return "未知"
        try:
            from datetime import datetime, timedelta, timezone
            dt = datetime.fromisoformat(iso_time.replace('Z', '+00:00'))
            
            # 转换为 UTC+8 (北京时间)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            
            beijing_tz = timezone(timedelta(hours=8))
            dt_beijing = dt.astimezone(beijing_tz)
            
            return dt_beijing.strftime("%Y-%m-%d %H:%M:%S")
        except:
            return iso_time

    # --- 窗口拖动逻辑 ---
    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            if event.position().y() < 40: # 标题栏高度
                self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
                event.accept()

    def mouseMoveEvent(self, event: QMouseEvent):
        if event.buttons() == Qt.MouseButton.LeftButton and self._drag_pos:
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def mouseReleaseEvent(self, event: QMouseEvent):
        self._drag_pos = None
