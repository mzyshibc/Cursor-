#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Cursor VIP Unified - 主入口文件
"""

import sys
import os
import ctypes
from pathlib import Path

# 添加项目根目录到Python路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from PyQt6.QtWidgets import QApplication, QMessageBox
from PyQt6.QtGui import QIcon
from PyQt6.QtCore import Qt
from PyQt6.QtNetwork import QLocalServer, QLocalSocket

from ui.main_window import MainWindow
from utils.logger import setup_logger
from utils.config import ConfigManager
from utils.license_validator import LicenseValidator
from utils.logger import get_logger

def exception_hook(exctype, value, traceback_obj):
    """全局异常捕获钩子"""
    import traceback
    from PyQt6.QtWidgets import QMessageBox
    
    # 记录错误到日志
    logger = get_logger("crash_handler")
    error_msg = ''.join(traceback.format_exception(exctype, value, traceback_obj))
    logger.critical(f"Uncaught exception:\n{error_msg}")
    
    # 保存到单独的崩溃日志文件
    try:
        from utils.config import ConfigManager
        log_dir = ConfigManager().get_logs_dir()
        crash_file = log_dir / "crash.log"
        with open(crash_file, "a", encoding="utf-8") as f:
            import datetime
            timestamp = datetime.datetime.now().isoformat()
            f.write(f"\n[{timestamp}] CRASH REPORT:\n{error_msg}\n{'-'*50}\n")
    except:
        pass

    # 忽略键盘中断（Ctrl+C）
    if issubclass(exctype, KeyboardInterrupt):
        sys.__excepthook__(exctype, value, traceback_obj)
        return

    # 弹出错误提示框（如果应用已启动）
    if QApplication.instance():
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Icon.Critical)
        msg.setWindowTitle("程序发生错误")
        msg.setText("抱歉，程序遇到了未捕获的异常。")
        msg.setInformativeText(f"错误类型: {exctype.__name__}\n错误信息: {str(value)}\n\n错误日志已保存。")
        msg.setDetailedText(error_msg)
        msg.exec()
    
    sys.exit(1)


def main():
    """主函数"""
    # 设置全局异常捕获
    sys.excepthook = exception_hook

    # 设置日志
    setup_logger()

    # 设置Windows任务栏图标
    try:
        if os.name == 'nt':  # Windows
            myappid = 'cursor.vip.unified.1.0'
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
    except:
        pass

    # 创建Qt应用
    app = QApplication(sys.argv)

    # 设置应用信息
    app.setApplicationName("Cursor Pro Manager")
    app.setApplicationVersion("1.0.0")
    app.setOrganizationName("CursorVIP")

    # 设置图标
    icon_path = project_root / "src" / "assets" / "icon.ico"
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))

    # 应用全局样式
    from ui.styles import CyberTheme
    CyberTheme.apply_global_style(app)

    # 单实例守护（检测是否已有实例在运行）
    server_name = "cursor_pro_manager"
    socket = QLocalSocket()
    socket.connectToServer(server_name)
    if socket.waitForConnected(100):
        from ui.custom_widgets import CyberMessageBox
        CyberMessageBox.information(
            None,
            "已在运行",
            "CursorProManager 已经在运行中\n\n请在任务栏或托盘中切换到已有窗口。\n如未看到窗口，可能最小化到托盘。"
        )
        sys.exit(0)
    else:
        # 当前作为主实例监听，保持对象存活到退出
        app._single_instance_server = QLocalServer()
        app._single_instance_server.listen(server_name)

    # 3. 检查许可证
    config_manager = ConfigManager()
    license_validator = LicenseValidator(config_manager)
    
    # 在线校验（每次启动时）
    print("正在进行启动时在线校验...")
    is_valid, check_result = license_validator.verify_license_online()
    
    if not is_valid:
        # 如果在线校验失败（过期或无效），尝试弹出激活窗口
        # 注意：这里可能会因为网络原因失败，如果是因为网络失败，我们是否应该允许离线使用？
        # 严格模式：必须在线校验通过。
        # 宽松模式：如果网络失败但本地有效，允许进入。
        
        # 这里采用严格模式，但如果是网络错误，可以提示用户
        error_code = check_result.get('error')
        if error_code in ['network_error', 'http_error']:
             # 网络问题，如果本地有效，暂时允许进入（或者提示重试）
             # 为了安全，我们还是要求激活
             pass
             
        # 如果本地有效但在线校验说无效（被吊销），则必须重新激活
        # 如果本地根本就无效，当然要激活
        
        from ui.auth_dialog import AuthDialog
        auth_dialog = AuthDialog(config_manager=config_manager)
        if auth_dialog.exec():
            # 激活成功，获取最新的许可证数据
            is_valid, license_data = license_validator.check_local_license()
        else:
            sys.exit(0)
    else:
        # 在线校验通过，使用返回的数据（可能包含更新的过期时间）
        # verify_license_online 已经更新了本地文件
        is_valid, license_data = license_validator.check_local_license()

    # 再次确认（双重保障）
    if not is_valid:
        sys.exit(0)

    # 4. 启动主窗口
    window = MainWindow(license_data=license_data, config_manager=config_manager)
    window.show()

    # 运行应用
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
