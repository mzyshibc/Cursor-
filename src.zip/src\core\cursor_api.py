#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Cursor 官方 API 客户端
用于获取账户信息、使用情况、订阅状态等
"""

import json
import time
import urllib.request
import urllib.error
import urllib.parse
from typing import Optional, Dict, Any, List, Tuple
import jwt
from datetime import datetime

from utils.logger import LoggerMixin


class CursorAPIError(Exception):
    """Cursor API 错误"""
    pass


class CursorRateLimitError(CursorAPIError):
    """API 频率限制错误"""
    pass


class CursorAuthError(CursorAPIError):
    """认证错误"""
    pass


class CursorOfficialAPI(LoggerMixin):
    """Cursor 官方 API 客户端"""

    # API 端点
    BASE_URL = "https://api2.cursor.sh"
    AUTH_URL = "https://cursor.com"
    POLL_ENDPOINT = f"{BASE_URL}/auth/poll"

    def __init__(self, timeout: int = 60):
        """
        初始化 API 客户端

        Args:
            timeout: 请求超时时间（秒）
        """
        self.timeout = timeout
        self.session_token = None
        self.last_request_time = 0
        self.min_request_interval = 1.0  # 最小请求间隔（秒）

    def _make_request(self, url: str, method: str = 'GET',
                     headers: Optional[Dict[str, str]] = None,
                     data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        发送HTTP请求

        Args:
            url: 请求URL
            method: 请求方法
            headers: 请求头
            data: 请求数据

        Returns:
            Dict: 响应数据

        Raises:
            CursorAPIError: API 相关错误
        """
        # 限制请求频率
        elapsed = time.time() - self.last_request_time
        if elapsed < self.min_request_interval:
            time.sleep(self.min_request_interval - elapsed)

        self.last_request_time = time.time()

        try:
            # 准备请求
            if headers is None:
                headers = {}

            # 设置默认头部
            default_headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'application/json',
                'Origin': 'https://www.cursor.com',
                'Referer': 'https://www.cursor.com/'
            }
            if method != 'GET':
                 default_headers['Content-Type'] = 'application/json'
            default_headers.update(headers)

            # 准备数据
            request_data = None
            if data:
                request_data = json.dumps(data).encode('utf-8')

            # 创建请求
            req = urllib.request.Request(url, method=method, data=request_data)

            # 设置头部
            for key, value in default_headers.items():
                req.add_header(key, value)

            self.logger.debug(f"{method} {url}")
            # 打印关键 Header 用于调试
            if 'Authorization' in default_headers:
                 self.logger.debug(f"Auth Mode: Bearer")
            elif 'Cookie' in default_headers:
                 self.logger.debug(f"Auth Mode: Cookie")

            # 发送请求
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                response_data = response.read().decode('utf-8')

                # 检查响应状态
                if response.status == 429:
                    raise CursorRateLimitError("API 请求频率过高")
                elif response.status == 401:
                    raise CursorAuthError("认证失败")
                elif response.status >= 400:
                    raise CursorAPIError(f"API 错误: {response.status}")

                # 解析JSON响应
                if response_data:
                    return json.loads(response_data)
                else:
                    # HTTP 204 (No Content) 是成功的响应，表示无内容
                    if response.status == 204:
                        self.logger.info(f"API 响应成功 (204 No Content): {url}")
                        return {}
                    else:
                        self.logger.warning(f"空响应: {url} status={response.status}")
                        return {}

        except urllib.error.HTTPError as e:
            if e.code == 429:
                raise CursorRateLimitError("API 请求频率过高")
            elif e.code == 401:
                raise CursorAuthError("认证失败")
            else:
                raise CursorAPIError(f"HTTP 错误: {e.code}")
        except urllib.error.URLError as e:
            raise CursorAPIError(f"网络错误: {e.reason}")
        except json.JSONDecodeError as e:
            raise CursorAPIError(f"响应解析错误: {e}")
        except Exception as e:
            raise CursorAPIError(f"请求异常: {e}")

    def get_user_info_by_bearer(self, access_token: str) -> Optional[Dict[str, Any]]:
        """
        使用 Bearer 认证获取用户信息

        Args:
            access_token: AccessToken

        Returns:
            Optional[Dict]: 用户信息
        """
        try:
            url = f"{self.AUTH_URL}/api/auth/me"

            headers = {
                'Authorization': f'Bearer {access_token}',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }

            response = self._make_request(url, headers=headers)

            if response is not None:
                self.logger.info("成功获取用户信息")
                return response
            else:
                self.logger.warning("获取用户信息失败：空响应")
                return None

        except CursorAuthError:
            self.logger.warning("认证失败：无效的访问令牌")
            return None
        except Exception as e:
            self.logger.error(f"获取用户信息异常: {e}")
            return None
            
    def get_user_info_by_cookie(self, session_token: str) -> Optional[Dict[str, Any]]:
        """
        使用 Cookie 认证获取用户信息 (SessionToken)

        Args:
            session_token: SessionToken (user_xxx::jwt)

        Returns:
            Optional[Dict]: 用户信息
        """
        try:
            url = f"{self.AUTH_URL}/api/auth/me"
            
            # URL编码SessionToken
            # 只要不是明显包含 %3A%3A 的，我们都尝试编码一下，或者如果包含 :: 也编码
            # 对于纯 user_xxxx，也必须编码，因为其中可能包含 base64 字符
            if '%3A%3A' not in session_token:
                 encoded_token = urllib.parse.quote(session_token, safe='')
            else:
                 encoded_token = session_token

            headers = {
                'Cookie': f'WorkosCursorSessionToken={encoded_token}',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
                'Referer': 'https://www.cursor.com/'
            }

            response = self._make_request(url, headers=headers)

            if response is not None:
                self.logger.info("成功获取用户信息(Cookie)")
                return response
            else:
                self.logger.warning("获取用户信息失败(Cookie)：空响应")
                return None

        except Exception as e:
            self.logger.error(f"获取用户信息(Cookie)异常: {e}")
            return None

    def get_usage_summary(self, token: str) -> Optional[Dict[str, Any]]:
        """
        获取使用情况信息 (智能选择认证方式)

        Args:
            token: AccessToken 或 SessionToken

        Returns:
            Optional[Dict]: 使用情况信息
        """
        try:
            url = f"{self.AUTH_URL}/api/usage-summary" # 使用新的 API

            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            
            if '::' in token or '%3A%3A' in token or token.startswith('user_'):
                 # URL编码SessionToken
                if '%3A%3A' not in token:
                    encoded_token = urllib.parse.quote(token, safe='')
                else:
                    encoded_token = token
                headers['Cookie'] = f'WorkosCursorSessionToken={encoded_token}'
                headers['Referer'] = 'https://www.cursor.com/'
            else:
                headers['Authorization'] = f'Bearer {token}'

            response = self._make_request(url, headers=headers)

            if response:
                self.logger.info("成功获取使用情况")
                return response
            else:
                return None

        except Exception as e:
            self.logger.error(f"获取使用情况异常: {e}")
            return None

    def get_stripe_info(self, token: str) -> Optional[Dict[str, Any]]:
        """
        获取 Stripe 订阅信息 (智能选择认证方式)

        Args:
            token: AccessToken 或 SessionToken

        Returns:
            Optional[Dict]: 订阅信息
        """
        try:
            url = f"{self.AUTH_URL}/api/auth/stripe" # 使用新的 API

            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            
            if '::' in token or '%3A%3A' in token or token.startswith('user_'):
                 # URL编码SessionToken
                if '%3A%3A' not in token:
                    encoded_token = urllib.parse.quote(token, safe='')
                else:
                    encoded_token = token
                headers['Cookie'] = f'WorkosCursorSessionToken={encoded_token}'
                headers['Referer'] = 'https://www.cursor.com/'
            else:
                headers['Authorization'] = f'Bearer {token}'

            response = self._make_request(url, headers=headers)

            if response:
                self.logger.info("成功获取 Stripe 信息")
                return response
            else:
                return None

        except Exception as e:
            self.logger.error(f"获取 Stripe 信息异常: {e}")
            return None

    def get_account_details(self, access_token: str) -> Optional[Dict[str, Any]]:
        """
        获取完整的账户详细信息
        
        Args:
            access_token: AccessToken 或 SessionToken
            
        Returns:
            Optional[Dict]: 账户详细信息
        """
        try:
            # 1. 尝试获取用户信息 (智能路由)
            user_info = None
            try:
                # 检查是否为 SessionToken (user_ 开头 或 包含 ::)
                if access_token.startswith('user_') or '::' in access_token or '%3A%3A' in access_token:
                    user_info = self.get_user_info_by_cookie(access_token)
                else:
                    # [关键修复] 如果是 Session 模式的 AccessToken (纯 JWT)，也应该尝试 Bearer 认证
                    # 之前如果是 session 模式提取出的纯 JWT，这里会走到 Bearer 认证
                    # 但 Bearer 认证可能不支持 Session Token 的 JWT
                    # 所以如果 Bearer 失败，应该尝试把 JWT 包装成 Session Token 再试一次？
                    # 不，Session Token 的 JWT 必须配合 user_id 前缀走 Cookie 认证才行
                    # 但这里我们只有 access_token (可能是纯 JWT)
                    
                    # 尝试 Bearer
                    user_info = self.get_user_info_by_bearer(access_token)
                    
                    # 如果 Bearer 失败，且 Token 看起来像 Session Token 的 JWT (有 sub 且不含 @)
                    if not user_info:
                        try:
                            # 尝试解码看看是不是 Session Token 的 JWT
                            payload = jwt.decode(access_token, options={"verify_signature": False})
                            if payload.get('type') == 'session' or (payload.get('sub') and '|' in payload.get('sub')):
                                # 这是一个 Session Token 的 JWT，必须包装成 user_xxx::jwt 格式走 Cookie 认证
                                # 尝试从 sub 中提取 user_id
                                sub = payload.get('sub', '')
                                user_id = sub.split('|')[-1] if '|' in sub else sub
                                if user_id:
                                    # 避免双重 user_ 前缀
                                    user_id_part = user_id
                                    if not user_id_part.startswith('user_'):
                                        user_id_part = f"user_{user_id_part}"
                                    temp_session_token = f"{user_id_part}::{access_token}"
                                    self.logger.info("尝试将 JWT 包装为 Session Token 进行认证")
                                    user_info = self.get_user_info_by_cookie(temp_session_token)
                        except:
                            pass

            except Exception as e:
                self.logger.warning(f"API 获取用户信息失败: {e}")

            # 如果 API 失败或者返回空信息，尝试本地解析
            if not user_info or not user_info.get('email'):
                # [关键修改] 对于 API 返回 204 No Content 的情况，我们应该视为“成功但无数据”
                # 而不是“失败”。
                # 用户坚持认为 API 应该返回数据，这说明在某些情况下（比如正确的 Session Token）API 确实会返回。
                # 既然现在的 Token 是用户确认过的“正确”Token，如果 API 还是返回 204，
                # 那可能真的是 auth/me 接口本身对该 Token 没有返回详细信息（比如该账号尚未设置 profile）。
                
                # 为了不让用户困惑，我们将日志级别调整为 debug，并明确指出回退原因
                if not user_info:
                    self.logger.debug("API 返回了 204 No Content 或空数据，尝试从 Token 中解析基本信息")
                
                email = self.extract_email_from_token(access_token)
                if email:
                    self.logger.info(f"API 获取失败或无邮箱信息，回退到本地解析邮箱: {email}")
                    # 尝试从 Token 中提取 UserID (sub)
                    user_id = None
                    try:
                        jwt_token = access_token
                        if "::" in access_token:
                            parts = access_token.split("::")
                            if len(parts) > 1:
                                jwt_token = parts[1]
                        payload = jwt.decode(jwt_token, options={"verify_signature": False})
                        user_id = payload.get('sub', '').replace('auth0|', '')
                    except:
                        pass

                    # 如果user_info为空，构造基础信息；如果不为空但没有email，补充email
                    if not user_info:
                        user_info = {'email': email, 'id': user_id}
                    else:
                        user_info['email'] = email
                        if user_id and not user_info.get('id'):
                            user_info['id'] = user_id
            
            if not user_info:
                return None


            # [关键修复] usage-summary 和 stripe 接口同样需要正确的 Session Token 格式
            # 如果 user_info 是通过 Cookie 认证获取的，说明 access_token 需要包装
            current_token_for_api = access_token
            
            # 1. 如果 user_info 里有 id，优先使用它来构造标准 Session Token
            if user_info and user_info.get('id'):
                try:
                    user_id = user_info.get('id')
                    # 只有当 current_token_for_api 还不是标准 Session Token 时才包装
                    # [修复] 增加对 URL 编码格式 (%3A%3A) 的兼容，防止双重包装
                    if not current_token_for_api.startswith('user_') or ('::' not in current_token_for_api and '%3A%3A' not in current_token_for_api):
                         # 避免双重 user_ 前缀
                         uid_str = str(user_id)
                         if not uid_str.startswith('user_'):
                             uid_str = f"user_{uid_str}"
                         current_token_for_api = f"{uid_str}::{access_token}"
                         self.logger.info(f"已构造标准 Session Token 用于后续调用: {uid_str}::...")
                except:
                    pass
            

            # 获取使用情况
            try:
                usage_info = self.get_usage_summary(current_token_for_api)
            except:
                usage_info = None
                
            # 获取 Stripe 信息
            try:
                subscription_info = self.get_stripe_info(current_token_for_api)
            except:
                subscription_info = None
            
            # ⭐ 尝试使用 get_usage_events 获取详细费用（即使 usage_summary 失败）
            usage_events = None
            total_cost_info = None
            
            # 如果有 user_id，尝试构造 Session Token 来获取详细费用
            # 这里的逻辑参考了自动注册模块
            if user_info and user_info.get('id'):
                try:
                    # 直接使用已经处理好的 current_token_for_api
                    usage_events = self.get_usage_events(current_token_for_api)
                    if usage_events:
                        # 假设默认为 free，稍后如果拿到 subscription_info 再修正
                        plan = 'free'
                        if usage_info:
                            plan = usage_info.get('membershipType', 'free')
                        elif subscription_info:
                            plan = subscription_info.get('membershipType', 'free')
                            
                        total_cost_info = self.calculate_total_cost(usage_events, plan)
                        self.logger.info(f"成功通过 get_usage_events 获取费用信息: ${total_cost_info['total_cost']}")
                except Exception as e:
                    self.logger.warning(f"获取详细费用信息失败: {e}")

            # 3. 规范化返回数据结构，适配前端 UI
            
            final_usage_info = {}
            if usage_info:
                final_usage_info = {
                    'plan': usage_info.get('membershipType', 'free'),
                    'gpt4_requests_left': 0,
                    'gpt35_requests_left': 0
                }
            elif total_cost_info: # 如果 usage_summary 失败但 events 成功，用 events 填充
                 final_usage_info = {
                    'plan': 'free', # 无法确定，默认 free
                    'gpt4_requests_left': 0,
                    'gpt35_requests_left': 0
                }
                
            final_sub_info = {}
            if subscription_info:
                final_sub_info = {
                    'plan': subscription_info.get('membershipType', 'free'),
                    'status': subscription_info.get('subscriptionStatus', 'active')
                }

            # 合并信息
            account_details = {
                'user_info': user_info,
                'usage_info': final_usage_info,
                'subscription_info': final_sub_info,
                'last_updated': datetime.now().isoformat()
            }
            
            # 如果获取到了详细费用信息，添加到返回结果中（可能需要前端适配显示）
            if total_cost_info:
                account_details['total_cost'] = total_cost_info['total_cost']
                account_details['unpaid_amount'] = total_cost_info['unpaid_amount']
                account_details['total_tokens'] = total_cost_info['total_tokens']
                account_details['by_model'] = total_cost_info['by_model']
            
            # 如果能从新 API 拿到更准确的 plan，覆盖它
            if usage_info and 'membershipType' in usage_info:
                 account_details['subscription_info']['plan'] = usage_info['membershipType']

            self.logger.info("成功获取账户详细信息")
            return account_details

        except Exception as e:
            self.logger.error(f"获取账户详细信息异常: {e}")
            return None

    def validate_token(self, access_token: str) -> Tuple[bool, Optional[Dict[str, Any]]]:
        """
        验证Token有效性

        Args:
            access_token: AccessToken

        Returns:
            Tuple[bool, Optional[Dict]]: (是否有效, Token信息)
        """
        try:
            # 解析JWT Token
            # 注意：如果是 user_xxx::jwt 格式，需要提取 jwt 部分
            jwt_token = access_token
            if "::" in access_token:
                parts = access_token.split("::")
                if len(parts) > 1:
                    jwt_token = parts[1]
            
            payload = jwt.decode(jwt_token, options={"verify_signature": False})

            # 检查过期时间
            exp = payload.get('exp')
            if exp:
                now = datetime.now().timestamp()
                is_valid = now < exp

                token_info = {
                    'type': payload.get('type', 'unknown'),
                    'user_id': payload.get('sub'),
                    'expires_at': datetime.fromtimestamp(exp).isoformat(),
                    'issued_at': datetime.fromtimestamp(payload.get('iat', 0)).isoformat(),
                    'is_valid': is_valid,
                    'time_remaining': exp - now if is_valid else 0
                }

                return is_valid, token_info
            else:
                return False, None

        except jwt.ExpiredSignatureError:
            return False, {'error': 'token_expired'}
        except jwt.InvalidTokenError:
            return False, {'error': 'invalid_token'}
        except Exception as e:
            self.logger.error(f"Token验证异常: {e}")
            return False, {'error': str(e)}

    def extract_email_from_token(self, token: str) -> Optional[str]:
        """
        从 Token 中提取邮箱 (本地解析，不调 API)
        
        Args:
            token: SessionToken 或 AccessToken
            
        Returns:
            Optional[str]: 邮箱地址
        """
        try:
            import urllib.parse
            import re
            
            # 1. 尝试 URL 解码
            decoded_token = urllib.parse.unquote(token)
            
            jwt_token = decoded_token
            
            # 2. 尝试提取 JWT 部分
            # 匹配 eyJ 开头的 JWT
            # 兼容 user_xxx::eyJ... 和 user_xxx%3A%3AeyJ... (已解码)
            if "::" in decoded_token:
                parts = decoded_token.split("::")
                if len(parts) > 1:
                    jwt_token = parts[1]
            elif decoded_token.startswith('user_'):
                # 尝试去掉 user_xxx 前缀，寻找 eyJ
                match = re.search(r'(eyJ[\w-]*\.eyJ[\w-]*\.[\w-]*)', decoded_token)
                if match:
                    jwt_token = match.group(1)
            
            # 3. 尝试解码 JWT
            self.logger.debug(f"尝试本地解析 JWT (前20字符): {jwt_token[:20]}...")
            try:
                payload = jwt.decode(jwt_token, options={"verify_signature": False})
            except Exception as e:
                self.logger.error(f"JWT 解码失败: {e}")
                return None
            
            # 4. 尝试获取邮箱
            email = payload.get('email') or payload.get('sub')
            
            # 简单验证邮箱格式
            if email and '@' in str(email):
                self.logger.info(f"本地解析 Token 成功，提取邮箱: {email}")
                return str(email)
            else:
                self.logger.warning(f"JWT 解码成功但未找到有效邮箱。Payload keys: {list(payload.keys())}")
            
            return None
            
        except Exception as e:
            self.logger.error(f"本地解析 Token 发生未捕获异常: {e}")
            return None

    def refresh_token(self, refresh_token: str) -> Optional[Dict[str, str]]:
        """
        刷新访问令牌

        Args:
            refresh_token: 刷新令牌

        Returns:
            Optional[Dict]: 新的令牌信息
        """
        try:
            url = f"{self.AUTH_URL}/api/auth/refresh"

            data = {
                'refresh_token': refresh_token,
                'grant_type': 'refresh_token'
            }

            response = self._make_request(url, method='POST', data=data)

            if response and 'access_token' in response:
                self.logger.info("成功刷新访问令牌")
                return {
                    'access_token': response.get('access_token'),
                    'refresh_token': response.get('refresh_token', refresh_token),
                    'expires_in': response.get('expires_in', 3600)
                }
            else:
                self.logger.warning("刷新令牌失败")
                return None

        except Exception as e:
            self.logger.error(f"刷新令牌异常: {e}")
            return None

    def get_available_models(self, access_token: str) -> List[Dict[str, Any]]:
        """
        获取可用的AI模型

        Args:
            access_token: AccessToken

        Returns:
            List[Dict]: 模型列表
        """
        try:
            url = f"{self.BASE_URL}/models"

            headers = {
                'Authorization': f'Bearer {access_token}'
            }

            response = self._make_request(url, headers=headers)

            if response and isinstance(response, list):
                return response
            elif response and 'models' in response:
                return response['models']
            else:
                return []

        except Exception as e:
            self.logger.error(f"获取模型列表异常: {e}")
            return []

    def get_credits_info(self, access_token: str) -> Optional[Dict[str, Any]]:
        """
        获取积分/credits信息

        Args:
            access_token: AccessToken

        Returns:
            Optional[Dict]: 积分信息
        """
        try:
            url = f"{self.AUTH_URL}/api/credits"

            headers = {
                'Authorization': f'Bearer {access_token}'
            }

            response = self._make_request(url, headers=headers)

            if response:
                self.logger.info("成功获取积分信息")
                return response
            else:
                return None

        except Exception as e:
            self.logger.error(f"获取积分信息异常: {e}")
            return None

    def check_feature_access(self, access_token: str, feature: str) -> bool:
        """
        检查功能访问权限

        Args:
            access_token: AccessToken
            feature: 功能名称

        Returns:
            bool: 是否有权限
        """
        try:
            # 这里的 user_info 获取也需要支持 SessionToken
            if '::' in access_token or '%3A%3A' in access_token or access_token.startswith('user_'):
                user_info = self.get_user_info_by_cookie(access_token)
            else:
                user_info = self.get_user_info_by_bearer(access_token)
                
            if not user_info:
                return False

            subscription = user_info.get('subscription', {})
            plan = subscription.get('plan', 'free')

            # 根据订阅计划检查功能权限
            feature_permissions = {
                'gpt-4': ['pro', 'pro_plus', 'enterprise'],
                'claude-3': ['pro', 'pro_plus', 'enterprise'],
                'unlimited_requests': ['pro_plus', 'enterprise'],
                'priority_support': ['pro_plus', 'enterprise']
            }

            allowed_plans = feature_permissions.get(feature, ['free'])
            return plan in allowed_plans

        except Exception as e:
            self.logger.error(f"检查功能权限异常: {e}")
            return False

    def get_usage_events(self, token: str, start_date: str = None, end_date: str = None, get_all_pages: bool = True) -> Optional[Dict[str, Any]]:
        """
        获取详细的使用记录和费用信息（支持多页获取）
        
        API: POST https://cursor.com/api/dashboard/get-filtered-usage-events
        
        Args:
            token: SessionToken (user_xxx::eyJ...)
            start_date: 开始日期（时间戳毫秒）
            end_date: 结束日期（时间戳毫秒）
            get_all_pages: 是否获取所有页（默认True）
            
        Returns:
            Optional[Dict]: 使用记录，包含每次调用的实际费用
        """
        try:
            from datetime import datetime, timedelta
            import urllib.parse
            
            # ⭐ 默认查询当月数据（从每月1号到现在）
            if not end_date:
                end_timestamp = int(datetime.now().timestamp() * 1000)
            else:
                end_timestamp = int(end_date)
            
            if not start_date:
                # 获取本月1号0点的时间戳
                now = datetime.now()
                start_dt = datetime(now.year, now.month, 1, 0, 0, 0)
                start_timestamp = int(start_dt.timestamp() * 1000)
            else:
                start_timestamp = int(start_date)
            
            # URL编码SessionToken
            if '::' in token and '%3A%3A' not in token:
                encoded_token = urllib.parse.quote(token, safe='')
            else:
                encoded_token = token
            
            url = f"{self.AUTH_URL}/api/dashboard/get-filtered-usage-events"
            
            # ⭐ 获取所有页的数据
            all_events = []
            page = 1
            page_size = 100
            total_count = 0
            
            while True:
                # 构造POST数据
                post_data = {
                    "teamId": 0,
                    "startDate": str(start_timestamp),
                    "endDate": str(end_timestamp),
                    "page": page,
                    "pageSize": page_size
                }
                
                # 构造请求
                req = urllib.request.Request(url, method='POST')
                req.add_header('Cookie', f'WorkosCursorSessionToken={encoded_token}')
                req.add_header('Content-Type', 'application/json')
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
                req.add_header('Accept', '*/*')
                req.add_header('Referer', 'https://cursor.com/cn/dashboard?tab=usage')
                req.add_header('Origin', 'https://cursor.com')
                
                # 发送请求
                post_bytes = json.dumps(post_data).encode('utf-8')
                
                self.logger.debug(f"POST {url} (Page {page})")
                
                with urllib.request.urlopen(req, data=post_bytes, timeout=self.timeout) as response:
                    if response.status == 200:
                        data = json.loads(response.read().decode('utf-8'))
                        total_count = data.get('totalUsageEventsCount', 0)
                        current_events = data.get('usageEventsDisplay', [])
                        
                        all_events.extend(current_events)
                        
                        self.logger.debug(f"✓ 第{page}页: {len(current_events)}条记录")
                        
                        # 如果不获取所有页，或者已经获取完所有数据
                        if not get_all_pages or len(current_events) < page_size or len(all_events) >= total_count:
                            break
                        
                        page += 1
                    else:
                        break
            
            self.logger.info(f"✓ 获取使用记录成功，共 {total_count} 条（已获取{len(all_events)}条）")
            
            return {
                'totalUsageEventsCount': total_count,
                'usageEventsDisplay': all_events
            }
                
        except Exception as e:
            self.logger.debug(f"获取使用记录失败: {e}")
            return None

    def calculate_total_cost(self, usage_events: Dict[str, Any], membership_type: str = 'free') -> Dict[str, Any]:
        """
        计算总费用和欠费金额
        
        Args:
            usage_events: get_usage_events返回的数据
            membership_type: 套餐类型（用于计算抵扣）
            
        Returns:
            Dict: 费用统计
                - total_cost: 总费用（美元）
                - total_tokens: 总tokens
                - event_count: 事件数量
                - by_model: 按模型分组的费用
                - unpaid_amount: 实际欠费金额 ⭐
        """
        if not usage_events or 'usageEventsDisplay' not in usage_events:
            return {'total_cost': 0, 'total_tokens': 0, 'event_count': 0, 'by_model': {}, 'unpaid_amount': 0}
        
        events = usage_events['usageEventsDisplay']
        total_cost = 0
        total_tokens = 0
        by_model = {}
        charged_count = 0
        
        for event in events:
            # ⭐ 跳过错误和不计费的事件
            kind = event.get('kind', '')
            if 'NOT_CHARGED' in kind or 'ERRORED' in kind:
                continue
            
            # ⭐ 使用 totalCents（美分转美元）- 这是最准确的
            token_usage = event.get('tokenUsage', {})
            event_cost = token_usage.get('totalCents', 0) / 100
            
            total_cost += event_cost
            charged_count += 1
            
            # 计算tokens
            token_usage = event.get('tokenUsage', {})
            event_tokens = (
                token_usage.get('inputTokens', 0) +
                token_usage.get('outputTokens', 0) +
                token_usage.get('cacheWriteTokens', 0) +
                token_usage.get('cacheReadTokens', 0)
            )
            total_tokens += event_tokens
            
            # 按模型分组
            model = event.get('model', 'unknown')
            if model not in by_model:
                by_model[model] = {'cost': 0, 'tokens': 0, 'count': 0}
            
            by_model[model]['cost'] += event_cost
            by_model[model]['tokens'] += event_tokens
            by_model[model]['count'] += 1
        
        # ⭐ 计算实际欠费金额（总费用 - 套餐抵扣）
        PLAN_CREDIT = {
            'pro': 20,
            'pro_trial': 20,
            'business': 40,
            'team': 40,
            'enterprise': 100,
            'free': 10,          # ⭐ FREE套餐有$10抵扣
            'free_trial': 10     # ⭐ FREE试用也是$10
        }
        
        plan_credit = PLAN_CREDIT.get(membership_type.lower(), 0)
        unpaid_amount = max(0, total_cost - plan_credit)
        
        return {
            'total_cost': round(total_cost, 2),
            'total_tokens': total_tokens,
            'event_count': len(events),
            'charged_count': charged_count,  # 实际计费的事件数
            'by_model': by_model,
            'unpaid_amount': round(unpaid_amount, 2)  # ⭐ 实际欠费
        }


# 全局实例
_api_client_instance = None

def get_api_client(timeout: int = 60) -> CursorOfficialAPI:
    """
    获取 API 客户端单例
    
    Args:
        timeout: 超时时间
        
    Returns:
        CursorOfficialAPI: API 客户端实例
    """
    global _api_client_instance
    if _api_client_instance is None:
        _api_client_instance = CursorOfficialAPI(timeout=timeout)
    return _api_client_instance
