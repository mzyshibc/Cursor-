#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
设置页面
包含重置机器码、备份配置、恢复配置功能
"""

import os
import shutil
import zipfile
import datetime
import time
from pathlib import Path
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
    QGroupBox, QFileDialog, QProgressBar, QCheckBox
)
from PyQt6.QtCore import QThread, pyqtSignal

from ui.styles import CyberTheme
from ui.custom_widgets import CyberMessageBox
from core.drission_modules.cursor_switcher import get_switcher
from utils.app_paths import resource_path

class BackupWorker(QThread):
    """备份任务线程"""
    progress = pyqtSignal(int, str)
    finished = pyqtSignal(bool, str)

    def __init__(self, save_path: str):
        super().__init__()
        self.save_path = save_path
        self.switcher = get_switcher()

    def run(self):
        try:
            zip_path = Path(self.save_path)
            
            # 获取目录路径
            cursor_dir = self.switcher.cursor_dir  # %APPDATA%/Cursor
            user_dir = cursor_dir / 'User'
            
            # 扩展目录通常在用户目录下
            home = Path.home()
            extensions_dir = home / '.cursor' / 'extensions'
            
            self.progress.emit(10, "正在扫描文件...")
            
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                # 1. 备份 User 目录 (排除一些大文件或缓存)
                if user_dir.exists():
                    self.progress.emit(20, "正在备份用户配置...")
                    for root, dirs, files in os.walk(user_dir):
                        # 排除 globalStorage 下的大文件，但保留 storage.json 和 state.vscdb
                        if 'globalStorage' in root:
                             # 简单策略：只备份关键的 json 和 db
                             pass
                        
                        for file in files:
                            file_path = Path(root) / file
                            # 计算相对路径
                            arcname = f"User/{file_path.relative_to(user_dir)}"
                            
                            # 过滤缓存文件
                            if 'Cache' in str(file_path) or 'Cached' in str(file_path):
                                continue
                            if file.endswith('.log') or file.endswith('.lock'):
                                continue
                                
                            zf.write(file_path, arcname)

                # 2. 备份扩展目录
                if extensions_dir.exists():
                    self.progress.emit(50, "正在备份扩展插件 (可能需要较长时间)...")
                    # 统计文件总数用于进度条（略，简化处理）
                    for root, dirs, files in os.walk(extensions_dir):
                        for file in files:
                            file_path = Path(root) / file
                            arcname = f"Extensions/{file_path.relative_to(extensions_dir)}"
                            zf.write(file_path, arcname)
            
            self.progress.emit(100, "备份完成")
            self.finished.emit(True, f"备份已保存至: {zip_path}")
            
        except Exception as e:
            self.finished.emit(False, str(e))


class RestoreWorker(QThread):
    """恢复任务线程"""
    progress = pyqtSignal(int, str)
    finished = pyqtSignal(bool, str)

    def __init__(self, backup_path: str):
        super().__init__()
        self.backup_path = backup_path
        self.switcher = get_switcher()

    def run(self):
        try:
            zip_path = Path(self.backup_path)
            if not zip_path.exists():
                raise FileNotFoundError("备份文件不存在")

            # 1. 强制关闭 Cursor
            self.progress.emit(10, "正在关闭 Cursor 进程...")
            if not self.switcher.close_cursor_gracefully():
                self.progress.emit(15, "无法完全关闭 Cursor，尝试强制清理...")
                self.switcher.kill_cursor_force()
            
            time.sleep(1)

            # 2. 准备目录
            cursor_dir = self.switcher.cursor_dir
            user_dir = cursor_dir / 'User'
            home = Path.home()
            extensions_dir = home / '.cursor' / 'extensions'

            self.progress.emit(30, "正在清理旧配置...")
            
            # 这里的清理策略要小心，不要把整个 User 删了，可能影响其他东西
            # 但为了恢复干净，通常建议清理关键目录
            # 我们只清理备份中包含的目录
            
            # 读取 ZIP 查看包含什么
            with zipfile.ZipFile(zip_path, 'r') as zf:
                file_list = zf.namelist()
                has_user = any(f.startswith('User/') for f in file_list)
                has_ext = any(f.startswith('Extensions/') for f in file_list)
                
                if has_user and user_dir.exists():
                    # 备份 storage.json 里的机器码？不需要，恢复后就是备份时的机器码
                    # 如果用户想保留机器码，这会是个问题。但通常恢复就是为了回到那个状态。
                    pass
                
                if has_ext and extensions_dir.exists():
                    # 扩展目录可以清空，防止版本冲突
                    try:
                        shutil.rmtree(extensions_dir)
                    except:
                        pass
                    extensions_dir.mkdir(parents=True, exist_ok=True)

                self.progress.emit(50, "正在解压文件...")
                
                total_files = len(file_list)
                for idx, file in enumerate(file_list):
                    if idx % 50 == 0:
                        percent = 50 + int((idx / total_files) * 40)
                        self.progress.emit(percent, f"正在恢复: {file}")
                    
                    if file.startswith('User/'):
                        # 提取到 User 目录
                        target_path = user_dir / file[5:] # 去掉 User/ 前缀
                        target_path.parent.mkdir(parents=True, exist_ok=True)
                        with zf.open(file) as source, open(target_path, "wb") as target:
                            shutil.copyfileobj(source, target)
                            
                    elif file.startswith('Extensions/'):
                        # 提取到 Extensions 目录
                        target_path = extensions_dir / file[11:] # 去掉 Extensions/ 前缀
                        target_path.parent.mkdir(parents=True, exist_ok=True)
                        with zf.open(file) as source, open(target_path, "wb") as target:
                            shutil.copyfileobj(source, target)

            self.progress.emit(100, "恢复完成")
            self.finished.emit(True, "配置已成功恢复，请重启 Cursor")

        except Exception as e:
            self.finished.emit(False, str(e))


from utils.version_checker import VersionChecker
from PyQt6.QtGui import QDesktopServices
from PyQt6.QtCore import QUrl

class SettingsWidget(QWidget):
    """设置页面组件"""
    
    def __init__(self, config_manager=None):
        super().__init__()
        self.config_manager = config_manager
        self.switcher = get_switcher()
        self.init_ui()
        
    def init_ui(self):
        """初始化 UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)
        
        # 0. 网络设置卡片
        self.init_network_card(layout)

        # 1. 机器码管理卡片
        self.init_machine_id_card(layout)
        
        # 2. 备份恢复卡片
        self.init_backup_restore_card(layout)

        layout.addStretch()

    def init_network_card(self, parent_layout):
        """网络设置区域"""
        group = QGroupBox("网络设置")
        group.setStyleSheet(f"""
            QGroupBox {{
                font-weight: bold;
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 15px;
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                background-color: {CyberTheme.COLOR_BG_CARD};
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                subcontrol-position: top left;
                left: 15px;
                padding: 0 5px;
                color: {CyberTheme.COLOR_PRIMARY};
            }}
        """)
        
        layout = QVBoxLayout(group)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # 绕过代理开关
        self.bypass_proxy_cb = QCheckBox("授权认证时绕过系统代理 (直连)")
        self.bypass_proxy_cb.setChecked(self.config_manager.get_auth_config().bypass_proxy)
        
        # 获取 check.svg 的绝对路径
        check_icon_path = resource_path("src/assets/check.svg").as_posix()
        
        self.bypass_proxy_cb.setStyleSheet(f"""
            QCheckBox {{
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                spacing: 8px;
            }}
            QCheckBox::indicator {{
                width: 18px;
                height: 18px;
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
            }}
            QCheckBox::indicator:checked {{
                background-color: {CyberTheme.COLOR_PRIMARY};
                border-color: {CyberTheme.COLOR_PRIMARY};
                image: url({check_icon_path});
            }}
            QCheckBox::indicator:hover {{
                border-color: {CyberTheme.COLOR_PRIMARY};
            }}
        """)
        self.bypass_proxy_cb.stateChanged.connect(self.on_bypass_proxy_changed)
        
        desc_label = QLabel("开启此选项后，软件在验证授权时将强制忽略系统代理设置，直接连接服务器。这通常能解决因代理节点问题导致的授权失败。")
        desc_label.setWordWrap(True)
        desc_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY}; font-size: 12px; margin-top: 4px;")
        
        layout.addWidget(self.bypass_proxy_cb)
        layout.addWidget(desc_label)
        
        parent_layout.addWidget(group)

    def on_bypass_proxy_changed(self, state):
        """绕过代理设置改变"""
        is_checked = (state == 2) # Qt.CheckState.Checked
        config = self.config_manager.get_auth_config()
        config.bypass_proxy = is_checked
        self.config_manager.set_auth_config(config)

    def init_machine_id_card(self, parent_layout):
        """机器码管理区域"""
        group = QGroupBox("机器码管理")
        group.setStyleSheet(f"""
            QGroupBox {{
                font-weight: bold;
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 15px;
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                background-color: {CyberTheme.COLOR_BG_CARD};
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                subcontrol-position: top left;
                left: 15px;
                padding: 0 5px;
                color: {CyberTheme.COLOR_PRIMARY};
            }}
        """)
        
        layout = QVBoxLayout(group)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # 说明文本
        info_label = QLabel(
            "重置机器码可以生成新的设备指纹，用于解决设备被封禁或限制的问题。\n"
            "注意：重置前请确保 Cursor 已关闭，重置后 Cursor 会被识别为新设备。"
        )
        info_label.setWordWrap(True)
        info_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY};")
        layout.addWidget(info_label)
        
        # 按钮栏
        btn_layout = QHBoxLayout()
        
        self.reset_btn = QPushButton("重置机器码")
        self.reset_btn.setFixedSize(140, 36)
        self.reset_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_PRIMARY};
                color: white;
                border: none;
                border-radius: 4px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: {CyberTheme.COLOR_PRIMARY_HOVER};
            }}
            QPushButton:pressed {{
                background-color: {CyberTheme.COLOR_PRIMARY_PRESSED};
            }}
        """)
        self.reset_btn.clicked.connect(self.on_reset_machine_id)
        
        btn_layout.addWidget(self.reset_btn)
        btn_layout.addStretch()
        
        layout.addLayout(btn_layout)
        parent_layout.addWidget(group)

    def init_backup_restore_card(self, parent_layout):
        """备份恢复区域"""
        group = QGroupBox("配置备份与恢复")
        group.setStyleSheet(f"""
            QGroupBox {{
                font-weight: bold;
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 15px;
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                background-color: {CyberTheme.COLOR_BG_CARD};
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                subcontrol-position: top left;
                left: 15px;
                padding: 0 5px;
                color: {CyberTheme.COLOR_ACCENT};
            }}
        """)
        
        layout = QVBoxLayout(group)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # 说明文本
        info_label = QLabel(
            "备份内容包括：用户设置 (settings.json)、快捷键、代码片段以及已安装的扩展插件。\n"
            "您可以将配置备份为 ZIP 文件，并在需要时一键恢复。"
        )
        info_label.setWordWrap(True)
        info_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_SECONDARY};")
        layout.addWidget(info_label)
        
        # 按钮栏
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(15)
        
        # 备份按钮
        self.backup_btn = QPushButton("备份当前配置")
        self.backup_btn.setFixedSize(140, 36)
        self.backup_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
            }}
            QPushButton:hover {{
                border-color: {CyberTheme.COLOR_ACCENT};
                color: {CyberTheme.COLOR_ACCENT};
            }}
        """)
        self.backup_btn.clicked.connect(self.on_backup_config)
        
        # 恢复按钮
        self.restore_btn = QPushButton("恢复配置")
        self.restore_btn.setFixedSize(140, 36)
        self.restore_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                color: {CyberTheme.COLOR_TEXT_PRIMARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 4px;
            }}
            QPushButton:hover {{
                border-color: {CyberTheme.COLOR_WARNING};
                color: {CyberTheme.COLOR_WARNING};
            }}
        """)
        self.restore_btn.clicked.connect(self.on_restore_config)
        
        btn_layout.addWidget(self.backup_btn)
        btn_layout.addWidget(self.restore_btn)
        btn_layout.addStretch()
        
        layout.addLayout(btn_layout)
        
        # 进度条 (默认隐藏)
        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(4)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setStyleSheet(f"""
            QProgressBar {{
                border: none;
                background-color: {CyberTheme.COLOR_BG_TERTIARY};
                border-radius: 2px;
            }}
            QProgressBar::chunk {{
                background-color: {CyberTheme.COLOR_ACCENT};
                border-radius: 2px;
            }}
        """)
        self.progress_bar.hide()
        layout.addWidget(self.progress_bar)
        
        # 状态文本
        self.status_label = QLabel("")
        self.status_label.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_MUTED}; font-size: 12px;")
        self.status_label.hide()
        layout.addWidget(self.status_label)
        
        parent_layout.addWidget(group)

    def on_reset_machine_id(self, checked=False):
        """重置机器码点击"""
        # 1. 确认提示
        result = CyberMessageBox.question(
            self, 
            "确认重置", 
            "确定要重置机器码吗？\n\n此操作将生成新的设备指纹，Cursor 将被重启以识别为新设备。\n请确保已保存所有工作。"
        )
        
        if result != 16384: # QMessageBox.Yes
            return
            
        # 2. 执行重置
        try:
            # 尝试关闭 Cursor
            self.switcher.close_cursor_gracefully()
            
            # 重置 ID
            self.switcher.reset_machine_ids()
            
            # 自动重启 Cursor
            self.switcher.start_cursor()
            
            CyberMessageBox.information(self, "成功", "机器码已成功重置！\n\nCursor 正在重启...")
            
        except Exception as e:
            CyberMessageBox.critical(self, "错误", f"重置失败: {str(e)}")

    def on_backup_config(self, checked=False):
        """备份配置点击"""
        # 选择保存路径
        default_name = f"cursor_backup_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "保存备份文件",
            str(Path.home() / "Desktop" / default_name),
            "ZIP 文件 (*.zip)"
        )
        
        if not file_path:
            return
            
        self.start_worker(BackupWorker(file_path))

    def on_restore_config(self, checked=False):
        """恢复配置点击"""
        # 选择备份文件
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "选择备份文件",
            str(Path.home() / "Desktop"),
            "ZIP 文件 (*.zip)"
        )
        
        if not file_path:
            return
            
        # 确认提示
        result = CyberMessageBox.question(
            self,
            "确认恢复",
            "恢复操作将覆盖现有的配置和扩展插件。\n\nCursor 将被强制关闭以确保写入成功。\n确定要继续吗？"
        )
        
        if result != 16384: # QMessageBox.Yes
            return
            
        self.start_worker(RestoreWorker(file_path))

    def start_worker(self, worker):
        """启动工作线程"""
        self.worker = worker # 保持引用防止被回收
        
        self.backup_btn.setEnabled(False)
        self.restore_btn.setEnabled(False)
        self.progress_bar.setValue(0)
        self.progress_bar.show()
        self.status_label.setText("准备中...")
        self.status_label.show()
        
        self.worker.progress.connect(self.update_progress)
        self.worker.finished.connect(self.task_finished)
        self.worker.start()
        
    def update_progress(self, value, text):
        """更新进度"""
        self.progress_bar.setValue(value)
        self.status_label.setText(text)
        
    def task_finished(self, success, message):
        """任务完成"""
        self.backup_btn.setEnabled(True)
        self.restore_btn.setEnabled(True)
        self.progress_bar.hide()
        
        if success:
            self.status_label.setText("操作成功")
            CyberMessageBox.information(self, "成功", message)
        else:
            self.status_label.setText("操作失败")
            CyberMessageBox.critical(self, "错误", f"操作失败: {message}")
