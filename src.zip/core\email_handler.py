#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
邮箱处理系统
支持TempMail和IMAP两种邮箱模式
"""

import time
import imaplib
import email
import email.header
import re
import random
import string
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
from email import utils as email_utils

import requests

try:
    from src.utils.logger import LoggerMixin
    from src.utils.config import EmailConfig
except ImportError:
    # 兼容直接运行脚本的情况
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from src.utils.logger import LoggerMixin
    from src.utils.config import EmailConfig


@dataclass
class EmailMessage:
    """邮件消息"""
    subject: str
    sender: str
    body: str
    received_time: str
    message_id: str = ""


class TempMailHandler(LoggerMixin):
    """TempMail处理器"""

    def __init__(self, config: EmailConfig):
        """
        初始化TempMail处理器

        Args:
            config: 邮箱配置
        """
        self.config = config
        self.session = requests.Session()

        # 设置请求头
        self.session.headers.update({
            'User-Agent': 'CursorVIP-Unified/1.0.0',
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        })

        # 支持的TempMail服务
        self.services = {
            'tempmail.plus': {
                'base_url': 'https://tempmail.plus/api',
                'generate_url': 'https://tempmail.plus',
            },
            # 暂时移除未实现的 10minutemail，避免配置错误导致空转
            # '10minutemail': { ... }
        }

    def generate_email(self) -> str:
        """
        生成临时邮箱

        Returns:
            str: 临时邮箱地址
        """
        try:
            service = self.services.get(self.config.tempmail_service, self.services['tempmail.plus'])

            if 'tempmail.plus' in service['base_url']:
                # tempmail.plus 生成邮箱
                url = f"{service['base_url']}/mails"
                params = {
                    'email': self.config.tempmail_email,
                    'limit': 1,
                    'epin': self.config.tempmail_pin
                }

                response = self.session.get(url, params=params, timeout=10)
                if response.status_code == 200:
                    # 如果成功，说明邮箱有效，直接返回配置的邮箱
                    return self.config.tempmail_email

            # 默认返回配置的邮箱
            return self.config.tempmail_email

        except Exception as e:
            self.logger.error(f"生成临时邮箱失败: {e}")
            return self.config.tempmail_email

    def get_verification_code(self, target_email: str, timeout: int = 60, start_timestamp: float = 0, ignore_mail_ids: List[str] = None) -> Optional[str]:
        """
        获取验证码 (完全复刻旧版逻辑)
        
        Args:
            target_email: 目标邮箱
            timeout: 超时时间(秒)
            start_timestamp: 开始搜索的时间戳（只处理在此之后收到的邮件）
            ignore_mail_ids: 要忽略的邮件ID列表（用于过滤旧邮件）
            
        Returns:
            Optional[str]: 验证码
        """
        try:
            ignore_mail_ids = ignore_mail_ids or []
            service = self.services.get(self.config.tempmail_service, self.services['tempmail.plus'])
            start_time = time.time()
            
            # 记录已经处理过的邮件ID，避免重复处理（虽然我们会删除，但双重保险）
            processed_mail_ids = set()

            loop_count = 0
            while time.time() - start_time < timeout:
                loop_count += 1
                if loop_count % 3 == 1: # 每3次循环（约3秒）打印一次
                    self.logger.info(f"正在检查邮件... (已耗时 {int(time.time() - start_time)}秒) 目标邮箱: {self.config.tempmail_email} API: {service['base_url']}")

                try:
                    # 1. 获取邮件列表
                    # 无论配置什么服务，只要 URL 包含 tempmail.plus 或者作为默认回退，都执行此逻辑
                    if 'tempmail.plus' in service['base_url']:
                        url = f"{service['base_url']}/mails"
                        params = {
                            'email': self.config.tempmail_email,
                            'limit': 20, 
                            'epin': self.config.tempmail_pin
                        }

                        response = self.session.get(url, params=params, timeout=10)

                        if response.status_code == 200:
                            data = response.json()
                            
                            # ⭐ 调试：打印获取到的原始邮件列表（只打印前3个）
                            if loop_count % 3 == 1:
                                self.logger.info(f"邮件列表响应: first_id={data.get('first_id')}, count={len(data.get('mail_list', []))}")
                                if data.get('mail_list'):
                                    for i, m in enumerate(data['mail_list'][:3]):
                                        self.logger.info(f"  [{i}] ID={m.get('mail_id')}, Subject={m.get('subject')}, From={m.get('from_mail')}")
                            
                            # 构造邮件ID列表 (参考旧版 _get_latest_mail_code)
                            mail_ids = []
                            if data.get('first_id'):
                                mail_ids.append(data.get('first_id'))
                            
                            mails_data = data.get('mail_list', []) or data.get('mails', [])
                            if mails_data:
                                # 只检查前5封
                                for mail in mails_data[:5]:
                                    mid = mail.get('mail_id') or mail.get('id')
                                    if mid and mid not in mail_ids:
                                        mail_ids.append(mid)
                            
                            if not mail_ids:
                                time.sleep(1)
                                continue

                            # 2. 遍历检查邮件
                            for mail_id in mail_ids:
                                # [关键修复] 过滤已知的旧邮件
                                if str(mail_id) in ignore_mail_ids:
                                    # 仅首次遇到时记录调试日志，避免刷屏
                                    if str(mail_id) not in processed_mail_ids:
                                        # self.logger.debug(f"跳过已知旧邮件: {mail_id}")
                                        processed_mail_ids.add(str(mail_id))
                                    continue

                                try:
                                    detail_url = f"{service['base_url']}/mails/{mail_id}"
                                    detail_params = {
                                        'email': self.config.tempmail_email,
                                        'epin': self.config.tempmail_pin
                                    }
                                    detail_response = self.session.get(detail_url, params=detail_params, timeout=10)
                                    
                                    if detail_response.status_code == 200:
                                        detail_data = detail_response.json()
                                        if detail_data.get('result'):
                                            
                                            mail_from = detail_data.get("from", "")
                                            mail_subject = detail_data.get("subject", "")
                                            mail_to = detail_data.get("to", "")
                                            mail_text = detail_data.get("text", "") or detail_data.get("html", "")
                                            mail_date = detail_data.get("date")

                                            # A. 时间检查
                                            if mail_date:
                                                try:
                                                    mail_ts = float(mail_date)
                                                    
                                                    # ⭐ 过滤旧邮件：如果邮件时间早于开始任务的时间，跳过并删除
                                                    if start_timestamp > 0 and mail_ts < start_timestamp:
                                                        self.logger.info(f"发现旧邮件 (Time: {mail_ts} < Start: {start_timestamp}), 跳过并删除")
                                                        # [关键修复] 强制转为字符串
                                                        self._delete_mail(str(mail_id))
                                                        processed_mail_ids.add(mail_id)
                                                        continue
                                                    
                                                    current_ts = time.time()
                                                    time_diff = current_ts - mail_ts
                                                    
                                                    # 仅记录日志，不跳过
                                                    if abs(time_diff) > 600:
                                                        self.logger.info(f"邮件时间差异较大 ({time_diff:.0f}s), 但可能是时区问题，继续处理")
                                                except:
                                                    pass

                                            # 1. 发件人检查 (参考旧版逻辑)
                                            # 确保只处理来自 Cursor 的邮件
                                            # ⭐ 增加调试日志
                                            self.logger.info(f"检查邮件: From='{mail_from}', Subject='{mail_subject}', ID={mail_id}")
                                            
                                            is_cursor_email = (
                                                'cursor' in mail_from.lower() or
                                                'no-reply' in mail_from.lower() or
                                                'noreply' in mail_from.lower()
                                            )
                                            
                                            if not is_cursor_email:
                                                # 如果不是 Cursor 邮件，再看内容是否包含 target_email (双重保险)
                                                # 但为了解决"长时间不输入"的问题，我们优先信任发件人过滤，避免处理杂乱邮件
                                                self.logger.debug(f"非Cursor邮件 (From: {mail_from}), 跳过")
                                                continue

                                            # 2. 收件人匹配
                                            # 宽容检查：只要邮件内容或主题包含目标邮箱，或者收件人字段匹配
                                            recipient_match = False
                                            
                                            # ⭐ 调试：打印匹配信息
                                            self.logger.info(f"匹配目标: {target_email} vs MailTo: {mail_to}")
                                            
                                            if target_email:
                                                target_lower = target_email.lower()
                                                if mail_to and target_lower in mail_to.lower():
                                                    recipient_match = True
                                                elif target_lower in mail_text.lower():
                                                    recipient_match = True
                                                elif target_lower in mail_subject.lower():
                                                    recipient_match = True
                                                else:
                                                    # ⭐ 特殊情况：如果是别名转发，可能 to 字段是别名，正文也没显示原名
                                                    # 这里做一个大胆的假设：如果是 Cursor 发来的最新邮件，且我们就在查这个邮箱，那大概率就是给我们的
                                                    self.logger.warning(f"⚠️ 邮件未明确包含目标邮箱 {target_email}，但发件人是 Cursor，尝试放行！")
                                                    recipient_match = True
                                            else:
                                                # 如果没传 target_email，默认匹配（风险较小，因为是用 pin 查的）
                                                recipient_match = True
                                            
                                            if not recipient_match:
                                                self.logger.warning(f"邮件收件人不匹配 (ID: {mail_id}), 跳过")
                                                continue

                                            # C. 提取验证码
                                            # 传入 target_email 以便移除
                                            code = self._extract_verification_code_from_mail(detail_data, target_email)
                                            
                                            # ⚡ 关键修正：如果提取到的验证码是空的，且发件人是 Cursor，这可能是因为验证码被误过滤了
                                            # 尝试在不移除 target_email 的情况下再提取一次
                                            if not code and is_cursor_email:
                                                self.logger.warning(f"⚠️ 常规提取失败，尝试保留邮箱地址提取...")
                                                code = self._extract_verification_code_from_mail(detail_data, "")

                                            if code:
                                                self.logger.info(f"✅ 找到验证码: {code}")
                                                # [关键修复] 强制转为字符串，防止 Cython 编译后类型错误
                                                self._delete_mail(str(mail_id))
                                                return code
                                            else:
                                                self.logger.warning(f"⚠️ 无法提取验证码 (ID: {mail_id})")
                                                self.logger.debug(f"邮件内容片段: {mail_text[:100]}...")

                                except Exception as e:
                                    self.logger.error(f"处理邮件异常: {e}")
                                    continue

                    time.sleep(1)

                except requests.RequestException as e:
                    self.logger.error(f"网络请求异常: {e}")
                    time.sleep(1)

            self.logger.warning("在超时时间内未找到验证码邮件")
            return None

        except Exception as e:
            self.logger.error(f"获取验证码失败: {e}")
            return None

    def _delete_mail(self, mail_id: str) -> bool:
        """
        删除邮件
        
        Args:
            mail_id: 邮件ID
            
        Returns:
            bool: 是否删除成功
        """
        try:
            service = self.services.get(self.config.tempmail_service, self.services['tempmail.plus'])
            url = f"{service['base_url']}/mails/"
            payload = {
                'email': self.config.tempmail_email,
                'first_id': mail_id,
                'epin': self.config.tempmail_pin
            }
            
            response = self.session.delete(url, data=payload, timeout=10)
            if response.status_code == 200 and response.json().get('result'):
                self.logger.info(f"已删除邮件: {mail_id}")
                return True
            return False
        except Exception as e:
            self.logger.warning(f"删除邮件失败: {e}")
            return False

    def _extract_verification_code_from_mail(self, mail: Dict[str, Any], target_email: str = "") -> Optional[str]:
        """
        从邮件中提取验证码

        Args:
            mail: 邮件数据
            target_email: 目标邮箱（用于在提取前移除，防止误判）

        Returns:
            Optional[str]: 验证码
        """
        try:
            subject = mail.get('subject', '')
            content = mail.get('text', '') or mail.get('html', '')

            # 合并邮件内容进行搜索
            full_content = f"{subject} {content}".lower()
            
            # ⭐ 关键修改：移除目标邮箱地址
            # 防止邮箱地址中的数字被误识别为验证码 (如 user123456@domain.com)
            if target_email:
                full_content = full_content.replace(target_email.lower(), '')

            # 验证码正则表达式
            patterns = [
                r'verification code[：:\s]+(\d{6})',
                r'verify code[：:\s]+(\d{6})',
                r'code[：:\s]+(\d{6})',
                r'verification[：:\s]+(\d{6})',
                r'验证码[：:\s]+(\d{6})',
                r'is\s+(\d{6})',  # 匹配 "code is 123456"
                r'>\s*(\d{6})\s*<', # 匹配 HTML 标签中的纯数字 <div>123456</div>
                r'(?<![a-zA-Z@.])\b(\d{6})\b' # ⭐ 增加负向断言，防止匹配到 user123456
            ]

            for pattern in patterns:
                match = re.search(pattern, full_content, re.IGNORECASE)
                if match:
                    code = match.group(1)
                    # 验证是否是6位数字
                    if code.isdigit() and len(code) == 6:
                        return code

            return None

        except Exception as e:
            self.logger.error(f"提取验证码失败: {e}")
            return None

    def get_recent_emails(self, limit: int = 5) -> List[EmailMessage]:
        """
        获取最近的邮件

        Args:
            limit: 限制数量

        Returns:
            List[EmailMessage]: 邮件列表
        """
        try:
            service = self.services.get(self.config.tempmail_service, self.services['tempmail.plus'])
            emails = []

            if 'tempmail.plus' in service['base_url']:
                url = f"{service['base_url']}/mails"
                params = {
                    'email': self.config.tempmail_email,
                    'limit': limit,
                    'epin': self.config.tempmail_pin
                }

                response = self.session.get(url, params=params, timeout=10)

                if response.status_code == 200:
                    data = response.json()
                    if data.get('result') and data.get('mail_list'):
                        for mail in data['mail_list'][:limit]:
                            email_msg = EmailMessage(
                                subject=mail.get('subject', ''),
                                sender=mail.get('from', ''),
                                body=mail.get('text', '') or mail.get('html', ''),
                                received_time=mail.get('date', ''),
                                message_id=mail.get('mail_id', '')
                            )
                            emails.append(email_msg)

            return emails

        except Exception as e:
            self.logger.error(f"获取邮件列表失败: {e}")
            return []


class IMAPHandler(LoggerMixin):
    """IMAP处理器"""

    def __init__(self, config: EmailConfig):
        """
        初始化IMAP处理器

        Args:
            config: 邮箱配置
        """
        self.config = config
        self.imap = None

    def connect(self) -> bool:
        """
        连接到IMAP服务器

        Returns:
            bool: 连接是否成功
        """
        try:
            if self.config.use_ssl:
                self.imap = imaplib.IMAP4_SSL(self.config.imap_server, self.config.imap_port)
            else:
                self.imap = imaplib.IMAP4(self.config.imap_server, self.config.imap_port)

            # 登录
            self.imap.login(self.config.imap_username, self.config.imap_password)

            # 选择文件夹
            self.imap.select(self.config.imap_folder)

            self.logger.info(f"IMAP连接成功: {self.config.imap_server}:{self.config.imap_port}")
            return True

        except Exception as e:
            self.logger.error(f"IMAP连接失败: {e}")
            return False

    def disconnect(self):
        """断开连接"""
        try:
            if self.imap:
                self.imap.logout()
                self.imap = None
        except:
            pass

    def get_verification_code(self, target_email: str = "", timeout: int = 60, start_timestamp: float = 0) -> Optional[str]:
        """
        获取验证码
        
        Args:
            target_email: 目标邮箱（用于搜索过滤）
            timeout: 超时时间(秒)
            start_timestamp: 开始时间戳
            
        Returns:
            Optional[str]: 验证码
        """
        if not self.imap and not self.connect():
            return None
            
        try:
            start_time = time.time()
            last_checked_msg_ids = set()
            
            # 如果没有提供target_email，尝试使用配置中的用户名作为过滤依据（虽然可能不准确）
            if not target_email:
                target_email = self.config.imap_username
            
            while time.time() - start_time < timeout:
                msg_ids = []
                
                # 策略1: 尝试搜索 (TO "target_email") - 带括号和引号
                try:
                    status, messages = self.imap.search('UTF-8', f'(TO "{target_email}")')
                    if status == 'OK' and messages[0]:
                        msg_ids = [msg_id.decode('utf-8') if isinstance(msg_id, bytes) else str(msg_id) 
                                  for msg_id in messages[0].split()]
                except:
                    pass
                
                # 策略2: 尝试搜索 TO target_email - 无括号
                if not msg_ids:
                    try:
                        status, messages = self.imap.search(None, 'TO', target_email)
                        if status == 'OK' and messages[0]:
                            msg_ids = [msg_id.decode('utf-8') if isinstance(msg_id, bytes) else str(msg_id) 
                                      for msg_id in messages[0].split()]
                    except:
                        pass
                
                # 策略3: 如果搜索失败，拉取最近30封邮件并在本地过滤
                if not msg_ids:
                    try:
                        # 获取邮件总数
                        status, data = self.imap.select(self.config.imap_folder)
                        if status == 'OK':
                            total_messages = int(data[0])
                            
                            # 检查最近30封
                            start_msg = max(1, total_messages - 29)
                            end_msg = total_messages
                            
                            for msg_num in range(end_msg, start_msg - 1, -1):
                                try:
                                    status, msg_data = self.imap.fetch(str(msg_num), '(RFC822.HEADER)')
                                    if status != 'OK' or not msg_data or not msg_data[0]:
                                        continue
                                        
                                    raw_email = msg_data[0][1]
                                    msg = email.message_from_bytes(raw_email)
                                    
                                    # 检查收件人
                                    to_addresses = []
                                    if msg.get('To'):
                                        to_addresses.extend(email_utils.getaddresses([msg.get('To')]))
                                    if msg.get('Cc'):
                                        to_addresses.extend(email_utils.getaddresses([msg.get('Cc')]))
                                        
                                    found = False
                                    for name, addr in to_addresses:
                                        if target_email.lower() in addr.lower():
                                            found = True
                                            break
                                            
                                    if found:
                                        msg_ids.append(str(msg_num))
                                        if len(msg_ids) >= 10:
                                            break
                                except:
                                    continue
                    except:
                        pass
                
                # 处理找到的邮件
                if msg_ids:
                    # 只处理最新的10封
                    recent_msgs = msg_ids[-10:] if len(msg_ids) > 10 else msg_ids
                    
                    for msg_id in reversed(recent_msgs):
                        if msg_id in last_checked_msg_ids:
                            continue
                            
                        try:
                            status, msg_data = self.imap.fetch(msg_id, '(RFC822)')
                            if status == 'OK':
                                email_message = email.message_from_bytes(msg_data[0][1])
                                
                                # ⭐ 时间过滤
                                if start_timestamp > 0:
                                    msg_date = email_message.get('Date')
                                    if msg_date:
                                        try:
                                            ts = email_utils.mktime_tz(email_utils.parsedate_tz(msg_date))
                                            if ts < start_timestamp:
                                                # 标记删除旧邮件（可选，视需求而定，这里暂不删除以免误删重要邮件）
                                                continue
                                        except:
                                            pass

                                code = self._extract_code_from_email(email_message)
                                
                                if code:
                                    # 找到验证码，删除邮件
                                    try:
                                        self.imap.store(msg_id, '+FLAGS', '\\Deleted')
                                        self.imap.expunge()
                                    except:
                                        pass
                                        
                                    self.logger.info(f"找到验证码: {code}")
                                    return code
                                    
                            last_checked_msg_ids.add(msg_id)
                        except Exception as e:
                            self.logger.error(f"解析邮件出错: {e}")
                            continue
                
                time.sleep(2)
                
            self.logger.warning("在超时时间内未找到验证码邮件")
            return None
            
        except Exception as e:
            self.logger.error(f"获取验证码失败: {e}")
            return None
        finally:
            self.disconnect()

    def _extract_code_from_email(self, email_message) -> Optional[str]:
        """
        从邮件中提取验证码

        Args:
            email_message: 邮件消息对象

        Returns:
            Optional[str]: 验证码
        """
        try:
            # 获取邮件主题和正文
            subject = self._decode_header(email_message.get('Subject', ''))
            body = self._get_email_body(email_message)

            # 合并内容进行搜索
            full_content = f"{subject} {body}".lower()

            # 验证码正则表达式
            patterns = [
                r'verification code[：:\s]+(\d{6})',
                r'verify code[：:\s]+(\d{6})',
                r'code[：:\s]+(\d{6})',
                r'verification[：:\s]+(\d{6})',
                r'验证码[：:\s]+(\d{6})',
                r'\b(\d{6})\b'
            ]

            for pattern in patterns:
                match = re.search(pattern, full_content, re.IGNORECASE)
                if match:
                    code = match.group(1)
                    if code.isdigit() and len(code) == 6:
                        return code

            return None

        except Exception as e:
            self.logger.error(f"提取验证码失败: {e}")
            return None

    def _decode_header(self, header: str) -> str:
        """解码邮件头部"""
        try:
            decoded_parts = email.header.decode_header(header)
            decoded_str = ''

            for part, encoding in decoded_parts:
                if isinstance(part, bytes):
                    decoded_str += part.decode(encoding or 'utf-8', errors='ignore')
                else:
                    decoded_str += str(part)

            return decoded_str
        except:
            return header

    def _get_email_body(self, email_message) -> str:
        """获取邮件正文"""
        try:
            body = ""

            if email_message.is_multipart():
                for part in email_message.walk():
                    if part.get_content_type() == "text/plain":
                        payload = part.get_payload(decode=True)
                        if payload:
                            body += payload.decode('utf-8', errors='ignore')
            else:
                payload = email_message.get_payload(decode=True)
                if payload:
                    body = payload.decode('utf-8', errors='ignore')

            return body
        except:
            return ""

    def get_recent_emails(self, limit: int = 5) -> List[EmailMessage]:
        """
        获取最近的邮件

        Args:
            limit: 限制数量

        Returns:
            List[EmailMessage]: 邮件列表
        """
        if not self.imap and not self.connect():
            return []

        try:
            emails = []

            # 获取最新的邮件
            status, messages = self.imap.search(None, 'ALL')

            if status == 'OK' and messages[0]:
                message_ids = messages[0].split()

                # 获取最新的limit封邮件
                for msg_id in reversed(message_ids[-limit:]):
                    status, msg_data = self.imap.fetch(msg_id, '(RFC822)')

                    if status == 'OK':
                        email_message = email.message_from_bytes(msg_data[0][1])

                        email_msg = EmailMessage(
                            subject=self._decode_header(email_message.get('Subject', '')),
                            sender=self._decode_header(email_message.get('From', '')),
                            body=self._get_email_body(email_message),
                            received_time=email_message.get('Date', ''),
                            message_id=email_message.get('Message-ID', '')
                        )

                        emails.append(email_msg)

            return emails

        except Exception as e:
            self.logger.error(f"获取邮件列表失败: {e}")
            return []
        finally:
            self.disconnect()


class EmailHandler(LoggerMixin):
    """统一邮箱处理器"""

    def __init__(self, config: EmailConfig):
        """
        初始化邮箱处理器

        Args:
            config: 邮箱配置
        """
        self.config = config
        self.tempmail_handler = TempMailHandler(config)
        self.imap_handler = IMAPHandler(config)

    def generate_email(self) -> str:
        """
        生成邮箱地址

        Returns:
            str: 邮箱地址
        """
        if self.config.mode == 'tempmail':
            return self.tempmail_handler.generate_email()
        elif self.config.mode == 'imap':
            # 检查是否是2925邮箱或者启用了别名生成
            if self.config.domain == '2925' or '2925.com' in self.config.imap_username:
                # 2925 别名生成逻辑: prefix-randomString@domain
                try:
                    if '@' in self.config.imap_username:
                        prefix = self.config.imap_username.split('@')[0]
                        domain = self.config.imap_username.split('@')[1]
                        
                        # 生成6-10位随机字符
                        random_chars = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
                        
                        # 构造别名
                        alias_email = f"{prefix}-{random_chars}@{domain}"
                        self.logger.info(f"生成2925别名邮箱: {alias_email}")
                        return alias_email
                except Exception as e:
                    self.logger.error(f"生成别名失败: {e}")
            
            # IMAP模式默认使用配置的邮箱
            return self.config.imap_username
        else:
            raise ValueError(f"不支持的邮箱模式: {self.config.mode}")

    def get_verification_code(self, target_email: str = "", timeout: int = 60, start_timestamp: float = 0, ignore_mail_ids: List[str] = None) -> Optional[str]:
        """
        获取验证码
        
        Args:
            target_email: 目标邮箱
            timeout: 超时时间(秒)
            start_timestamp: 开始时间戳
            ignore_mail_ids: 忽略的邮件ID列表
            
        Returns:
            Optional[str]: 验证码
        """
        if self.config.mode == 'tempmail':
            return self.tempmail_handler.get_verification_code(target_email, timeout, start_timestamp, ignore_mail_ids)
        elif self.config.mode == 'imap':
            return self.imap_handler.get_verification_code(target_email, timeout, start_timestamp)
        else:
            raise ValueError(f"不支持的邮箱模式: {self.config.mode}")

    def get_recent_emails(self, limit: int = 5) -> List[EmailMessage]:
        """
        获取最近的邮件

        Args:
            limit: 限制数量

        Returns:
            List[EmailMessage]: 邮件列表
        """
        if self.config.mode == 'tempmail':
            return self.tempmail_handler.get_recent_emails(limit)
        elif self.config.mode == 'imap':
            return self.imap_handler.get_recent_emails(limit)
        else:
            return []

    def test_connection(self) -> Tuple[bool, str]:
        """
        测试邮箱连接

        Returns:
            Tuple[bool, str]: (是否成功, 消息)
        """
        try:
            if self.config.mode == 'tempmail':
                # 测试TempMail连接
                emails = self.tempmail_handler.get_recent_emails(1)
                if emails is not None:
                    return True, "TempMail连接成功"
                else:
                    return False, "TempMail连接失败"

            elif self.config.mode == 'imap':
                # 测试IMAP连接
                if self.imap_handler.connect():
                    self.imap_handler.disconnect()
                    return True, "IMAP连接成功"
                else:
                    return False, "IMAP连接失败"

            else:
                return False, f"不支持的邮箱模式: {self.config.mode}"

        except Exception as e:
            return False, f"连接测试失败: {str(e)}"
