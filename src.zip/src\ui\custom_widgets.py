#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自定义 UI 组件
"""

from PyQt6.QtWidgets import (
    QLabel, QDialog, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QMessageBox
)
from PyQt6.QtCore import Qt, QTimer, QSize
from PyQt6.QtGui import (
    QLinearGradient, QColor, QPainter, QBrush, QPen, QMouseEvent, QFont, QFontMetrics
)

from ui.styles import CyberTheme

class RainbowTitleLabel(QLabel):
    """彩虹渐变标题标签 (使用 QLinearGradient 模拟流动效果)"""
    
    def __init__(self, text, font_size=16, bold=True, parent=None):
        super().__init__(text, parent)
        
        self.font_size = font_size
        self.is_bold = bold
        
        # 字体设置
        weight = QFont.Weight.Bold if bold else QFont.Weight.Normal
        font = QFont("Segoe UI", font_size, weight)
        font.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 1)
        self.setFont(font)
        
        # 渐变动画参数
        self.offset = 0.0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_gradient)
        self.timer.start(50)  # 20FPS 足够流畅
        
        # 定义渐变颜色 (青 -> 蓝 -> 粉)
        self.colors = [
            QColor("#00ff88"), # 青
            QColor("#00ccff"), # 蓝
            QColor("#ff0080"), # 粉
            QColor("#00ff88")  # 回到青 (循环)
        ]
        
    def update_gradient(self):
        # 移动偏移量
        self.offset += 0.05  # 加快速度
        if self.offset > 1.0:
            self.offset -= 1.0
        self.update() # 触发重绘

    def sizeHint(self):
        """重写 sizeHint 以确保布局管理器预留足够的空间"""
        weight = QFont.Weight.Bold if self.is_bold else QFont.Weight.Normal
        font = CyberTheme.get_font(self.font_size, weight == QFont.Weight.Bold)
        
        metrics = QFontMetrics(font)
        # 加上一些余量，特别是考虑到字间距
        width = metrics.horizontalAdvance(self.text()) + 30
        height = metrics.height() + 10
        return QSize(width, height)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # 强制使用初始化时指定的字体大小和粗细
        weight = QFont.Weight.Bold if self.is_bold else QFont.Weight.Normal
        font = CyberTheme.get_font(self.font_size, weight == QFont.Weight.Bold)
        painter.setFont(font)
        
        # 更密集的流光实现，确保短文本也能看到多种颜色
        # 渐变跨度设为宽度的 1.5 倍 (之前是2倍，太长了导致颜色变化慢)
        span_width = max(self.width() * 1.5, 200) # 最小跨度200
        
        start_x = -span_width + self.offset * span_width * 2
        end_x = start_x + span_width
        
        gradient = QLinearGradient(start_x, 0, end_x, 0)
        gradient.setColorAt(0.0, self.colors[0])
        gradient.setColorAt(0.33, self.colors[1])
        gradient.setColorAt(0.66, self.colors[2])
        gradient.setColorAt(1.0, self.colors[0])
        
        pen = QPen(QBrush(gradient), 0)
        painter.setPen(pen)
        
        # 绘制文本
        painter.drawText(self.rect(), self.alignment(), self.text())


class CyberMessageBox(QDialog):
    """自定义风格消息框"""
    
    # 图标映射 (使用 Segoe MDL2 Assets)
    ICON_INFO = "\ue946"     # Info
    ICON_WARNING = "\ue7ba"  # Warning
    ICON_ERROR = "\ue783"    # ErrorBadge
    ICON_QUESTION = "\ue9ce" # Unknown
    
    def __init__(self, parent=None, title="提示", text="", icon_type="info", buttons=None):
        super().__init__(parent)
        self._drag_pos = None
        self.result_btn = QMessageBox.StandardButton.NoButton
        
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Dialog)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.resize(400, 200)
        
        # 主布局
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # 背景容器
        container = QWidget()
        container.setObjectName("Container")
        container.setStyleSheet(f"""
            #Container {{
                background-color: {CyberTheme.COLOR_BG_PRIMARY};
                border: 1px solid {CyberTheme.COLOR_BORDER};
                border-radius: 8px;
            }}
        """)
        container_layout = QVBoxLayout(container)
        container_layout.setContentsMargins(0, 0, 0, 0)
        container_layout.setSpacing(0)
        
        # 1. 标题栏
        title_bar = QWidget()
        title_bar.setFixedHeight(36)
        title_bar.setStyleSheet(f"""
            QWidget {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                border-bottom: 1px solid {CyberTheme.COLOR_BORDER};
            }}
        """)
        title_layout = QHBoxLayout(title_bar)
        title_layout.setContentsMargins(12, 0, 8, 0)
        
        title_lbl = RainbowTitleLabel(title, font_size=13, bold=True)
        # 强制设置透明背景和无边框，防止继承父窗口样式
        title_lbl.setStyleSheet("background-color: transparent; border: none; color: transparent;") 
        title_layout.addWidget(title_lbl)
        title_layout.addStretch()
        
        # 仿照主界面样式，使用 Segoe MDL2 Assets 字体
        close_btn = QPushButton("✕")
        close_btn.setFixedSize(32, 24)
        # 确保字体和颜色与主界面一致
        close_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: transparent;
                border: none;
                border-radius: 4px;
                color: {CyberTheme.COLOR_TEXT_SECONDARY};
                font-family: "Segoe MDL2 Assets", "Segoe UI Symbol", "Microsoft YaHei", sans-serif;
                font-size: 12px;
                padding: 0;
            }}
            QPushButton:hover {{
                background-color: {CyberTheme.COLOR_DANGER};
                color: white;
            }}
        """)
        close_btn.clicked.connect(self.reject)
        title_layout.addWidget(close_btn)
        
        container_layout.addWidget(title_bar)
        
        # 2. 内容区域
        content = QWidget()
        content_layout = QHBoxLayout(content)
        content_layout.setContentsMargins(24, 24, 24, 24)
        content_layout.setSpacing(20)
        
        # 图标
        icon_lbl = QLabel()
        icon_lbl.setFixedSize(48, 48)
        icon_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon_font = QFont("Segoe MDL2 Assets", 24)
        icon_lbl.setFont(icon_font)
        
        icon_char = self.ICON_INFO
        icon_color = CyberTheme.COLOR_PRIMARY
        
        if icon_type == "warning":
            icon_char = self.ICON_WARNING
            icon_color = CyberTheme.COLOR_WARNING
        elif icon_type == "error":
            icon_char = self.ICON_ERROR
            icon_color = CyberTheme.COLOR_DANGER
        elif icon_type == "question":
            icon_char = self.ICON_QUESTION
            icon_color = CyberTheme.COLOR_ACCENT
            
        icon_lbl.setText(icon_char)
        icon_lbl.setStyleSheet(f"color: {icon_color}; font-family: 'Segoe MDL2 Assets'; border: none; background: transparent;")
        content_layout.addWidget(icon_lbl)
        
        # 文本
        text_lbl = QLabel(text)
        text_lbl.setWordWrap(True)
        text_lbl.setStyleSheet(f"color: {CyberTheme.COLOR_TEXT_PRIMARY}; font-size: 13px; border: none; background: transparent;")
        content_layout.addWidget(text_lbl, 1)
        
        container_layout.addWidget(content)
        
        # 3. 按钮区域
        btn_bar = QWidget()
        btn_bar.setStyleSheet(f"""
            QWidget {{
                background-color: {CyberTheme.COLOR_BG_SECONDARY};
                border-bottom-left-radius: 8px;
                border-bottom-right-radius: 8px;
                border-top: 1px solid {CyberTheme.COLOR_BORDER};
            }}
        """)
        btn_layout = QHBoxLayout(btn_bar)
        btn_layout.setContentsMargins(12, 12, 12, 12)
        btn_layout.addStretch()
        
        # 添加按钮
        if not buttons:
            buttons = [("确定", QMessageBox.StandardButton.Ok, "primary")]
            
        for btn_text, btn_val, btn_style in buttons:
            btn = QPushButton(btn_text)
            btn.setMinimumWidth(80)
            if btn_style == "primary":
                btn.setStyleSheet(f"""
                    QPushButton {{
                        background-color: {CyberTheme.COLOR_PRIMARY};
                        color: white;
                        border: none;
                        border-radius: 4px;
                        padding: 6px 16px;
                    }}
                    QPushButton:hover {{
                        background-color: {CyberTheme.COLOR_PRIMARY_HOVER};
                    }}
                """)
            else:
                btn.setStyleSheet(f"""
                    QPushButton {{
                        background-color: transparent;
                        color: {CyberTheme.COLOR_TEXT_PRIMARY};
                        border: 1px solid {CyberTheme.COLOR_BORDER};
                        border-radius: 4px;
                        padding: 6px 16px;
                    }}
                    QPushButton:hover {{
                        border-color: {CyberTheme.COLOR_TEXT_SECONDARY};
                    }}
                """)
            
            # 使用闭包捕获变量
            btn.clicked.connect(lambda checked, v=btn_val: self.on_btn_clicked(v))
            btn_layout.addWidget(btn)
            
        container_layout.addWidget(btn_bar)
        layout.addWidget(container)
        
    def on_btn_clicked(self, val):
        self.result_btn = val
        self.accept()
        
    # --- 静态便捷方法 ---
    @staticmethod
    def information(parent, title, text):
        dlg = CyberMessageBox(parent, title, text, "info")
        dlg.exec()
        return QMessageBox.StandardButton.Ok
        
    @staticmethod
    def warning(parent, title, text):
        dlg = CyberMessageBox(parent, title, text, "warning")
        dlg.exec()
        return QMessageBox.StandardButton.Ok

    @staticmethod
    def critical(parent, title, text):
        dlg = CyberMessageBox(parent, title, text, "error")
        dlg.exec()
        return QMessageBox.StandardButton.Ok
        
    @staticmethod
    def question(parent, title, text):
        buttons = [
            ("确定", QMessageBox.StandardButton.Yes, "primary"),
            ("取消", QMessageBox.StandardButton.No, "secondary")
        ]
        dlg = CyberMessageBox(parent, title, text, "question", buttons)
        dlg.exec()
        return dlg.result_btn

    # --- 拖动逻辑 ---
    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            if event.position().y() < 36:
                self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
                event.accept()

    def mouseMoveEvent(self, event: QMouseEvent):
        if event.buttons() == Qt.MouseButton.LeftButton and self._drag_pos:
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def mouseReleaseEvent(self, event: QMouseEvent):
        self._drag_pos = None
